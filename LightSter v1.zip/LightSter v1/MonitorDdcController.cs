using System.Runtime.InteropServices;

namespace LightSter;

internal sealed class MonitorDdcController
{
    private const byte VcpBrightness = 0x10;
    private const byte VcpContrast = 0x12;
    private const byte VcpRedGain = 0x16;
    private const byte VcpGreenGain = 0x18;
    private const byte VcpBlueGain = 0x1A;

    // VCP 0x72 "Gamma" - zweryfikowane narzędziem ControlMyMonitor (NirSoft) na
    // konkretnym monitorze użytkownika: Current Value=140, Maximum=160, dozwolone
    // wartości 80/100/120/140/160 - czyli NIE indeks 0-4 (jak wcześniej zakładałem
    // jako najczęstszy, "domyślny" schemat), tylko surowa wartość policzona ze wzoru
    // (gamma - 1.0) * 100: 1.8->80, 2.0->100, 2.2->120, 2.4->140, 2.6->160.
    private const byte VcpGamma = 0x72;

    private static uint GammaValueToVcpIndex(double value) => (uint)Math.Round((value - 1.0) * 100);

    private static double VcpIndexToGammaValue(uint index) => GammaSteps.Snap(index / 100.0 + 1.0) ?? 2.2;

    private static readonly object DdcLock = new();
    private static readonly Dictionary<string, Dictionary<byte, uint>> MaximumCache = new(StringComparer.Ordinal);

    // Ostatnio zastosowane wartosci per monitor - pozwala pomijac zapis DDC dla wartosci,
    // ktore sie nie zmienily. DDC/CI po magistrali I2C jest WOLNE (dziesiatki-setki ms na
    // kazda pojedyncza wartosc), wiec przy ruszaniu WYLACZNIE suwakiem saturacji nie ma
    // sensu za kazdym razem od nowa wysylac tez jasnosc/kontrast/RGB - to byla glowna
    // przyczyna opoznien i "gubienia" zmian saturacji (czekaly w kolejce za wolnym DDC).
    private static readonly Dictionary<string, ManualMonitorValues> LastAppliedCache = new(StringComparer.Ordinal);

    // Saturacja jest sterowana przez NVIDIA NVAPI (Digital Vibrance), nie przez DDC/CI.
    private readonly MonitorVibranceController _vibranceController = new();

    public IReadOnlyList<MonitorDescriptor> GetMonitors()
    {
        List<MonitorDescriptor> monitors = [];

        EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (hMonitor, _, _, _) =>
        {
            if (!GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitor, out uint count) || count == 0)
            {
                return true;
            }

            PhysicalMonitor[] physicalMonitors = new PhysicalMonitor[count];
            if (!GetPhysicalMonitorsFromHMONITOR(hMonitor, count, physicalMonitors))
            {
                return true;
            }

            string? gdiDeviceName = TryGetGdiDeviceName(hMonitor);

            for (int index = 0; index < physicalMonitors.Length; index++)
            {
                PhysicalMonitor physicalMonitor = physicalMonitors[index];
                string description = string.IsNullOrWhiteSpace(physicalMonitor.Description)
                    ? $"Monitor {monitors.Count + 1}"
                    : physicalMonitor.Description.Trim();

                monitors.Add(new MonitorDescriptor(
                    BuildMonitorId(monitors.Count, description, gdiDeviceName),
                    description));
            }

            foreach (PhysicalMonitor physicalMonitor in physicalMonitors)
            {
                DestroyPhysicalMonitor(physicalMonitor.Handle);
            }

            return true;
        }, IntPtr.Zero);

        if (monitors.Count == 0)
        {
            monitors.Add(new MonitorDescriptor("default", "Domyślny monitor"));
        }

        return monitors;
    }

    public ApplyResult ApplyAutomation(AppSettings settings, TimeOnly time)
    {
        lock (DdcLock)
        {
            return ApplyAutomationCore(settings, time);
        }
    }

    private ApplyResult ApplyAutomationCore(AppSettings settings, TimeOnly time)
    {
        List<PhysicalMonitorBinding> monitors = GetPhysicalMonitorBindings();
        int success = 0;
        int attempted = 0;
        List<string> failures = [];

        try
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                MonitorConfiguration configuration = ResolveConfiguration(settings, monitor.MonitorId, monitor.DisplayName);
                Profile profile = configuration.ActiveProfile;
                TimeOnly effectiveTime = profile.GetEffectiveTime(time, settings.ShowSlotTimeOffsetPanel);

                int brightness = profile.Brightness.GetValueAt(effectiveTime);
                int contrast = profile.Contrast.GetValueAt(effectiveTime);
                int saturation = profile.Saturation.GetValueAt(effectiveTime);
                int rgb = profile.Rgb.GetValueAt(effectiveTime);

                // Gamma nie jest powiązana z krzywymi w ogóle - to czysto ręczne
                // ustawienie (pigułka gammy w szybkim panelu).
                double gamma = configuration.ManualValues.Gamma;

                attempted += 7;
                success += ApplyValues(
                    monitor.Handle,
                    monitor.MonitorId,
                    monitor.GdiDeviceName,
                    brightness,
                    contrast,
                    saturation,
                    rgb,
                    rgb,
                    rgb,
                    gamma,
                    failures);
            }
        }
        finally
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                DestroyPhysicalMonitor(monitor.Handle);
            }
        }

        return new ApplyResult(monitors.Count, attempted, success, failures);
    }

    public ApplyResult ApplyManual(ManualMonitorValues values, string? monitorId = null, bool applyGamma = true)
    {
        values.Clamp();
        lock (DdcLock)
        {
            return ApplyManualCore(values, monitorId, applyGamma);
        }
    }

    private ApplyResult ApplyManualCore(ManualMonitorValues values, string? monitorId, bool applyGamma)
    {
        List<PhysicalMonitorBinding> monitors = GetPhysicalMonitorBindings();
        int success = 0;
        int attempted = 0;
        List<string> failures = [];

        double? gammaToApply = applyGamma ? values.Gamma : null;

        try
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                if (monitorId is not null && monitor.MonitorId != monitorId)
                {
                    continue;
                }

                attempted += gammaToApply.HasValue ? 7 : 6;
                success += ApplyValues(
                    monitor.Handle,
                    monitor.MonitorId,
                    monitor.GdiDeviceName,
                    values.Brightness,
                    values.Contrast,
                    values.Saturation,
                    values.Red,
                    values.Green,
                    values.Blue,
                    gammaToApply,
                    failures);
            }
        }
        finally
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                DestroyPhysicalMonitor(monitor.Handle);
            }
        }

        return new ApplyResult(monitors.Count, attempted, success, failures);
    }

    public ApplyResult ApplyPreset(Preset preset, string? monitorId = null)
    {
        preset.Clamp();
        // "None" (preset.Gamma == null) oznacza, ze ten preset ma w ogole nie
        // dotykac gammy - applyGamma:false pomija VCP 0x72 calkowicie zamiast
        // wyslac cokolwiek.
        return ApplyManual(
            new ManualMonitorValues
            {
                Brightness = preset.Brightness,
                Contrast = preset.Contrast,
                Saturation = preset.Saturation,
                Red = preset.Rgb,
                Green = preset.Rgb,
                Blue = preset.Rgb,
                Gamma = preset.Gamma ?? 2.2
            },
            monitorId,
            applyGamma: preset.Gamma.HasValue);
    }

    /// <summary>
    /// Ustawia WYŁĄCZNIE gammę, nie dotykając jasności/kontrastu/saturacji/RGB w
    /// ogóle - używane przez pigułkę gammy w szybkim panelu, która działa niezależnie
    /// od tego, czy "Krzywe" (automatyka) jest właśnie włączone. Zwykłe ApplyManual
    /// wysłałoby też cokolwiek aktualnie siedzi w ManualValues dla reszty parametrów,
    /// co przy włączonej automatyce nadpisałoby na monitorze świeżo wyliczone przez
    /// nią wartości nieaktualnymi, ręcznymi.
    /// </summary>
    public ApplyResult ApplyGammaOnly(double gamma, string? monitorId = null)
    {
        double snapped = GammaSteps.Snap(gamma) ?? 2.2;
        lock (DdcLock)
        {
            List<PhysicalMonitorBinding> monitors = GetPhysicalMonitorBindings();
            int success = 0;
            int attempted = 0;
            List<string> failures = [];

            try
            {
                foreach (PhysicalMonitorBinding monitor in monitors)
                {
                    if (monitorId is not null && monitor.MonitorId != monitorId)
                    {
                        continue;
                    }

                    attempted++;
                    LastAppliedCache.TryGetValue(monitor.MonitorId, out ManualMonitorValues? previous);
                    if (ApplyGammaIfChanged(monitor.Handle, snapped, previous?.Gamma, failures))
                    {
                        success++;
                        ManualMonitorValues confirmed = previous?.Clone() ?? new ManualMonitorValues();
                        confirmed.Gamma = snapped;
                        LastAppliedCache[monitor.MonitorId] = confirmed;
                    }
                }
            }
            finally
            {
                foreach (PhysicalMonitorBinding monitor in monitors)
                {
                    DestroyPhysicalMonitor(monitor.Handle);
                }
            }

            return new ApplyResult(monitors.Count, attempted, success, failures);
        }
    }

    public int? TryReadBrightness(string? monitorId = null)
    {
        lock (DdcLock)
        {
            return TryReadBrightnessCore(monitorId);
        }
    }

    private int? TryReadBrightnessCore(string? monitorId)
    {
        List<PhysicalMonitorBinding> monitors = GetPhysicalMonitorBindings();

        try
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                if (monitorId is not null && monitor.MonitorId != monitorId)
                {
                    continue;
                }

                if (TryGetVcpFeature(monitor.Handle, VcpBrightness, out uint current, out uint maximum) && maximum > 0)
                {
                    return (int)Math.Clamp(Math.Round(current / (double)maximum * 100), 0, 100);
                }
            }
        }
        finally
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                DestroyPhysicalMonitor(monitor.Handle);
            }
        }

        return null;
    }

    public double? TryReadGamma(string? monitorId = null)
    {
        lock (DdcLock)
        {
            return TryReadGammaCore(monitorId);
        }
    }

    private double? TryReadGammaCore(string? monitorId)
    {
        List<PhysicalMonitorBinding> monitors = GetPhysicalMonitorBindings();

        try
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                if (monitorId is not null && monitor.MonitorId != monitorId)
                {
                    continue;
                }

                if (TryGetVcpFeature(monitor.Handle, VcpGamma, out uint current, out _))
                {
                    return VcpIndexToGammaValue(current);
                }
            }
        }
        finally
        {
            foreach (PhysicalMonitorBinding monitor in monitors)
            {
                DestroyPhysicalMonitor(monitor.Handle);
            }
        }

        return null;
    }

    private static MonitorConfiguration ResolveConfiguration(
        AppSettings settings,
        string monitorId,
        string displayName)
    {
        MonitorConfiguration? configuration = settings.Monitors.FirstOrDefault(
            monitor => monitor.MonitorId == monitorId);

        if (configuration is not null)
        {
            return configuration;
        }

        return MonitorConfiguration.Create(monitorId, displayName, 0);
    }

    private int ApplyValues(
        IntPtr handle,
        string monitorCacheKey,
        string? gdiDeviceName,
        int brightness,
        int contrast,
        int saturation,
        int red,
        int green,
        int blue,
        double? gamma,
        List<string> failures)
    {
        Dictionary<byte, uint> maximums = ReadMaximums(handle, monitorCacheKey);
        int success = 0;

        LastAppliedCache.TryGetValue(monitorCacheKey, out ManualMonitorValues? previous);

        // Zaczynamy od tego, co bylo ostatnio potwierdzone (albo od wartosci docelowych przy
        // pierwszym uruchomieniu) - i nadpisujemy TYLKO te pola, ktore faktycznie udalo sie
        // zapisac. Dzieki temu nieudany zapis nie zostanie mylnie zapamietany jako sukces
        // (co uniemozliwiloby ponowna probe przy nastepnej, identycznej wartosci).
        ManualMonitorValues confirmed = previous?.Clone() ?? new ManualMonitorValues
        {
            Brightness = brightness,
            Contrast = contrast,
            Saturation = saturation,
            Red = red,
            Green = green,
            Blue = blue,
            Gamma = gamma ?? 2.2
        };

        // Saturacja idzie PIERWSZA i ZAWSZE (nawet jesli sie nie zmienila - koszt jest
        // pomijalny dzieki cache'owaniu uchwytu w MonitorVibranceController). NVAPI nie
        // korzysta z wolnej magistrali I2C, wiec powinno zadzialac praktycznie od razu -
        // zanim ewentualne wolne zapisy DDC ponizej zdazą zablokowac watek na dluzej.
        if (_vibranceController.TrySetSaturation(gdiDeviceName, saturation))
        {
            success++;
            confirmed.Saturation = saturation;
        }
        else
        {
            failures.Add($"Saturacja (NVIDIA Digital Vibrance): {_vibranceController.LastError ?? "nieznany blad"}");
        }

        // Jasnosc/kontrast/RGB ida po wolnym DDC/CI - wysylamy tylko to, co faktycznie
        // sie zmienilo od ostatniego zastosowania, zeby nie blokowac watku niepotrzebnie
        // przy zmianie samej saturacji.
        if (ApplyIfChanged(handle, VcpBrightness, brightness, 100, previous?.Brightness, maximums, failures))
        {
            success++;
            confirmed.Brightness = brightness;
        }

        if (ApplyIfChanged(handle, VcpContrast, contrast, 100, previous?.Contrast, maximums, failures))
        {
            success++;
            confirmed.Contrast = contrast;
        }

        // appMax = 100: skala RGB w aplikacji to teraz 0-100 (dopasowana do
        // monitorów, ktore i tak nie przyjmuja pelnego zakresu 0-255 na tych VCP).
        // ScaleToMonitor ponizej i tak przeskaluje dalej do realnego zakresu
        // zglaszanego przez monitor, jesli ten zglasza cos innego niz 100.
        if (ApplyIfChanged(handle, VcpRedGain, red, 100, previous?.Red, maximums, failures))
        {
            success++;
            confirmed.Red = red;
        }

        if (ApplyIfChanged(handle, VcpGreenGain, green, 100, previous?.Green, maximums, failures))
        {
            success++;
            confirmed.Green = green;
        }

        if (ApplyIfChanged(handle, VcpBlueGain, blue, 100, previous?.Blue, maximums, failures))
        {
            success++;
            confirmed.Blue = blue;
        }

        // Gamma: null oznacza "nie dotykaj jej wcale" (np. preset ustawiony na
        // "None", albo aktywny slot bez zadnych punktow gammy podczas gdy manualna
        // wartosc jeszcze sie nie ustalila) - w tym wypadku po prostu pomijamy VCP
        // 0x72 calkowicie, zamiast wysylac cokolwiek.
        if (gamma is { } gammaValue)
        {
            double snappedGamma = GammaSteps.Snap(gammaValue) ?? 2.2;
            if (ApplyGammaIfChanged(handle, snappedGamma, previous?.Gamma, failures))
            {
                success++;
                confirmed.Gamma = snappedGamma;
            }
        }

        LastAppliedCache[monitorCacheKey] = confirmed;

        return success;
    }

    // Jak ApplyIfChanged, ale dla gammy (dyskretny indeks VCP 0-4 zamiast
    // proporcjonalnego skalowania 0-100/0-255).
    private static bool ApplyGammaIfChanged(
        IntPtr handle,
        double gamma,
        double? previousGamma,
        List<string> failures)
    {
        if (previousGamma.HasValue && Math.Abs(previousGamma.Value - gamma) < 0.01)
        {
            return true;
        }

        uint index = GammaValueToVcpIndex(gamma);

        // DDC/CI jedzie po wolnej, niezbyt niezawodnej magistrali I2C - SetVCPFeature
        // zwracające "true" oznacza tylko, że sam zapis się wysłał, NIE że monitor
        // faktycznie zdążył go poprawnie przyjąć (zwłaszcza przy szybko po sobie
        // następujących komendach - stąd zgłoszony problem: GUI pokazywało 2.6, ale
        // monitor realnie wciąż miał 2.4/2.6 sprzed jednego kroku). Żeby mieć
        // pewność, że to, co pokazuje GUI, NAPRAWDĘ dotarło do monitora - po każdym
        // zapisie odczytujemy z powrotem aktualną wartość i, jeśli się nie zgadza,
        // próbujemy ponownie (z krótką przerwą, żeby dać magistrali czas na
        // "ustatkowanie się" po poprzedniej komendzie).
        const int maxAttempts = 4;
        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            bool sent = SetVCPFeature(handle, VcpGamma, index);
            if (!sent)
            {
                if (attempt == maxAttempts)
                {
                    failures.Add($"0x{VcpGamma:X2} (gamma) - zapis nie powiódł się");
                    return false;
                }

                Thread.Sleep(60);
                continue;
            }

            // Krótka przerwa, żeby dać monitorowi chwilę na faktyczne przetworzenie
            // komendy, zanim spytamy go, jaką wartość teraz ma - odpytanie od razu
            // "na styk" po zapisie bywa zawodne na tej samej magistrali.
            Thread.Sleep(40);

            if (TryGetVcpFeature(handle, VcpGamma, out uint readBack, out _) && readBack == index)
            {
                return true;
            }

            if (attempt == maxAttempts)
            {
                failures.Add(
                    $"0x{VcpGamma:X2} (gamma) - monitor nie potwierdził wartości po {maxAttempts} próbach");
                return false;
            }

            Thread.Sleep(60);
        }

        return false;
    }

    // Pomija zapis DDC, jesli wartosc jest identyczna jak ostatnio wyslana do tego monitora.
    // Brak zmiany liczymy jako "sukces" (nic nie trzeba bylo robic).
    private static bool ApplyIfChanged(
        IntPtr handle,
        byte code,
        int appValue,
        int appMax,
        int? previousValue,
        Dictionary<byte, uint> maximums,
        List<string> failures)
    {
        if (previousValue.HasValue && previousValue.Value == appValue)
        {
            return true;
        }

        return SetFeature(handle, code, appValue, appMax, maximums, failures);
    }


    private static Dictionary<byte, uint> ReadMaximums(IntPtr handle, string monitorCacheKey)
    {
        if (MaximumCache.TryGetValue(monitorCacheKey, out Dictionary<byte, uint>? cached))
        {
            return cached;
        }

        Dictionary<byte, uint> maximums = [];
        TryReadMaximum(handle, VcpBrightness, maximums);
        TryReadMaximum(handle, VcpContrast, maximums);
        TryReadMaximum(handle, VcpRedGain, maximums);
        TryReadMaximum(handle, VcpGreenGain, maximums);
        TryReadMaximum(handle, VcpBlueGain, maximums);
        MaximumCache[monitorCacheKey] = maximums;
        return maximums;
    }

    private static void TryReadMaximum(IntPtr handle, byte code, Dictionary<byte, uint> maximums)
    {
        if (TryGetVcpFeature(handle, code, out _, out uint maximum) && maximum > 0)
        {
            maximums[code] = maximum;
        }
    }

    private static bool SetFeature(
        IntPtr monitor,
        byte code,
        int appValue,
        int appMax,
        Dictionary<byte, uint> maximums,
        List<string> failures)
    {
        uint monitorMax = maximums.GetValueOrDefault(code, (uint)appMax);
        uint scaled = ScaleToMonitor(appValue, appMax, monitorMax);
        bool ok = SetVCPFeature(monitor, code, scaled);
        if (!ok)
        {
            failures.Add($"0x{code:X2}");
        }

        return ok;
    }

    private static uint ScaleToMonitor(int appValue, int appMax, uint monitorMax)
    {
        if (appMax <= 0)
        {
            return 0;
        }

        int clamped = Math.Clamp(appValue, 0, appMax);
        return (uint)Math.Round(clamped / (double)appMax * monitorMax);
    }

    private static List<PhysicalMonitorBinding> GetPhysicalMonitorBindings()
    {
        List<PhysicalMonitorBinding> monitors = [];

        EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (hMonitor, _, _, _) =>
        {
            if (!GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitor, out uint count) || count == 0)
            {
                return true;
            }

            PhysicalMonitor[] physicalMonitors = new PhysicalMonitor[count];
            if (!GetPhysicalMonitorsFromHMONITOR(hMonitor, count, physicalMonitors))
            {
                return true;
            }

            string? gdiDeviceName = TryGetGdiDeviceName(hMonitor);

            for (int index = 0; index < physicalMonitors.Length; index++)
            {
                PhysicalMonitor physicalMonitor = physicalMonitors[index];
                string description = string.IsNullOrWhiteSpace(physicalMonitor.Description)
                    ? $"Monitor {monitors.Count + 1}"
                    : physicalMonitor.Description.Trim();

                monitors.Add(new PhysicalMonitorBinding(
                    physicalMonitor.Handle,
                    BuildMonitorId(monitors.Count, description, gdiDeviceName),
                    description,
                    gdiDeviceName));
            }

            return true;
        }, IntPtr.Zero);

        return monitors;
    }

    private static string? TryGetGdiDeviceName(IntPtr hMonitor)
    {
        MONITORINFOEX info = new();
        info.cbSize = Marshal.SizeOf<MONITORINFOEX>();
        if (GetMonitorInfo(hMonitor, ref info) && !string.IsNullOrWhiteSpace(info.szDevice))
        {
            return info.szDevice;
        }

        return null;
    }

    /// <summary>
    /// Buduje identyfikator monitora używany do dopasowania go do zapisanego profilu
    /// (m.in. przesunięcia czasowego "Czas"/H) pomiędzy uruchomieniami aplikacji.
    /// </summary>
    /// <remarks>
    /// Wcześniej identyfikator opierał się WYŁĄCZNIE o kolejność zwróconą przez
    /// EnumDisplayMonitors w danym wywołaniu ("0:Generic PnP Monitor" itd.) - dla
    /// monitorów bez unikalnego EDID/numeru seryjnego (bardzo częste dla "Generic PnP
    /// Monitor", jak w tej konfiguracji) ta kolejność nie jest gwarantowana pomiędzy
    /// uruchomieniami. Zwłaszcza tuż po restarcie komputera ("Autostart"), monitor
    /// bywa jeszcze "wybudzany" i bywa wykryty inaczej niż normalnie, przez co
    /// aplikacja dopasowywała się do INNEGO zapisanego profilu monitora - a każdy
    /// profil ma swoje własne przesunięcie czasowe, więc z perspektywy użytkownika
    /// wyglądało to tak, jakby "zero samo się przesunęło" po restarcie.
    ///
    /// Nazwa urządzenia GDI (np. "\\.\DISPLAY1", przypisywana przez Windows do
    /// konkretnego portu/adaptera GPU) jest dużo bardziej stabilna pomiędzy
    /// restartami niż kolejność enumeracji, więc używamy jej jako głównego składnika
    /// identyfikatora, gdy jest dostępna - z powrotem do starego schematu tylko jako
    /// ostateczność, gdyby z jakiegoś powodu nie udało się jej odczytać.
    /// </remarks>
    private static string BuildMonitorId(int index, string description, string? gdiDeviceName)
    {
        return !string.IsNullOrWhiteSpace(gdiDeviceName)
            ? $"{gdiDeviceName}:{description}"
            : $"{index}:{description}";
    }

    [DllImport("user32.dll")]
    private static extern bool EnumDisplayMonitors(
        IntPtr hdc,
        IntPtr lprcClip,
        MonitorEnumProc lpfnEnum,
        IntPtr dwData);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFOEX lpmi);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MONITORINFOEX
    {
        public int cbSize;
        public RECT rcMonitor;
        public RECT rcWork;
        public uint dwFlags;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string szDevice;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    private delegate bool MonitorEnumProc(
        IntPtr hMonitor,
        IntPtr hdcMonitor,
        IntPtr lprcMonitor,
        IntPtr dwData);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool GetNumberOfPhysicalMonitorsFromHMONITOR(
        IntPtr hMonitor,
        out uint pdwNumberOfPhysicalMonitors);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool GetPhysicalMonitorsFromHMONITOR(
        IntPtr hMonitor,
        uint dwPhysicalMonitorArraySize,
        [Out] PhysicalMonitor[] pPhysicalMonitorArray);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool DestroyPhysicalMonitor(IntPtr hMonitor);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool SetVCPFeature(
        IntPtr hMonitor,
        byte bVCPCode,
        uint dwNewValue);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool GetVCPFeatureAndVCPFeatureReply(
        IntPtr hMonitor,
        byte bVCPCode,
        out byte pvct,
        out uint pdwCurrentValue,
        out uint pdwMaximumValue);

    private static bool TryGetVcpFeature(IntPtr monitor, byte code, out uint current, out uint maximum)
    {
        bool ok = GetVCPFeatureAndVCPFeatureReply(monitor, code, out _, out current, out maximum);
        return ok && maximum > 0;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct PhysicalMonitor
    {
        public IntPtr Handle;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string Description;
    }

    private sealed record PhysicalMonitorBinding(IntPtr Handle, string MonitorId, string DisplayName, string? GdiDeviceName);
}

internal sealed record MonitorDescriptor(string MonitorId, string DisplayName);

internal sealed record ApplyResult(
    int MonitorCount,
    int AttemptedFeatures,
    int SuccessfulFeatures,
    IReadOnlyList<string> FailedVcpCodes);
