namespace LightSter;

internal sealed class SmoothMonitorApplier
{
    private const int AutomationIntervalMs = 60_000;
    private const int BrightnessStep = 2;
    private const int ContrastStep = 2;
    private const int SaturationStep = 2;
    private const int RgbStep = 5;

    private readonly MonitorDdcController _controller = new();
    private readonly Dictionary<string, ManualMonitorValues> _currentByMonitor = new(StringComparer.Ordinal);
    private readonly object _gate = new();
    private readonly object _pendingLock = new();
    private DateTime _lastAutomationTick = DateTime.MinValue;
    private ManualMonitorValues? _pendingManual;
    private string? _pendingManualMonitorId;
    private Action? _pendingManualCallback;
    private bool _pendingManualApplyGamma = true;
    private int _manualWorkerActive;

    private double? _pendingGamma;
    private string? _pendingGammaMonitorId;
    private Action? _pendingGammaCallback;
    private int _gammaWorkerActive;

    public void ApplyManualNow(AppSettings settings, Action? onCompleted = null)
    {
        ManualMonitorValues snapshot = settings.ActiveMonitor.ManualValues.Clone();
        string? monitorId = settings.Monitors.Count > 1 ? settings.ActiveMonitor.MonitorId : null;

        lock (_gate)
        {
            if (monitorId is not null)
            {
                _currentByMonitor[monitorId] = snapshot.Clone();
            }
            else
            {
                foreach (MonitorConfiguration monitor in settings.Monitors)
                {
                    _currentByMonitor[monitor.MonitorId] = snapshot.Clone();
                }
            }
        }

        lock (_pendingLock)
        {
            _pendingManual = snapshot;
            _pendingManualMonitorId = monitorId;
            _pendingManualCallback = onCompleted;
            _pendingManualApplyGamma = true;
        }

        ScheduleManualApply();
    }

    public void ApplyPresetNow(Preset preset, AppSettings settings, Action? onCompleted = null)
    {
        ManualMonitorValues snapshot = new()
        {
            Brightness = preset.Brightness,
            Contrast = preset.Contrast,
            Saturation = preset.Saturation,
            Red = preset.Rgb,
            Green = preset.Rgb,
            Blue = preset.Rgb,
            Gamma = preset.Gamma ?? 2.2
        };
        snapshot.Clamp();

        lock (_gate)
        {
            foreach (MonitorConfiguration monitor in settings.Monitors)
            {
                _currentByMonitor[monitor.MonitorId] = snapshot.Clone();
            }
        }

        lock (_pendingLock)
        {
            _pendingManual = snapshot;
            _pendingManualMonitorId = null;
            _pendingManualCallback = onCompleted;
            // "None" (preset.Gamma == null) ma jawnie nie dotykac gammy w ogole.
            _pendingManualApplyGamma = preset.Gamma.HasValue;
        }

        ScheduleManualApply();
    }

    public void TickAutomation(AppSettings settings, Action? onCompleted = null)
    {
        if (!settings.AppEnabled || !settings.AutomationEnabled)
        {
            return;
        }

        if ((DateTime.UtcNow - _lastAutomationTick).TotalMilliseconds < AutomationIntervalMs)
        {
            return;
        }

        _lastAutomationTick = DateTime.UtcNow;
        TimeOnly now = TimeOnly.FromDateTime(DateTime.Now);
        Dictionary<string, ManualMonitorValues> nextValues = [];

        lock (_gate)
        {
            foreach (MonitorConfiguration monitor in settings.Monitors)
            {
                ManualMonitorValues target = BuildTarget(monitor, now, settings.ShowSlotTimeOffsetPanel);
                if (!_currentByMonitor.TryGetValue(monitor.MonitorId, out ManualMonitorValues? current))
                {
                    current = target.Clone();
                }

                ManualMonitorValues stepped = StepToward(current, target);
                _currentByMonitor[monitor.MonitorId] = stepped.Clone();
                nextValues[monitor.MonitorId] = stepped;
            }
        }

        RunOnBackground(() =>
        {
            foreach (KeyValuePair<string, ManualMonitorValues> entry in nextValues)
            {
                _controller.ApplyManual(entry.Value, entry.Key);
            }

            onCompleted?.Invoke();
        });
    }

    public void ForceAutomationSync(AppSettings settings, Action? onCompleted = null)
    {
        _lastAutomationTick = DateTime.MinValue;
        TimeOnly now = TimeOnly.FromDateTime(DateTime.Now);
        Dictionary<string, ManualMonitorValues> nextValues = [];

        lock (_gate)
        {
            foreach (MonitorConfiguration monitor in settings.Monitors)
            {
                ManualMonitorValues target = BuildTarget(monitor, now, settings.ShowSlotTimeOffsetPanel);
                _currentByMonitor[monitor.MonitorId] = target.Clone();
                nextValues[monitor.MonitorId] = target;
            }
        }

        RunOnBackground(() =>
        {
            foreach (KeyValuePair<string, ManualMonitorValues> entry in nextValues)
            {
                _controller.ApplyManual(entry.Value, entry.Key);
            }

            onCompleted?.Invoke();
        });
    }

    public void ReadBrightness(Action<int>? onCompleted)
    {
        RunOnBackground(() =>
        {
            int? value = _controller.TryReadBrightness();
            if (value.HasValue)
            {
                onCompleted?.Invoke(value.Value);
            }
        });
    }

    private void ScheduleManualApply()
    {
        if (Interlocked.CompareExchange(ref _manualWorkerActive, 1, 0) != 0)
        {
            return;
        }

        Task.Run(ProcessManualQueue);
    }

    private void ProcessManualQueue()
    {
        try
        {
            while (true)
            {
                ManualMonitorValues? snapshot;
                string? monitorId;
                Action? callback;
                bool applyGamma;

                lock (_pendingLock)
                {
                    snapshot = _pendingManual;
                    monitorId = _pendingManualMonitorId;
                    callback = _pendingManualCallback;
                    applyGamma = _pendingManualApplyGamma;
                    _pendingManual = null;
                    _pendingManualMonitorId = null;
                    _pendingManualCallback = null;
                    _pendingManualApplyGamma = true;
                }

                if (snapshot is null)
                {
                    break;
                }

                _controller.ApplyManual(snapshot, monitorId, applyGamma);
                callback?.Invoke();
            }
        }
        finally
        {
            Interlocked.Exchange(ref _manualWorkerActive, 0);

            lock (_pendingLock)
            {
                if (_pendingManual is not null)
                {
                    ScheduleManualApply();
                }
            }
        }
    }

    private static ManualMonitorValues BuildTarget(MonitorConfiguration monitor, TimeOnly time, bool offsetEnabled)
    {
        Profile profile = monitor.ActiveProfile;

        // Uwzględnia przesunięcie czasowe slotu (Profile.TimeOffsetMinutes) - odpytuje
        // krzywe pod "przesuniętą" chwilą zamiast realnego "now". Jeśli panel "H" jest
        // wyłączony (offsetEnabled == false), przesunięcie jest pomijane - liczy się
        // tak, jakby wynosiło 0, niezależnie od zapisanej wartości.
        TimeOnly effectiveTime = profile.GetEffectiveTime(time, offsetEnabled);
        int rgb = profile.Rgb.GetValueAt(effectiveTime);
        ManualMonitorValues target = new()
        {
            Brightness = profile.Brightness.GetValueAt(effectiveTime),
            Contrast = profile.Contrast.GetValueAt(effectiveTime),
            Saturation = profile.Saturation.GetValueAt(effectiveTime),
            // Gamma nie jest powiązana z krzywymi/harmonogramem 24h w ogóle - to
            // czysto ręczne ustawienie (pigułka gammy w szybkim panelu), niezależne
            // od tego, który slot/która pora dnia jest aktywna. Automatyka po prostu
            // powtarza tu ostatnią ręcznie ustawioną wartość (cache w
            // MonitorDdcController i tak pominie zapis DDC, jeśli się nie zmieniła).
            Gamma = monitor.ManualValues.Gamma
        };
        target.SetUnifiedRgb(rgb);
        target.Clamp();
        return target;
    }

    private static ManualMonitorValues StepToward(ManualMonitorValues current, ManualMonitorValues target)
    {
        ManualMonitorValues next = current.Clone();
        next.Brightness = StepValue(current.Brightness, target.Brightness, BrightnessStep);
        next.Contrast = StepValue(current.Contrast, target.Contrast, ContrastStep);
        next.Saturation = StepValue(current.Saturation, target.Saturation, SaturationStep);
        next.Red = StepValue(current.Red, target.Red, RgbStep);
        next.Green = StepValue(current.Green, target.Green, RgbStep);
        next.Blue = StepValue(current.Blue, target.Blue, RgbStep);
        // Gamma jest dyskretna (5 kroków co 0.2) - pośrednie wartości nie mają sensu,
        // więc w przeciwieństwie do reszty przeskakuje od razu na docelową wartość,
        // zamiast stopniowo "dojeżdżać" jak jasność/kontrast/RGB.
        next.Gamma = target.Gamma;
        next.Clamp();
        return next;
    }

    private static int StepValue(int current, int target, int step)
    {
        if (current == target)
        {
            return current;
        }

        return current < target
            ? Math.Min(target, current + step)
            : Math.Max(target, current - step);
    }

    /// <summary>
    /// Ustawia WYŁĄCZNIE gammę (pigułka gammy w szybkim panelu). Przy szybkim
    /// przewijaniu scrolla każde "kliknięcie" wywołuje tę metodę osobno - gdyby
    /// każde z nich osobno odpalało własny Task.Run, przy naprawdę szybkim DDC/I2C
    /// (każdy zapis to ok. kilkadziesiąt ms) kolejność ich WYKONANIA na wątkach z
    /// puli NIE jest gwarantowana taka sama jak kolejność wywołań - starsza wartość
    /// mogła "dojechać" do monitora PO nowszej, więc finalnie na ekranie zostawała
    /// wartość sprzed ostatniego kroku, mimo że GUI już pokazywało najnowszą.
    /// Zamiast tego: jeden, pojedynczy worker w tle, ZAWSZE bierze NAJŚWIEŻSZĄ
    /// żądaną wartość z _pendingGamma (nadpisywaną przy każdym wywołaniu) - żadne
    /// pośrednie przewinięcie nie ginie bezpowrotnie (worker sprawdza ponownie po
    /// każdym zapisie), a finalna wartość zastosowana na monitorze zawsze będzie
    /// tą ostatnią zażądaną - bez dodawania sztucznego opóźnienia do pierwszego
    /// przewinięcia.
    /// </summary>
    public void ApplyGammaOnly(double gamma, AppSettings settings, Action? onCompleted = null)
    {
        string? monitorId = settings.Monitors.Count > 1 ? settings.ActiveMonitor.MonitorId : null;

        lock (_pendingLock)
        {
            _pendingGamma = gamma;
            _pendingGammaMonitorId = monitorId;
            _pendingGammaCallback = onCompleted;
        }

        ScheduleGammaApply();
    }

    private void ScheduleGammaApply()
    {
        if (Interlocked.CompareExchange(ref _gammaWorkerActive, 1, 0) != 0)
        {
            return;
        }

        Task.Run(ProcessGammaQueue);
    }

    private void ProcessGammaQueue()
    {
        try
        {
            while (true)
            {
                double? gamma;
                string? monitorId;
                Action? callback;

                lock (_pendingLock)
                {
                    gamma = _pendingGamma;
                    monitorId = _pendingGammaMonitorId;
                    callback = _pendingGammaCallback;
                    _pendingGamma = null;
                    _pendingGammaMonitorId = null;
                    _pendingGammaCallback = null;
                }

                if (gamma is not { } value)
                {
                    break;
                }

                _controller.ApplyGammaOnly(value, monitorId);
                callback?.Invoke();
            }
        }
        finally
        {
            Interlocked.Exchange(ref _gammaWorkerActive, 0);

            lock (_pendingLock)
            {
                if (_pendingGamma is not null)
                {
                    ScheduleGammaApply();
                }
            }
        }
    }

    private static void RunOnBackground(Action action)
    {
        Task.Run(action);
    }
}
