using System.Runtime.InteropServices;

namespace LightSter;

internal static class TrayIconRenderer
{
    public static Icon CreateBrightnessIcon(int brightness, bool appEnabled)
    {
        using Bitmap bitmap = new(16, 16, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using Graphics graphics = Graphics.FromImage(bitmap);
        graphics.Clear(Color.Transparent);
        graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

        // The tray icon glyph is always a bold black "0" - it no longer reflects the
        // live brightness value (that's still shown in the tooltip text below).
        const string label = "0";
        using Font font = new("Segoe UI", 6.5f, FontStyle.Bold, GraphicsUnit.Point);
        SizeF size = graphics.MeasureString(label, font);
        using SolidBrush textBrush = new(Color.Black);
        graphics.DrawString(
            label,
            font,
            textBrush,
            (16f - size.Width) / 2f,
            (16f - size.Height) / 2f - 0.5f);

        IntPtr handle = bitmap.GetHicon();
        using Icon temporary = Icon.FromHandle(handle);
        Icon cloned = (Icon)temporary.Clone();
        DestroyIcon(handle);
        return cloned;
    }

    /// <summary>
    /// Jak <see cref="CreateBrightnessIcon"/>, tylko zamiast "0" pokazuje napis
    /// "HDR" albo "SDR" - używane, gdy AppSettings.ShowHdrStatusIconInTray jest
    /// włączone.
    /// </summary>
    public static Icon CreateModeIcon(bool hdrActive, bool appEnabled)
    {
        using Bitmap bitmap = new(16, 16, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using Graphics graphics = Graphics.FromImage(bitmap);
        graphics.Clear(Color.Transparent);
        graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

        string label = hdrActive ? "HDR" : "SDR";

        // Zaczynamy od dwa razy większego rozmiaru niż poprzednio (4.5 -> 9) i w
        // razie potrzeby zmniejszamy, aż napis zmieści się w 16x16 ikonce - dzięki
        // temu jest maksymalnie duży/czytelny, ale nigdy nie zostaje przycięty.
        float fontSize = 9f;
        Font font = new("Segoe UI", fontSize, FontStyle.Bold, GraphicsUnit.Point);
        SizeF size = graphics.MeasureString(label, font);
        while (size.Width > 15f && fontSize > 4.5f)
        {
            font.Dispose();
            fontSize -= 0.5f;
            font = new Font("Segoe UI", fontSize, FontStyle.Bold, GraphicsUnit.Point);
            size = graphics.MeasureString(label, font);
        }

        using (font)
        {
            using SolidBrush textBrush = new(Color.Black);
            graphics.DrawString(
                label,
                font,
                textBrush,
                (16f - size.Width) / 2f,
                (16f - size.Height) / 2f - 0.5f);
        }

        IntPtr handle = bitmap.GetHicon();
        using Icon temporary = Icon.FromHandle(handle);
        Icon cloned = (Icon)temporary.Clone();
        DestroyIcon(handle);
        return cloned;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool DestroyIcon(IntPtr hIcon);
}
