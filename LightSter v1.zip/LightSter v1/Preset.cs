namespace LightSter;

internal sealed class Preset
{
    public string Name { get; set; } = "Preset";
    public int Brightness { get; set; } = 50;
    public int Contrast { get; set; } = 70;
    public int Saturation { get; set; } = 50;
    public int Rgb { get; set; } = 50;

    /// <summary>
    /// Gamma tego presetu ręcznego - jedna z 5 wartości obsługiwanych przez DDC/CI
    /// (1.8/2.0/2.2/2.4/2.6), albo null dla "None" (preset nie wpływa na gammę).
    /// </summary>
    public double? Gamma { get; set; }

    /// <summary>
    /// Migracja starych zapisanych wartości RGB 0-255 na nową skalę 0-100.
    /// </summary>
    public void MigrateRgbScaleIfNeeded()
    {
        if (Rgb > 100)
        {
            Rgb = (int)Math.Round(Math.Clamp(Rgb, 0, 255) / 255.0 * 100);
        }
    }

    public void Clamp()
    {
        Brightness = Math.Clamp(Brightness, 0, 100);
        Contrast = Math.Clamp(Contrast, 0, 100);
        Saturation = Math.Clamp(Saturation, 0, 100);
        Rgb = Math.Clamp(Rgb, 0, 100);
        Gamma = GammaSteps.Snap(Gamma);
    }
}
