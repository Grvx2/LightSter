@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist "app\LightSter.exe" goto run

echo Budowanie LightSter...
dotnet build -c Release
if errorlevel 1 (
    echo.
    echo Blad budowania. Upewnij sie, ze masz zainstalowany .NET 8 SDK.
    echo Pobierz: https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

:run
start "" "%~dp0app\LightSter.exe"
