namespace LightSter;

internal sealed class TrayApplicationContext : ApplicationContext
{
    private readonly AppSettings _settings;
    private readonly MonitorDdcController _monitorController = new();
    private readonly SmoothMonitorApplier _applier = new();
    private readonly NotifyIcon _notifyIcon = new();
    private readonly System.Windows.Forms.Timer _timer = new();
    private readonly MainForm _mainForm;
    private readonly QuickAdjustForm _quickAdjustForm;
    private readonly TrayPopupMenu _trayMenu = new();
    private Icon? _currentIcon;
    private bool? _lastRenderedHdrState;

    public TrayApplicationContext()
    {
        _settings = AppSettings.Load();
        _settings.SyncMonitors(_monitorController.GetMonitors());
        _settings.AutostartEnabled = AutostartManager.IsEnabled();
        _settings.Save();

        _mainForm = new MainForm(_settings, _monitorController, _applier, OnSettingsChanged);
        _quickAdjustForm = new QuickAdjustForm(
            _settings,
            _applier,
            UpdateTrayIcon,
            OnAutomationChanged);

        _trayMenu.SetTrayProximityCheck(IsCursorNearTray);
        _quickAdjustForm.SetTrayProximityCheck(IsCursorNearTray);

        ConfigureTrayIcon();
        ConfigureTimer();

        _mainForm.FormClosing += (_, e) =>
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                _mainForm.Hide();
            }
        };

        ApplyStartupMode();
    }

    private void ConfigureTrayIcon()
    {
        UpdateTrayIcon();
        // Celowo bez _notifyIcon.Text - użytkownik nie chce dymka z nazwą "LightSter"
        // po najechaniu na samą ikonkę w zasobniku systemowym.
        _notifyIcon.Visible = true;
        _notifyIcon.MouseUp += OnTrayMouseUp;
    }

    private void ConfigureTimer()
    {
        _timer.Interval = 1000;
        _timer.Tick += (_, _) =>
        {
            _applier.TickAutomation(_settings, UpdateTrayIcon);

            // Ikonka HDR/SDR ma pokazywać AKTUALNY tryb Windows niezależnie od tego,
            // czy zmienił się przez środkowy klik LightStera, przez Ustawienia
            // Windows, czy skrótem Win+Alt+B - więc co sekundę porównujemy realny
            // stan z tym, co ostatnio narysowaliśmy, i odświeżamy w razie różnicy.
            if (_settings.ShowHdrStatusIconInTray && HdrController.IsEnabled() != _lastRenderedHdrState)
            {
                UpdateTrayIcon();
            }
        };
        _timer.Start();
    }

    private void ApplyStartupMode()
    {
        if (_settings.AutomationEnabled)
        {
            _applier.ForceAutomationSync(_settings, UpdateTrayIcon);
        }
        else
        {
            _applier.ApplyManualNow(_settings, UpdateTrayIcon);
        }
    }

    private void OnTrayMouseUp(object? sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            if (_quickAdjustForm.Visible)
            {
                _quickAdjustForm.HidePanel();
                return;
            }

            // Zamykamy drugie okno *jawnie i natychmiast*, zanim pokażemy to.
            // Nie polegamy tu na Deactivate/timerze (te działają z opóźnieniem
            // rzędu setek ms, a przy szybkim przełączaniu między ikonami dawało
            // to okno, w którym oba panele bywały otwarte jednocześnie).
            _trayMenu.HideMenu();

            _quickAdjustForm.RefreshFromSettings();
            _quickAdjustForm.ShowNearTray();
            return;
        }

        if (e.Button == MouseButtons.Right)
        {
            ShowTrayMenu();
            return;
        }

        if (e.Button == MouseButtons.Middle)
        {
            HdrController.Toggle();
            UpdateTrayIcon();
        }
    }

    private void ShowTrayMenu()
    {
        // Jak wyżej - jawne, natychmiastowe zamknięcie panelu lewego kliknięcia,
        // żeby oba okna nigdy nie były otwarte jednocześnie, niezależnie od
        // tego, kiedy zadziała jego własny timer/Deactivate.
        _quickAdjustForm.HidePanel();

        List<TrayMenuEntry> entries = [];

        if (_settings.Presets.Count == 0)
        {
            entries.Add(new TrayMenuEntry { Text = "(brak presetów)", Enabled = false });
        }
        else
        {
            foreach (Preset preset in _settings.Presets)
            {
                Preset captured = preset;
                entries.Add(new TrayMenuEntry
                {
                    Text = captured.Name,
                    Action = () => ApplyPreset(captured)
                });
            }
        }

        entries.Add(TrayMenuEntry.Separator());
        entries.Add(new TrayMenuEntry { Text = "Krzywe", Action = ShowCurvesWindow });
        entries.Add(TrayMenuEntry.Separator());
        entries.Add(new TrayMenuEntry
        {
            IsCurveSlotBar = true,
            CurveSlotCount = _settings.CurveSlotCount,
            ActiveCurveSlot = _settings.ActiveMonitor.ActiveCurveSlot,
            SlotAction = SwitchCurveSlot,
            SlotNames = _settings.ActiveMonitor.CurveSlots.Select(profile => profile.Name).ToList()
        });
        entries.Add(TrayMenuEntry.Separator());
        entries.Add(new TrayMenuEntry { Text = "Zamknij", Action = ExitApplication });

        _trayMenu.SetItems(entries);
        _trayMenu.ShowNearTray(Cursor.Position);
    }

    private void SwitchCurveSlot(int slot)
    {
        _settings.ActiveMonitor.ActiveCurveSlot = slot;
        _settings.Save();
        OnSettingsChanged();

        if (_mainForm.Visible)
        {
            _mainForm.RefreshFromSettings();
        }

        if (_settings.AutomationEnabled)
        {
            _applier.ForceAutomationSync(_settings, () =>
            {
                UpdateTrayIcon();
                if (_quickAdjustForm.Visible)
                {
                    _quickAdjustForm.BeginInvoke(_quickAdjustForm.RefreshFromSettings);
                }
            });
        }
        else
        {
            UpdateTrayIcon();
            if (_quickAdjustForm.Visible)
            {
                _quickAdjustForm.BeginInvoke(_quickAdjustForm.RefreshFromSettings);
            }
        }
    }

    private void ShowCurvesWindow()
    {
        _mainForm.RefreshFromSettings();
        _mainForm.Show();
        _mainForm.WindowState = FormWindowState.Normal;
        _mainForm.Activate();
    }

    private void ApplyPreset(Preset preset)
    {
        if (!_settings.AppEnabled)
        {
            return;
        }

        _applier.ApplyPresetNow(preset, _settings, () =>
        {
            foreach (MonitorConfiguration monitor in _settings.Monitors)
            {
                monitor.ManualValues.Brightness = preset.Brightness;
                monitor.ManualValues.Contrast = preset.Contrast;
                monitor.ManualValues.Saturation = preset.Saturation;
                monitor.ManualValues.SetUnifiedRgb(preset.Rgb);
            }

            _settings.ManualValues.CopyFrom(_settings.ActiveMonitor.ManualValues);
            _settings.Save();
            if (_quickAdjustForm.Visible)
            {
                _quickAdjustForm.BeginInvoke(_quickAdjustForm.RefreshFromSettings);
            }

            UpdateTrayIcon();
        });
    }

    private void OnAutomationChanged(bool enabled)
    {
        if (enabled)
        {
            _applier.ForceAutomationSync(_settings, UpdateTrayIcon);
        }
        else
        {
            _applier.ApplyManualNow(_settings, UpdateTrayIcon);
        }
    }

    private void OnSettingsChanged()
    {
        UpdateTrayIcon();
        if (_quickAdjustForm.IsDisposed)
        {
            return;
        }

        _quickAdjustForm.BeginInvoke(_quickAdjustForm.RefreshFromSettings);
    }

    private void UpdateTrayIcon()
    {
        if (_mainForm.InvokeRequired)
        {
            _mainForm.BeginInvoke(UpdateTrayIcon);
            return;
        }

        int brightness = _settings.ActiveMonitor.ManualValues.Brightness;
        SetTrayIcon(brightness, _settings.AppEnabled);

        _applier.ReadBrightness(read =>
        {
            if (_mainForm.IsDisposed)
            {
                return;
            }

            _mainForm.BeginInvoke(() =>
            {
                if (!_settings.AutomationEnabled)
                {
                    return;
                }

                _settings.ActiveMonitor.ManualValues.Brightness = read;
                _settings.ManualValues.Brightness = read;
                SetTrayIcon(read, _settings.AppEnabled);
            });
        });
    }

    private void SetTrayIcon(int brightness, bool appEnabled)
    {
        bool hdrActive = HdrController.IsEnabled();
        Icon nextIcon = _settings.ShowHdrStatusIconInTray
            ? TrayIconRenderer.CreateModeIcon(hdrActive, appEnabled)
            : TrayIconRenderer.CreateBrightnessIcon(brightness, appEnabled);
        _lastRenderedHdrState = hdrActive;
        if (_currentIcon is not null)
        {
            _notifyIcon.Icon = nextIcon;
            _currentIcon.Dispose();
        }
        else
        {
            _notifyIcon.Icon = nextIcon;
        }

        _currentIcon = nextIcon;
    }

    private bool IsCursorNearTray()
    {
        Rectangle workArea = Screen.PrimaryScreen?.WorkingArea ?? Rectangle.Empty;
        Point cursor = Cursor.Position;
        return cursor.Y >= workArea.Bottom - 48 && cursor.X >= workArea.Right - 320;
    }

    private void ExitApplication()
    {
        _timer.Stop();
        _notifyIcon.Visible = false;
        _currentIcon?.Dispose();
        _notifyIcon.Dispose();
        _trayMenu.Close();
        _quickAdjustForm.Close();
        _mainForm.Close();
        ExitThread();
    }
}
