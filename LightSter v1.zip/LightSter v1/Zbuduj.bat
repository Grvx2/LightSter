@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Budowanie LightSter do folderu app\...
dotnet build -c Release
if errorlevel 1 (
    echo.
    echo Blad budowania.
    pause
    exit /b 1
)

echo.
echo Gotowe: %~dp0app\LightSter.exe
pause
