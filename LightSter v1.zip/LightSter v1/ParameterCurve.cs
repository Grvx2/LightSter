namespace LightSter;

internal sealed class ParameterCurve
{
    public List<CurvePoint> Points { get; set; } = [];
    public int MaxValue { get; set; } = 100;

    public int GetValueAt(TimeOnly time)
    {
        Normalize();

        if (Points.Count == 0)
        {
            return MaxValue / 2;
        }

        if (Points.Count == 1)
        {
            return Points[0].Value;
        }

        int minute = time.Hour * 60 + time.Minute;
        CurvePoint? previous = null;
        CurvePoint? next = null;

        foreach (CurvePoint point in Points)
        {
            if (point.Minute <= minute)
            {
                previous = point;
            }

            if (point.Minute >= minute)
            {
                next = point;
                break;
            }
        }

        previous ??= Points[^1];
        next ??= Points[0];

        if (previous.Minute == next.Minute)
        {
            return previous.Value;
        }

        int previousMinute = previous.Minute;
        int nextMinute = next.Minute;
        int currentMinute = minute;

        if (nextMinute < previousMinute)
        {
            nextMinute += 1440;
        }

        if (currentMinute < previousMinute)
        {
            currentMinute += 1440;
        }

        double amount = (currentMinute - previousMinute) / (double)(nextMinute - previousMinute);
        return (int)Math.Round(previous.Value + (next.Value - previous.Value) * amount);
    }

    public void Normalize()
    {
        Points = Points
            .Select(point => new CurvePoint(point.Minute, point.Value, MaxValue))
            .GroupBy(point => point.Minute)
            .Select(group => group.Last())
            .OrderBy(point => point.Minute)
            .ToList();
    }

    public static ParameterCurve Default(int value, int maxValue = 100)
    {
        return new ParameterCurve
        {
            MaxValue = maxValue,
            Points =
            [
                new CurvePoint(0, value, maxValue),
                new CurvePoint(8 * 60, value, maxValue),
                new CurvePoint(18 * 60, value, maxValue),
                new CurvePoint(23 * 60, value, maxValue)
            ]
        };
    }

    public static ParameterCurve CreateDefaultForParameter(ParameterKind kind) => kind switch
    {
        ParameterKind.Brightness => Default(40, 100),
        ParameterKind.Contrast => Default(50, 100),
        ParameterKind.Saturation => Default(50, 100),
        ParameterKind.Rgb => Default(50, 100),
        _ => Default(50, 100)
    };

    /// <summary>
    /// Krzywa z jednym, pojedynczym punktem o godz. 12:00 - używana jako
    /// wartość domyślna nowo dodawanego slotu.
    /// </summary>
    public static ParameterCurve SinglePointNoon(int value, int maxValue = 100)
    {
        return new ParameterCurve
        {
            MaxValue = maxValue,
            Points = [new CurvePoint(12 * 60, value, maxValue)]
        };
    }

    public static ParameterCurve CreateNewSlotDefaultForParameter(ParameterKind kind) => kind switch
    {
        ParameterKind.Brightness => SinglePointNoon(40, 100),
        ParameterKind.Contrast => SinglePointNoon(50, 100),
        ParameterKind.Saturation => SinglePointNoon(50, 100),
        ParameterKind.Rgb => SinglePointNoon(100, 100),
        _ => SinglePointNoon(50, 100)
    };
}
