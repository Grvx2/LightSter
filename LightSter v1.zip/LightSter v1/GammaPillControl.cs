namespace LightSter;

/// <summary>
/// Subtelna "pigułka" (pozioma kapsuła z zaokrąglonymi rogami) pokazująca obecną
/// ręcznie ustawioną gammę (1.8-2.6) w szybkim panelu. Sama nie nasłuchuje scrolla -
/// robi to QuickAdjustForm.WndProc, tak samo jak dla reszty suwaków w tym oknie -
/// tylko rysuje siebie i wystawia Value/ValueChanged.
/// </summary>
internal sealed class GammaPillControl : Control
{
    private double _value = 2.2;

    public double Value
    {
        get => _value;
        set
        {
            double snapped = GammaSteps.Snap(value) ?? 2.2;
            if (Math.Abs(snapped - _value) < 0.01)
            {
                return;
            }

            _value = snapped;
            Invalidate();
            ValueChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    public event EventHandler? ValueChanged;

    public GammaPillControl()
    {
        SetStyle(
            ControlStyles.AllPaintingInWmPaint
            | ControlStyles.UserPaint
            | ControlStyles.OptimizedDoubleBuffer
            | ControlStyles.ResizeRedraw,
            true);
        Size = new Size(34, 18);
        Cursor = Cursors.Hand;
        // Tło jednolite, dopasowane do reszty paska (zamiast próby prawdziwej
        // przezroczystości) - poprzednia wersja pomijała malowanie tła całkowicie,
        // co potrafiło zostawić nieodświeżone/przypadkowe piksele w buforze i dawać
        // wrażenie "nachodzenia" na sąsiednie kontrolki. Ten kolor jest zawsze taki
        // sam jak tło paska, więc pełne, zwykłe malowanie tła wygląda identycznie
        // jak przezroczystość, bez ryzyka artefaktów.
        BackColor = Color.FromArgb(34, 38, 44);
    }

    /// <summary>
    /// Krok bez zawijania: na krańcach (1.8 albo 2.6) dalszy scroll w tym samym
    /// kierunku nic już nie zmienia, zamiast przeskakiwać na drugi koniec.
    /// </summary>
    public void StepByWheel(int wheelDelta)
    {
        int direction = wheelDelta > 0 ? 1 : -1;
        Value = GammaSteps.Step(_value, direction);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        Rectangle bounds = new(0, 0, Width - 1, Height - 1);
        using System.Drawing.Drawing2D.GraphicsPath path = RoundedCapsulePath(bounds);
        using SolidBrush fill = new(Color.FromArgb(40, 255, 255, 255));
        using Pen border = new(Color.FromArgb(64, 255, 255, 255));
        e.Graphics.FillPath(fill, path);
        e.Graphics.DrawPath(border, path);

        string text = _value.ToString("0.0");
        using Font font = new("Segoe UI", 7.5f, FontStyle.Bold);
        using SolidBrush textBrush = new(Color.FromArgb(210, 214, 220));
        SizeF textSize = e.Graphics.MeasureString(text, font);
        e.Graphics.DrawString(
            text,
            font,
            textBrush,
            (Width - textSize.Width) / 2,
            (Height - textSize.Height) / 2);
    }

    private static System.Drawing.Drawing2D.GraphicsPath RoundedCapsulePath(Rectangle bounds)
    {
        int radius = bounds.Height;
        System.Drawing.Drawing2D.GraphicsPath path = new();
        path.AddArc(bounds.X, bounds.Y, radius, bounds.Height, 90, 180);
        path.AddArc(bounds.Right - radius, bounds.Y, radius, bounds.Height, -90, 180);
        path.CloseFigure();
        return path;
    }
}
