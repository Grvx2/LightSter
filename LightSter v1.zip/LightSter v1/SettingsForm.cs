namespace LightSter;

/// <summary>
/// Okno "Ustawienia" otwierane z panelu Krzywych (przycisk, który zastąpił
/// dawny checkbox "Automatyczne krzywe"). Wszystkie zmiany tu stosują się i
/// zapisują natychmiast (nie ma Cofnij/Anuluj), tak samo jak reszta interfejsu
/// LightStera.
/// </summary>
internal sealed class SettingsForm : Form
{
    private const int RowHeight = 28;

    private readonly AppSettings _settings;
    private readonly CheckBox _autostartCheckBox = new();
    private readonly CheckBox _hdrTrayIconCheckBox = new();

    private readonly RadioButton _offsetKeepOnManualToggle = new();
    private readonly RadioButton _offsetResetOnManualToggle = new();

    private readonly RadioButton _hReenableAfterAutomation = new();
    private readonly RadioButton _hStayOffAfterAutomation = new();

    private readonly Panel _guzik3Panel = new();
    private readonly RadioButton _offsetKeepWhenReenabled = new();
    private readonly RadioButton _offsetResetWhenReenabled = new();

    private bool _syncing;

    public SettingsForm(AppSettings settings)
    {
        _settings = settings;

        Text = "LightSter - Ustawienia";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        Font = new Font("Segoe UI", 9.5f);
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        Padding = new Padding(16);
        BackColor = Color.FromArgb(243, 244, 246);

        BuildLayout();
        LoadValues();
        WireEvents();
    }

    private void BuildLayout()
    {
        FlowLayoutPanel root = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false
        };
        Controls.Add(root);

        _autostartCheckBox.Text = "Autostart";
        _autostartCheckBox.AutoSize = true;
        _autostartCheckBox.Height = RowHeight;
        _autostartCheckBox.Margin = new Padding(0, 0, 0, 12);
        root.Controls.Add(_autostartCheckBox);

        _hdrTrayIconCheckBox.Text = "HDR/SDR ICO";
        _hdrTrayIconCheckBox.AutoSize = true;
        _hdrTrayIconCheckBox.Height = RowHeight;
        _hdrTrayIconCheckBox.Margin = new Padding(0, 0, 0, 16);
        root.Controls.Add(_hdrTrayIconCheckBox);

        root.Controls.Add(MakeSubLabel("Po wyłączeniu H"));
        root.Controls.Add(MakeRadioGroup(
            _offsetResetOnManualToggle, "Resetuj",
            _offsetKeepOnManualToggle, "Zapamiętaj"));

        root.Controls.Add(MakeSubLabel("Po wyłączeniu krzywych"));
        root.Controls.Add(MakeRadioGroup(
            _hReenableAfterAutomation, "Włącz H spowrotem",
            _hStayOffAfterAutomation, "Wyłącz"));

        _guzik3Panel.AutoSize = true;
        _guzik3Panel.Margin = new Padding(0);
        FlowLayoutPanel guzik3Flow = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0)
        };
        _guzik3Panel.Controls.Add(guzik3Flow);
        guzik3Flow.Controls.Add(MakeSubLabel("Oraz"));
        guzik3Flow.Controls.Add(MakeRadioGroup(
            _offsetResetWhenReenabled, "Resetuj",
            _offsetKeepWhenReenabled, "Zapamiętaj"));
        root.Controls.Add(_guzik3Panel);

        Button closeButton = new()
        {
            Text = "Zamknij",
            AutoSize = true,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(0, 16, 0, 0)
        };
        closeButton.Click += (_, _) => Close();
        root.Controls.Add(closeButton);
    }

    private static Label MakeSubLabel(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
        Margin = new Padding(0, 4, 0, 4)
    };

    private static FlowLayoutPanel MakeRadioGroup(
        RadioButton first, string firstText,
        RadioButton second, string secondText)
    {
        first.Text = firstText;
        first.AutoSize = true;
        first.Margin = new Padding(16, 0, 0, 0);

        second.Text = secondText;
        second.AutoSize = true;
        second.Margin = new Padding(16, 4, 0, 0);

        FlowLayoutPanel panel = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0, 0, 0, 4)
        };
        panel.Controls.Add(first);
        panel.Controls.Add(second);
        return panel;
    }

    private void LoadValues()
    {
        _syncing = true;

        _autostartCheckBox.Checked = _settings.AutostartEnabled;
        _hdrTrayIconCheckBox.Checked = _settings.ShowHdrStatusIconInTray;

        _offsetResetOnManualToggle.Checked = _settings.ResetOffsetOnManualHToggle;
        _offsetKeepOnManualToggle.Checked = !_settings.ResetOffsetOnManualHToggle;

        _hReenableAfterAutomation.Checked = _settings.ReenableHAfterAutomationResume;
        _hStayOffAfterAutomation.Checked = !_settings.ReenableHAfterAutomationResume;

        _offsetResetWhenReenabled.Checked = _settings.ResetOffsetWhenHReenabledByAutomation;
        _offsetKeepWhenReenabled.Checked = !_settings.ResetOffsetWhenHReenabledByAutomation;

        _guzik3Panel.Visible = _settings.ReenableHAfterAutomationResume;

        _syncing = false;
    }

    private void WireEvents()
    {
        _autostartCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            _settings.AutostartEnabled = _autostartCheckBox.Checked;
            AutostartManager.SetEnabled(_settings.AutostartEnabled);
            Save();
        };

        _hdrTrayIconCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            _settings.ShowHdrStatusIconInTray = _hdrTrayIconCheckBox.Checked;
            Save();
        };

        _offsetResetOnManualToggle.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetResetOnManualToggle.Checked)
            {
                return;
            }

            _settings.ResetOffsetOnManualHToggle = true;
            Save();
        };

        _offsetKeepOnManualToggle.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetKeepOnManualToggle.Checked)
            {
                return;
            }

            _settings.ResetOffsetOnManualHToggle = false;
            Save();
        };

        _hReenableAfterAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_hReenableAfterAutomation.Checked)
            {
                return;
            }

            _settings.ReenableHAfterAutomationResume = true;
            _guzik3Panel.Visible = true;
            Save();
        };

        _hStayOffAfterAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_hStayOffAfterAutomation.Checked)
            {
                return;
            }

            _settings.ReenableHAfterAutomationResume = false;
            _guzik3Panel.Visible = false;
            Save();
        };

        _offsetResetWhenReenabled.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetResetWhenReenabled.Checked)
            {
                return;
            }

            _settings.ResetOffsetWhenHReenabledByAutomation = true;
            Save();
        };

        _offsetKeepWhenReenabled.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetKeepWhenReenabled.Checked)
            {
                return;
            }

            _settings.ResetOffsetWhenHReenabledByAutomation = false;
            Save();
        };
    }

    private void Save()
    {
        try
        {
            _settings.Save();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                $"Nie zapisano ustawień: {ex.Message}",
                "LightSter",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}
