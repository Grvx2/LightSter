namespace LightSter;

internal sealed class ManualMonitorValues
{
    public int Brightness { get; set; } = 50;
    public int Contrast { get; set; } = 70;
    public int Saturation { get; set; } = 50;
    public int Red { get; set; } = 50;
    public int Green { get; set; } = 50;
    public int Blue { get; set; } = 50;

    /// <summary>
    /// Ręcznie ustawiona gamma (pigułka gammy w szybkim panelu) - w pełni ręczna,
    /// niezależna od krzywych/automatyki i od tego, który slot jest aktywny.
    /// </summary>
    public double Gamma { get; set; } = 2.2;

    /// <summary>
    /// Migracja ze starej skali RGB 0-255 na nową 0-100: jeśli którakolwiek składowa
    /// przekracza 100, zakładamy, że to jeszcze stara skala i przeskalowujemy
    /// proporcjonalnie, zamiast pozwolić <see cref="Clamp"/> obciąć ją bezmyślnie.
    /// Wywoływane raz, przed Clamp, przy każdym wczytaniu ustawień.
    /// </summary>
    public void MigrateRgbScaleIfNeeded()
    {
        if (Red <= 100 && Green <= 100 && Blue <= 100)
        {
            return;
        }

        Red = (int)Math.Round(Math.Clamp(Red, 0, 255) / 255.0 * 100);
        Green = (int)Math.Round(Math.Clamp(Green, 0, 255) / 255.0 * 100);
        Blue = (int)Math.Round(Math.Clamp(Blue, 0, 255) / 255.0 * 100);
    }

    public void Clamp()
    {
        Brightness = Math.Clamp(Brightness, 0, 100);
        Contrast = Math.Clamp(Contrast, 0, 100);
        Saturation = Math.Clamp(Saturation, 0, 100);
        Red = Math.Clamp(Red, 0, 100);
        Green = Math.Clamp(Green, 0, 100);
        Blue = Math.Clamp(Blue, 0, 100);
        Gamma = GammaSteps.Snap(Gamma) ?? 2.2;
    }

    public int UnifiedRgb => Math.Clamp((Red + Green + Blue) / 3, 0, 100);

    public void SetUnifiedRgb(int value)
    {
        value = Math.Clamp(value, 0, 100);
        Red = value;
        Green = value;
        Blue = value;
    }

    public ManualMonitorValues Clone()
    {
        return new ManualMonitorValues
        {
            Brightness = Brightness,
            Contrast = Contrast,
            Saturation = Saturation,
            Red = Red,
            Green = Green,
            Blue = Blue,
            Gamma = Gamma
        };
    }

    public void CopyFrom(ManualMonitorValues other)
    {
        Brightness = other.Brightness;
        Contrast = other.Contrast;
        Saturation = other.Saturation;
        Red = other.Red;
        Green = other.Green;
        Blue = other.Blue;
        Gamma = other.Gamma;
    }
}
