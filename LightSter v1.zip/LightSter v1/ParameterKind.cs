namespace LightSter;

internal enum ParameterKind
{
    Brightness,
    Contrast,
    Saturation,
    Rgb
}
