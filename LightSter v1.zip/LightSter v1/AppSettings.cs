using System.Text.Json;

namespace LightSter;

internal sealed class AppSettings
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public bool AutomationEnabled { get; set; } = true;
    public bool AppEnabled { get; set; } = true;
    public bool AutostartEnabled { get; set; }
    public int ActiveMonitorIndex { get; set; }
    public List<MonitorConfiguration> Monitors { get; set; } = [];
    public List<Preset> Presets { get; set; } = [];
    public ManualMonitorValues ManualValues { get; set; } = new();
    public bool ShowIndividualRgbChannels { get; set; } = true;

    /// <summary>
    /// Stan przełącznika "H" (panel przesunięcia czasowego slotu) w oknie szybkich
    /// suwaków - zapamiętywany niezależnie od stanu przełącznika "Krzywe", tak żeby
    /// wyłączenie i włączenie z powrotem "Krzywe" przywracało poprzedni stan "H".
    /// </summary>
    public bool ShowSlotTimeOffsetPanel { get; set; }

    /// <summary>
    /// Gdy włączone, ikonka w zasobniku systemowym pokazuje "HDR"/"SDR" (aktualny
    /// tryb koloru Windows) zamiast zwykłego "0".
    /// </summary>
    public bool ShowHdrStatusIconInTray { get; set; }

    /// <summary>
    /// Guzik 1 (okno Ustawienia): po ręcznym wyłączeniu "H", a potem ponownym
    /// włączeniu - czy przesunięcie czasowe aktywnego slotu ma zostać wyzerowane
    /// (true) czy zapamiętane (false, domyślnie - zgodne z zachowaniem sprzed tej
    /// opcji).
    /// </summary>
    public bool ResetOffsetOnManualHToggle { get; set; }

    /// <summary>
    /// Guzik 2 (okno Ustawienia): jeśli automatyczne krzywe ("Krzywe") zostały
    /// wyłączone w momencie, gdy "H" było włączone - to po ponownym włączeniu
    /// automatycznych krzywych, czy "H" ma wrócić do stanu włączonego (true,
    /// domyślnie) czy zostać wyłączone (false).
    /// </summary>
    public bool ReenableHAfterAutomationResume { get; set; } = true;

    /// <summary>
    /// Guzik 3 (okno Ustawienia, widoczny tylko gdy <see cref="ReenableHAfterAutomationResume"/>
    /// jest włączone): gdy "H" wraca do stanu włączonego po wznowieniu
    /// automatycznych krzywych (patrz Guzik 2) - czy przesunięcie czasowe ma
    /// zostać wyzerowane (true) czy zapamiętane (false, domyślnie).
    /// </summary>
    public bool ResetOffsetWhenHReenabledByAutomation { get; set; }

    public static string SettingsPath
    {
        get
        {
            string directory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "LightSter");
            return Path.Combine(directory, "profiles.json");
        }
    }

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(SettingsPath))
            {
                string json = File.ReadAllText(SettingsPath);
                AppSettings? settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions);
                if (settings is not null)
                {
                    settings.MigrateLegacySettings(json);
                    settings.EnsureValid();
                    return settings;
                }
            }
        }
        catch
        {
        }

        AppSettings fallback = new();
        fallback.EnsureValid();
        return fallback;
    }

    public void Save()
    {
        EnsureValid();
        string directory = Path.GetDirectoryName(SettingsPath)!;
        Directory.CreateDirectory(directory);
        File.WriteAllText(SettingsPath, JsonSerializer.Serialize(this, JsonOptions));
    }

    public MonitorConfiguration ActiveMonitor
    {
        get
        {
            EnsureValid();
            return Monitors[ActiveMonitorIndex];
        }
    }

    public void EnsureValid()
    {
        ManualValues.MigrateRgbScaleIfNeeded();
        ManualValues.Clamp();
        foreach (Preset preset in Presets)
        {
            preset.MigrateRgbScaleIfNeeded();
            preset.Clamp();
        }

        if (Monitors.Count == 0)
        {
            Monitors.Add(MonitorConfiguration.Create("default", "Domyślny monitor", 0));
        }

        ActiveMonitorIndex = Math.Clamp(ActiveMonitorIndex, 0, Monitors.Count - 1);

        foreach (MonitorConfiguration monitor in Monitors)
        {
            monitor.MigrateLegacyProfile();
            monitor.EnsureCurveSlots();
            monitor.ActiveCurveSlot = Math.Clamp(monitor.ActiveCurveSlot, 1, monitor.CurveSlots.Count);
            monitor.ManualValues.MigrateRgbScaleIfNeeded();
            monitor.ManualValues.Clamp();
            if (monitor.DisplayNumber <= 0)
            {
                monitor.DisplayNumber = Monitors.IndexOf(monitor) + 1;
            }

            foreach (Profile profile in monitor.CurveSlots)
            {
                EnsureProfileCurves(profile);
            }
        }

        SyncCurveSlotCountsAcrossMonitors();
    }

    public int CurveSlotCount
    {
        get
        {
            EnsureValid();
            return Monitors.Count == 0 ? 3 : Monitors.Max(monitor => monitor.CurveSlots.Count);
        }
    }


    public void CopyCurveSlot(int slot)
    {
        EnsureValid();
        foreach (MonitorConfiguration monitor in Monitors)
        {
            monitor.EnsureCurveSlots();
            int index = Math.Clamp(slot, 1, monitor.CurveSlots.Count) - 1;
            Profile copy = JsonSerializer.Deserialize<Profile>(JsonSerializer.Serialize(monitor.CurveSlots[index], JsonOptions), JsonOptions)!;
            monitor.CurveSlots.Add(copy);
        }
    }

    public void MoveCurveSlot(int slot, int direction)
    {
        EnsureValid();
        foreach (MonitorConfiguration monitor in Monitors)
        {
            int from = slot - 1, to = from + direction;
            if (from < 0 || to < 0 || from >= monitor.CurveSlots.Count || to >= monitor.CurveSlots.Count) continue;
            (monitor.CurveSlots[from], monitor.CurveSlots[to]) = (monitor.CurveSlots[to], monitor.CurveSlots[from]);
        }
    }

    public void AddCurveSlot()
    {
        EnsureValid();
        int nextIndex = CurveSlotCount;
        foreach (MonitorConfiguration monitor in Monitors)
        {
            monitor.EnsureCurveSlots();
            monitor.CurveSlots.Add(Profile.CreateDefault(nextIndex));
            EnsureProfileCurves(monitor.CurveSlots[^1]);
        }
    }

    /// <summary>
    /// Usuwa wskazany slot (1-indeksowany) ze wszystkich monitorów. Jeśli slot
    /// nie zostanie podany, domyślnie usuwany jest ostatni slot (zachowanie
    /// zgodne z poprzednimi wersjami).
    /// </summary>
    public void RemoveCurveSlot(int? slot = null)
    {
        EnsureValid();
        if (CurveSlotCount <= 3)
        {
            return;
        }

        foreach (MonitorConfiguration monitor in Monitors)
        {
            monitor.EnsureCurveSlots();
            int index = slot is null
                ? monitor.CurveSlots.Count - 1
                : Math.Clamp(slot.Value, 1, monitor.CurveSlots.Count) - 1;
            monitor.CurveSlots.RemoveAt(index);
            monitor.ActiveCurveSlot = Math.Clamp(monitor.ActiveCurveSlot, 1, monitor.CurveSlots.Count);
        }
    }

    private void SyncCurveSlotCountsAcrossMonitors()
    {
        if (Monitors.Count == 0)
        {
            return;
        }

        int targetCount = Monitors.Max(monitor => monitor.CurveSlots.Count);
        targetCount = Math.Max(targetCount, 3);

        foreach (MonitorConfiguration monitor in Monitors)
        {
            monitor.EnsureCurveSlots();
            while (monitor.CurveSlots.Count < targetCount)
            {
                monitor.CurveSlots.Add(Profile.CreateDefault(monitor.CurveSlots.Count));
            }

            monitor.ActiveCurveSlot = Math.Clamp(monitor.ActiveCurveSlot, 1, monitor.CurveSlots.Count);
            foreach (Profile profile in monitor.CurveSlots)
            {
                EnsureProfileCurves(profile);
            }
        }
    }

    public void SyncMonitors(IReadOnlyList<MonitorDescriptor> detectedMonitors)
    {
        List<MonitorConfiguration> updated = [];
        HashSet<int> usedNumbers = Monitors.Select(monitor => monitor.DisplayNumber).Where(number => number > 0).ToHashSet();
        int nextNumber = 1;

        int AllocateNumber()
        {
            while (usedNumbers.Contains(nextNumber))
            {
                nextNumber++;
            }

            usedNumbers.Add(nextNumber);
            return nextNumber++;
        }

        for (int index = 0; index < detectedMonitors.Count; index++)
        {
            MonitorDescriptor descriptor = detectedMonitors[index];
            MonitorConfiguration? existing = Monitors.FirstOrDefault(
                    monitor => monitor.MonitorId == descriptor.MonitorId)
                ?? Monitors.FirstOrDefault(
                    monitor => monitor.DisplayName == descriptor.DisplayName)
                ?? (index < Monitors.Count ? Monitors[index] : null);

            if (existing is not null)
            {
                int displayNumber = existing.DisplayNumber > 0 ? existing.DisplayNumber : AllocateNumber();
                existing.EnsureCurveSlots();
                updated.Add(new MonitorConfiguration
                {
                    MonitorId = descriptor.MonitorId,
                    DisplayName = descriptor.DisplayName,
                    DisplayNumber = displayNumber,
                    ActiveCurveSlot = existing.ActiveCurveSlot,
                    ManualValues = existing.ManualValues,
                    CurveSlots = existing.CurveSlots,
                    CurveSlot1 = existing.CurveSlot1,
                    CurveSlot2 = existing.CurveSlot2,
                    CurveSlot3 = existing.CurveSlot3
                });
            }
            else
            {
                updated.Add(MonitorConfiguration.Create(
                    descriptor.MonitorId,
                    descriptor.DisplayName,
                    AllocateNumber()));
            }
        }

        if (updated.Count == 0)
        {
            updated.Add(MonitorConfiguration.Create("default", "Domyślny monitor", 0));
        }

        Monitors = updated;
        ActiveMonitorIndex = Math.Clamp(ActiveMonitorIndex, 0, Monitors.Count - 1);
    }

    private static void EnsureProfileCurves(Profile profile)
    {
        profile.Brightness.MaxValue = 100;
        profile.Contrast.MaxValue = 100;
        profile.Saturation.MaxValue = 100;

        // Migracja: RGB było kiedyś w skali 0-255, teraz jest 0-100 (część monitorów,
        // w tym ten sterowany przez DDC/CI VCP 0x16/0x18/0x1A, i tak przyjmuje tylko
        // 0-100) - jeśli istniejąca krzywa ma jeszcze starą skalę, przeskalowujemy jej
        // punkty proporcjonalnie, zamiast bezmyślnie obcinać (co zniszczyłoby
        // dotychczasowe ustawienia użytkownika, ścinając np. 200 do 100).
        if (profile.Rgb.MaxValue == 255)
        {
            foreach (CurvePoint point in profile.Rgb.Points)
            {
                point.Value = (int)Math.Round(point.Value / 255.0 * 100);
            }
        }

        profile.Rgb.MaxValue = 100;
        profile.Brightness.Normalize();
        profile.Contrast.Normalize();
        profile.Saturation.Normalize();
        profile.Rgb.Normalize();
    }

    private void MigrateLegacySettings(string json)
    {
        if (Monitors.Count > 0 || !json.Contains("\"Profiles\"", StringComparison.Ordinal))
        {
            return;
        }

        try
        {
            LegacyAppSettings? legacy = JsonSerializer.Deserialize<LegacyAppSettings>(json, JsonOptions);
            if (legacy?.Profiles is null || legacy.Profiles.Count == 0)
            {
                return;
            }

            int profileIndex = Math.Clamp(legacy.ActiveProfileIndex, 0, legacy.Profiles.Count - 1);
            Profile profile = legacy.Profiles[profileIndex];
            Monitors =
            [
                new MonitorConfiguration
                {
                    MonitorId = "default",
                    DisplayName = "Domyślny monitor",
                    CurveSlot1 = profile
                }
            ];
            AutomationEnabled = legacy.AutomationEnabled;
            ActiveMonitorIndex = 0;
        }
        catch
        {
        }
    }

    private sealed class LegacyAppSettings
    {
        public bool AutomationEnabled { get; set; }
        public int ActiveProfileIndex { get; set; }
        public List<Profile> Profiles { get; set; } = [];
    }
}
