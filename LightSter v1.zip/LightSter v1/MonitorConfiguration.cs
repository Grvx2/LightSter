namespace LightSter;

internal sealed class MonitorConfiguration
{
    public string MonitorId { get; set; } = string.Empty;
    public string DisplayName { get; set; } = "Monitor";
    public int DisplayNumber { get; set; } = 1;
    public int ActiveCurveSlot { get; set; } = 1;
    public ManualMonitorValues ManualValues { get; set; } = new();
    public List<Profile> CurveSlots { get; set; } = [];
    public Profile CurveSlot1 { get; set; } = Profile.CreateDefault(0);
    public Profile CurveSlot2 { get; set; } = Profile.CreateDefault(1);
    public Profile CurveSlot3 { get; set; } = Profile.CreateDefault(2);

    public Profile? Profile { get; set; }

    public Profile ActiveProfile
    {
        get
        {
            EnsureCurveSlots();
            int index = Math.Clamp(ActiveCurveSlot, 1, CurveSlots.Count) - 1;
            return CurveSlots[index];
        }
    }

    public void EnsureCurveSlots()
    {
        if (CurveSlots.Count >= 3)
        {
            return;
        }

        if (CurveSlots.Count == 0)
        {
            MigrateLegacyProfile();
            CurveSlots =
            [
                CurveSlot1,
                CurveSlot2,
                CurveSlot3
            ];
        }

        while (CurveSlots.Count < 3)
        {
            CurveSlots.Add(Profile.CreateDefault(CurveSlots.Count));
        }
    }

    public void SetActiveProfile(Profile profile)
    {
        EnsureCurveSlots();
        int index = Math.Clamp(ActiveCurveSlot, 1, CurveSlots.Count) - 1;
        CurveSlots[index] = profile;
    }

    public void MigrateLegacyProfile()
    {
        if (Profile is null)
        {
            return;
        }

        CurveSlot1 = Profile;
        Profile = null;
    }

    public static MonitorConfiguration Create(string monitorId, string displayName, int displayNumber)
    {
        return new MonitorConfiguration
        {
            MonitorId = monitorId,
            DisplayName = displayName,
            DisplayNumber = displayNumber,
            CurveSlots =
            [
                Profile.CreateDefault(displayNumber - 1),
                Profile.CreateDefault(displayNumber),
                Profile.CreateDefault(displayNumber + 1)
            ],
            CurveSlot1 = Profile.CreateDefault(displayNumber - 1),
            CurveSlot2 = Profile.CreateDefault(displayNumber),
            CurveSlot3 = Profile.CreateDefault(displayNumber + 1)
        };
    }
}
