namespace LightSter;

internal sealed class QuickAdjustForm : Form
{
    private const int ColumnWidth = 82;
    // Wysokość wiersza z drobną liczbą pokazującą obecną wartość z krzywej,
    // widoczną NAD każdym suwakiem - ZAWSZE zarezerwowana (nawet gdy "Krzywe" jest
    // wyłączone i tekst jest po prostu pusty), żeby przełączanie automatyki nigdy
    // nie zmieniało rozmiaru okna. Jedyny suwak, przy którym okno ma się zmieniać
    // rozmiarem, to "Czas"/H (patrz _offsetColumnShouldBeVisible w CalculateWidth).
    private const int InfoLabelHeight = 15;
    private const int BaseFormHeight = 338;
    private const int MaxOffsetMinutes = 8 * 60;
    private const int OffsetWheelStepMinutes = 10;
    private const int OffsetHeaderWheelStepMinutes = 1;

    private const int HideDelayMs = 495;

    // Ile czasu ufamy zewnętrznemu sprawdzeniu "kursor jest przy zasobniku"
    // (oparte o globalną pozycję kursora). W trybie pełnoekranowym niektórych
    // gier (np. wyłączny fullscreen) globalna pozycja kursora bywa nieaktualna,
    // więc po tym czasie przestajemy jej ufać i polegamy tylko na realnym
    // najechaniu na samo okno panelu. (Ten sam mechanizm co w TrayPopupMenu.)
    private const int TrayProximityTrustMs = 6000;

    // Absolutny "wentyl bezpieczeństwa" - panel nigdy nie zostanie otwarty
    // dłużej niż tyle, niezależnie od tego, czy uda się poprawnie wykryć
    // pozycję kursora, czy nie (np. aplikacja pełnoekranowa blokująca jej
    // odczyt/aktualizację - wcześniej panel w takiej sytuacji nie zamykał się
    // wcale, bo jedynym mechanizmem zamykającym był Deactivate, który w
    // wyłącznym trybie pełnoekranowym części gier nie jest wysyłany).
    private const int MaxAutoHideMs = 7500;

    private readonly AppSettings _settings;
    private readonly SmoothMonitorApplier _applier;
    private readonly Action _onValuesApplied;
    private readonly Action<bool> _onAutomationChanged;
    private readonly System.Windows.Forms.Timer _applyDebounce = new() { Interval = 80 };
    private readonly System.Windows.Forms.Timer _offsetApplyDebounce = new() { Interval = 80 };
    private readonly System.Windows.Forms.Timer _infoTimer = new() { Interval = 1000 };
    private readonly System.Windows.Forms.Timer _hideTimer = new() { Interval = 100 };
    private DateTime _mouseLeftAt = DateTime.MinValue;
    private DateTime _shownAt = DateTime.MinValue;
    private Func<bool>? _isNearTray;
    private readonly CheckBox _automationCheckBox = new();
    private readonly CheckBox _hOffsetCheckBox = new();
    private readonly Panel _offsetColumnHost = new();

    // Control.Visible in WinForms is an *ambient* value: it returns false
    // whenever any ancestor (here: this whole form, while Hidden) is not
    // currently visible - regardless of what was just assigned to it. We
    // compute the window width (CalculateWidth) before calling Show() when
    // reopening the panel, so reading _offsetColumnHost.Visible at that point
    // would always report false even when the "Czas" column is about to be
    // shown, giving a too-narrow window that clips the RGB column. This flag
    // tracks the intended state directly, unaffected by the form's own
    // visibility, so layout sizing is always correct even before Show().
    private bool _offsetColumnShouldBeVisible;

    private readonly Panel _offsetHeader = new();
    private readonly VerticalValueSlider _offsetSlider = new();
    private readonly Label _offsetValueLabel = new();
    private readonly ToolTip _hOffsetToolTip = new();
    private readonly FlowLayoutPanel _topBar = new();
    private readonly Panel _topBarHost = new();
    private readonly FlowLayoutPanel _monitorButtonsPanel = new();
    private readonly Label _freezeToManualButton = new();
    private readonly GammaPillControl _gammaPill = new();
    private readonly Panel _hWrapper = new();
    private readonly FlowLayoutPanel _slidersPanel = new();
    private readonly List<SliderColumn> _columns = [];
    private SliderColumn _brightnessColumn = null!;
    private SliderColumn _contrastColumn = null!;
    private SliderColumn _saturationColumn = null!;

    // RGB: jeden host o STAŁEJ szerokości (dokładnie tyle, co jedna zwykła
    // kolumna), wewnątrz którego przełączamy widoczność między widokiem "razem"
    // (jeden suwak RGB) a "osobno" (R/G/B obok siebie) - dzięki temu okno NIGDY
    // nie zmienia rozmiaru przy przełączaniu trybu (patrz ToggleRgbMode).
    private readonly Panel _rgbHost = new();
    private readonly Panel _rgbCombinedView = new() { Dock = DockStyle.Fill };
    private readonly Panel _rgbIndividualView = new() { Dock = DockStyle.Fill, Visible = false };
    private SliderColumn _rgbMasterColumn = null!;
    private SliderColumn _redColumn = null!;
    private SliderColumn _greenColumn = null!;
    private SliderColumn _blueColumn = null!;

    private readonly Dictionary<int, MonitorBadge> _monitorButtons = [];
    private bool _syncing;

    // Do Guzik 2/3 z okna Ustawień: gdy "Krzywe" wyłączają się (ręcznie albo
    // automatycznie, patrz DisableAutomationIfNeeded), zapamiętujemy tu, czy "H"
    // było wtedy włączone - tylko w takim przypadku ma w ogóle sens pytanie "czy H
    // ma wrócić po wznowieniu automatyki".
    private bool _hWasOnWhenAutomationDisabled;

    public QuickAdjustForm(
        AppSettings settings,
        SmoothMonitorApplier applier,
        Action onValuesApplied,
        Action<bool> onAutomationChanged)
    {
        _settings = settings;
        _applier = applier;
        _onValuesApplied = onValuesApplied;
        _onAutomationChanged = onAutomationChanged;

        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        BackColor = Color.FromArgb(34, 38, 44);
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 9f);
        Padding = new Padding(6, 8, 6, 8);
        SetStyle(
            ControlStyles.AllPaintingInWmPaint
            | ControlStyles.UserPaint
            | ControlStyles.OptimizedDoubleBuffer,
            true);

        BuildLayout();
        RebuildMonitorButtons();
        LoadValues();
        WireEvents();
        UpdateLayoutSize();
        Deactivate += (_, _) =>
        {
            if (_mouseLeftAt == DateTime.MinValue)
            {
                _mouseLeftAt = DateTime.UtcNow;
            }
        };
        _applyDebounce.Tick += (_, _) => FlushApply();
        _offsetApplyDebounce.Tick += (_, _) => FlushOffsetApply();
        _infoTimer.Tick += (_, _) => UpdateAutomationInfoLabel();
        _hideTimer.Tick += (_, _) => CheckAutoHide();
    }

    public void SetTrayProximityCheck(Func<bool> isNearTray)
    {
        _isNearTray = isNearTray;
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        base.OnMouseEnter(e);
        _mouseLeftAt = DateTime.MinValue;
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        if (!ClientRectangle.Contains(PointToClient(Cursor.Position)))
        {
            _mouseLeftAt = DateTime.UtcNow;
        }
    }

    private void CheckAutoHide()
    {
        double elapsedSinceShown = (DateTime.UtcNow - _shownAt).TotalMilliseconds;

        // Przez pierwsze kilka sekund ufamy sprawdzeniu "kursor przy zasobniku"
        // (oparte o globalną pozycję kursora - zwykle działa dobrze).
        bool trustTrayProximity = elapsedSinceShown < TrayProximityTrustMs;
        if (trustTrayProximity && _isNearTray?.Invoke() == true)
        {
            _mouseLeftAt = DateTime.MinValue;
            return;
        }

        Point cursor = PointToClient(Cursor.Position);
        if (ClientRectangle.Contains(cursor))
        {
            _mouseLeftAt = DateTime.MinValue;
            return;
        }

        if (_mouseLeftAt == DateTime.MinValue)
        {
            _mouseLeftAt = DateTime.UtcNow;
        }

        bool hoverGraceExpired = (DateTime.UtcNow - _mouseLeftAt).TotalMilliseconds >= HideDelayMs;

        // Jeśli z jakiegokolwiek powodu (np. aplikacja pełnoekranowa blokująca
        // odczyt pozycji kursora, albo Deactivate w ogóle nie przychodzi w
        // wyłącznym trybie pełnoekranowym) nie da się wiarygodnie ustalić, czy
        // kursor znajduje się na oknie, to i tak chowamy panel po max. ok. 5s.
        bool hardTimeoutExpired = elapsedSinceShown >= MaxAutoHideMs;

        if (hoverGraceExpired || hardTimeoutExpired)
        {
            HidePanel();
        }
    }

    public void HidePanel()
    {
        _hideTimer.Stop();
        _infoTimer.Stop();
        Hide();
    }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x00000080;

            // WS_EX_COMPOSITED: każe systemowi rysować całe okno (i wszystkie jego
            // kontrolki-dzieci) do jednego bufora naraz zamiast każdą z osobna, co
            // znacznie ogranicza migotanie przy zmianie rozmiaru okna (np. przy
            // włączaniu/wyłączaniu "H"/"Czas", jedynym momencie, kiedy okno faktycznie
            // zmienia rozmiar).
            cp.ExStyle |= 0x02000000;
            return cp;
        }
    }

    public void ShowNearTray()
    {
        RebuildMonitorButtons();
        LoadValues();
        UpdateLayoutSize();
        PositionNearTray();
        if (!Visible)
        {
            Show();
        }

        Activate();
        UpdateWindowRegion();
        UpdateAutomationInfoLabel();
        if (_settings.AutomationEnabled)
        {
            _infoTimer.Start();
        }

        _hideTimer.Start();
        _mouseLeftAt = DateTime.MinValue;
        _shownAt = DateTime.UtcNow;
    }

    public void RefreshFromSettings()
    {
        RebuildMonitorButtons();
        LoadValues();
        UpdateLayoutSize();
        UpdateAutomationInfoLabel();
    }

    protected override void WndProc(ref Message m)
    {
        const int WM_MOUSEWHEEL = 0x020A;
        if (m.Msg == WM_MOUSEWHEEL)
        {
            int delta = (short)((m.WParam.ToInt64() >> 16) & 0xFFFF);
            Point screenPoint = Cursor.Position;

            // Pigułka gammy: scroll działa niezależnie od "Krzywe"/automatyki -
            // gamma nie jest w ogóle powiązana z krzywymi, więc to zawsze czysto
            // ręczne ustawienie.
            Rectangle gammaPillBounds = _gammaPill.RectangleToScreen(_gammaPill.ClientRectangle);
            if (gammaPillBounds.Contains(screenPoint))
            {
                _gammaPill.StepByWheel(delta);
                m.Result = IntPtr.Zero;
                return;
            }

            VerticalValueSlider? slider = FindSliderAtPoint(screenPoint);
            if (slider is not null)
            {
                slider.AdjustByWheel(delta);
                m.Result = IntPtr.Zero;
                return;
            }

            // Scrolling over the "Czas" caption/value label nudges the slot time
            // offset by exactly +/-1 minute per notch - finer than the slider's own
            // 20-minute wheel grid, for precise adjustments.
            if (_offsetColumnHost.Visible)
            {
                Rectangle offsetHeaderBounds = _offsetHeader.RectangleToScreen(_offsetHeader.ClientRectangle);
                if (offsetHeaderBounds.Contains(screenPoint))
                {
                    _offsetSlider.AdjustByWheelStep(delta, OffsetHeaderWheelStepMinutes);
                    m.Result = IntPtr.Zero;
                    return;
                }
            }

            // Scrolling over the caption/value label above a slider nudges that
            // column by exactly +/-1 per notch - a finer, always-uniform alternative
            // to the slider's own (usually coarser) wheel grid.
            SliderColumn? headerColumn = FindHeaderColumnAtPoint(screenPoint);
            if (headerColumn is not null)
            {
                headerColumn.Slider.AdjustByWheelStep(delta, 1);
                m.Result = IntPtr.Zero;
                return;
            }
        }

        base.WndProc(ref m);
    }

    private VerticalValueSlider? FindSliderAtPoint(Point screenPoint)
    {
        if (_offsetColumnHost.Visible)
        {
            Rectangle offsetBounds = _offsetSlider.RectangleToScreen(_offsetSlider.ClientRectangle);
            if (offsetBounds.Contains(screenPoint))
            {
                return _offsetSlider;
            }
        }

        foreach (SliderColumn column in _columns)
        {
            if (!column.Host.Visible)
            {
                continue;
            }

            Rectangle bounds = column.Slider.RectangleToScreen(column.Slider.ClientRectangle);
            if (bounds.Contains(screenPoint))
            {
                return column.Slider;
            }
        }

        return null;
    }

    private SliderColumn? FindHeaderColumnAtPoint(Point screenPoint)
    {
        foreach (SliderColumn column in _columns)
        {
            if (!column.Host.Visible)
            {
                continue;
            }

            Rectangle bounds = column.Header.RectangleToScreen(column.Header.ClientRectangle);
            if (bounds.Contains(screenPoint))
            {
                return column;
            }
        }

        return null;
    }

    private void BuildLayout()
    {
        TableLayoutPanel root = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        _topBarHost.Dock = DockStyle.Fill;

        _topBar.Dock = DockStyle.Fill;
        _topBar.FlowDirection = FlowDirection.LeftToRight;
        _topBar.WrapContents = false;
        _topBar.Padding = new Padding(0, 4, 0, 0);

        _automationCheckBox.Text = "Krzywe";
        _automationCheckBox.ForeColor = Color.White;
        _automationCheckBox.AutoSize = true;
        _automationCheckBox.Checked = _settings.AutomationEnabled;

        _hOffsetCheckBox.Text = "H";
        _hOffsetCheckBox.ForeColor = Color.White;
        _hOffsetCheckBox.AutoSize = true;
        _hOffsetCheckBox.Checked = _settings.ShowSlotTimeOffsetPanel;
        _hOffsetToolTip.SetToolTip(
            _hOffsetCheckBox,
            "Panel przesunięcia czasowego aktywnego slotu (+/-8h).");

        _hOffsetToolTip.SetToolTip(_gammaPill, "Gamma (DDC) - scroll, żeby zmienić.");

        // Subtelny "+": zamraża obecnie wyliczoną z krzywych wartość (uwzględniając
        // przesunięcie czasowe, jeśli panel "H" jest włączony) do suwaków ręcznych i
        // wyłącza automatykę. Widoczny tylko, gdy "Krzywe" jest włączone - bo tylko
        // wtedy ma to jakiekolwiek zastosowanie. Celowo bardzo słabo kontrastowy w
        // spoczynku (żeby nie rzucał się w oczy) i wyraźniejszy pod kursorem.
        _freezeToManualButton.Text = "+";
        _freezeToManualButton.AutoSize = true;
        _freezeToManualButton.Font = new Font("Segoe UI", 13f, FontStyle.Regular);
        _freezeToManualButton.Padding = new Padding(0);
        _freezeToManualButton.Cursor = Cursors.Hand;
        _freezeToManualButton.ForeColor = Color.FromArgb(70, 255, 255, 255);
        _freezeToManualButton.Visible = _settings.AutomationEnabled;
        _freezeToManualButton.MouseEnter += (_, _) => _freezeToManualButton.ForeColor = Color.FromArgb(220, 255, 255, 255);
        _freezeToManualButton.MouseLeave += (_, _) => _freezeToManualButton.ForeColor = Color.FromArgb(70, 255, 255, 255);
        _freezeToManualButton.Click += (_, _) => FreezeCurveValuesToManual();

        // "Krzywe", "H", pigułka gammy i "+" mają różne wysokości (checkboxy z
        // tekstem, ręcznie rysowana pigułka, pogrubiony znak "+" w większej
        // czcionce). Poprzednia wersja owijała w ten sposób TYLKO "H"/gammę/plusa,
        // a "Krzywe" zostawiła na starym, osobnym systemie (Margin.Top) - przez co
        // zamiast się ujednolicić, doszła NOWA niespójność między "Krzywe" a resztą.
        // Teraz WSZYSTKIE CZTERY przechodzą przez dokładnie ten sam mechanizm:
        // każdy dostaje własny Panel o tej samej wysokości rzędu (maksimum z
        // PreferredSize wszystkich czterech, żeby żaden się nie ucinał), a sam
        // element jest w nim ręcznie wyśrodkowany przez Location - jedna, spójna
        // linia dla całego paska.
        int rowHeight = Math.Max(
            Math.Max(_automationCheckBox.PreferredSize.Height, _hOffsetCheckBox.PreferredSize.Height),
            Math.Max(_gammaPill.PreferredSize.Height, _freezeToManualButton.PreferredSize.Height));

        Panel krzyweWrapper = CenterInFixedHeightPanel(_automationCheckBox, rowHeight);
        krzyweWrapper.Margin = new Padding(0, 2, 14, 0);
        FillCenteredInFixedHeightPanel(_hWrapper, _hOffsetCheckBox, rowHeight);
        _hWrapper.Margin = new Padding(0, 2, 8, 0);
        Panel gammaWrapper = CenterInFixedHeightPanel(_gammaPill, rowHeight);
        gammaWrapper.Margin = new Padding(0, 2, 8, 0);
        Panel plusWrapper = CenterInFixedHeightPanel(_freezeToManualButton, rowHeight);
        plusWrapper.Margin = new Padding(0, 2, 10, 0);

        _topBar.Controls.Add(krzyweWrapper);

        _topBar.Controls.Add(_hWrapper);
        _topBar.Controls.Add(gammaWrapper);
        _topBar.Controls.Add(plusWrapper);

        _monitorButtonsPanel.FlowDirection = FlowDirection.LeftToRight;
        _monitorButtonsPanel.WrapContents = false;
        _monitorButtonsPanel.AutoSize = true;
        _monitorButtonsPanel.Dock = DockStyle.Right;
        _monitorButtonsPanel.Margin = new Padding(0);
        _monitorButtonsPanel.Padding = new Padding(0, 4, 0, 0);

        // Dock.Fill control goes in first, then the Dock.Right control is added on
        // top of it - WinForms then carves the monitor-badge column out of the right
        // edge of the host and lets the flow panel fill the remaining space, so "1"
        // (or "1 2 3...") always sits flush against the window's right edge instead
        // of merely trailing after the checkboxes/plus at whatever width they take.
        _topBarHost.Controls.Add(_topBar);
        _topBarHost.Controls.Add(_monitorButtonsPanel);
        root.Controls.Add(_topBarHost, 0, 0);

        _slidersPanel.Dock = DockStyle.Fill;
        _slidersPanel.FlowDirection = FlowDirection.LeftToRight;
        _slidersPanel.WrapContents = false;
        _slidersPanel.AutoScroll = false;
        _slidersPanel.Padding = new Padding(0, 4, 0, 0);

        // Numbers shown next to each slider (click to jump straight to that value).
        int[] percentLabels10 = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

        // The four "combined" columns have fewer stops (11) than the R/G/B channel
        // strips (14), so there's extra vertical room to show their numbers bigger.
        const float CombinedLabelFontSize = 11f;

        BuildOffsetColumn(_slidersPanel);

        _brightnessColumn = AddSliderColumn(_slidersPanel, "Jasność", Color.FromArgb(255, 196, 64), 0, 100, percentLabels10, 5,
            v => ActiveValues.Brightness = v, () => ActiveValues.Brightness, labelFontSize: CombinedLabelFontSize);
        _columns.Add(_brightnessColumn);
        _contrastColumn = AddSliderColumn(_slidersPanel, "Kontrast", Color.FromArgb(220, 224, 230), 0, 100, percentLabels10, 2,
            v => ActiveValues.Contrast = v, () => ActiveValues.Contrast, labelFontSize: CombinedLabelFontSize);
        _columns.Add(_contrastColumn);
        _saturationColumn = AddSliderColumn(_slidersPanel, "Saturacja", Color.FromArgb(88, 176, 255), 0, 100, percentLabels10, 2,
            v => ActiveValues.Saturation = v, () => ActiveValues.Saturation, labelFontSize: CombinedLabelFontSize);
        _columns.Add(_saturationColumn);

        BuildRgbHost(_slidersPanel, percentLabels10, CombinedLabelFontSize);

        root.Controls.Add(_slidersPanel, 0, 1);
    }

    /// <summary>
    /// RGB: host o stałej szerokości (tyle co jedna zwykła kolumna) zawierający
    /// DWA nakładające się widoki - "razem" (jeden suwak 0-100) i "osobno" (R/G/B
    /// obok siebie, węższe, bez paska liczb, krok scrolla zawsze co 1) - między
    /// którymi przełącza się podwójnym kliknięciem na podpis, bez zmiany rozmiaru
    /// okna, bo host sam nigdy nie zmienia rozmiaru, zmienia się tylko to, co jest
    /// w nim akurat widoczne.
    /// </summary>
    /// <summary>
    /// Owija kontrolkę w mały Panel o stałej wysokości (rowHeight), z kontrolką
    /// ręcznie ustawioną na środku przez Location - żadnego auto-sizingu,
    /// żadnego polegania na tym, że WinForms poprawnie policzy PreferredSize przy
    /// pierwszym układzie (co zawodziło przy TableLayoutPanel zagnieżdżonym w
    /// FlowLayoutPanel - patrz historia zmian w BuildLayout). Gwarantowane,
    /// przewidywalne wyśrodkowanie w pionie.
    /// </summary>
    private static Panel CenterInFixedHeightPanel(Control control, int rowHeight)
    {
        Panel wrapper = new();
        FillCenteredInFixedHeightPanel(wrapper, control, rowHeight);
        return wrapper;
    }

    /// <summary>
    /// Jak <see cref="CenterInFixedHeightPanel"/>, ale wypełnia JUŻ ISTNIEJĄCY panel
    /// zamiast tworzyć nowy - potrzebne dla "H", którego cały wrapper musi dać się
    /// chować/pokazywać jako pole (patrz UpdateOffsetVisibility: gdy "Krzywe" jest
    /// wyłączone, "H" znika, a bez schowania też jego wrappera zostawało po nim
    /// puste miejsce, przez co pigułka gammy "dziwnie wisiała" oddzielona od reszty).
    /// </summary>
    private static void FillCenteredInFixedHeightPanel(Panel wrapper, Control control, int rowHeight)
    {
        control.Anchor = AnchorStyles.None;
        Size preferred = control.PreferredSize;
        int width = preferred.Width > 0 ? preferred.Width : control.Width;
        int height = preferred.Height > 0 ? preferred.Height : control.Height;

        wrapper.Width = width;
        wrapper.Height = rowHeight;
        control.Location = new Point(0, Math.Max(0, (rowHeight - height) / 2));
        wrapper.Controls.Add(control);
    }

    private void BuildRgbHost(Panel panel, int[] percentLabels10, float combinedLabelFontSize)
    {
        _rgbHost.Width = ColumnWidth;
        _rgbHost.Height = 250;
        _rgbHost.Margin = new Padding(0, 0, 4, 0);
        panel.Controls.Add(_rgbHost);

        Panel combinedView = _rgbCombinedView;
        _rgbHost.Controls.Add(combinedView);
        _rgbMasterColumn = AddSliderColumn(combinedView, "RGB", Color.FromArgb(150, 154, 160), 0, 100, percentLabels10, 5,
            v => ActiveValues.SetUnifiedRgb(v), () => ActiveValues.UnifiedRgb, isRgbMaster: true,
            labelFontSize: combinedLabelFontSize, dockFill: true);
        _columns.Add(_rgbMasterColumn);
        WireRgbToggle(_rgbMasterColumn.Header, showIndividual: true);

        Panel individualView = _rgbIndividualView;
        _rgbHost.Controls.Add(individualView);

        FlowLayoutPanel individualFlow = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false
        };
        individualView.Controls.Add(individualFlow);

        // Pełnowysokościowe suwaki (tyle co _rgbHost, BEZ odejmowania miejsca na duży
        // wspólny nagłówek jak w poprzedniej wersji - to właśnie skracało je i
        // psuło proporcje ruchu kciuka, robiąc wrażenie, że "suwak zaczyna się
        // dopiero od ~70%"). Każdy ma mały, WŁASNY licznik wartości nad sobą - bez
        // osobnej nazwy/podpisu (kolor już rozróżnia R/G/B, podpis tekstowy tylko
        // zabierałby miejsce w 26px kolumnie). Krok scrolla zawsze 1, bez paska
        // liczb po bokach.
        const int individualColumnWidth = 26;
        _redColumn = AddBareChannelSlider(individualFlow, Color.FromArgb(232, 72, 72), individualColumnWidth,
            2, v => ActiveValues.Red = v, () => ActiveValues.Red);
        _columns.Add(_redColumn);
        _greenColumn = AddBareChannelSlider(individualFlow, Color.FromArgb(72, 196, 104), individualColumnWidth,
            2, v => ActiveValues.Green = v, () => ActiveValues.Green);
        _columns.Add(_greenColumn);
        _blueColumn = AddBareChannelSlider(individualFlow, Color.FromArgb(72, 132, 232), individualColumnWidth,
            0, v => ActiveValues.Blue = v, () => ActiveValues.Blue);
        _columns.Add(_blueColumn);

        // Podwójny klik gdziekolwiek w tym widoku wraca do "razem" (nie ma tu już
        // jednego wspólnego nagłówka do podczepienia się pod niego, więc łapiemy to
        // na całym widoku i na każdym suwaku z osobna).
        individualView.DoubleClick += (_, _) => SetRgbMode(false);
        individualFlow.DoubleClick += (_, _) => SetRgbMode(false);
        foreach (SliderColumn channel in new[] { _redColumn, _greenColumn, _blueColumn })
        {
            channel.Host.DoubleClick += (_, _) => SetRgbMode(false);
            channel.ValueLabel.DoubleClick += (_, _) => SetRgbMode(false);
        }

        ApplyRgbModeVisibility();
    }

    /// <summary>
    /// Buduje pełnowysokościowy, "goły" suwak kanału RGB z własnym, kompaktowym
    /// licznikiem wartości (ale bez podpisu/nazwy i bez informacji z krzywej - te są
    /// zbędne w tak wąskiej kolumnie i tylko powodowały nachodzenie). Opakowany w
    /// SliderColumn dla spójności z resztą mechanizmów (hit-testing scrolla,
    /// OnColumnChanged, zamrażanie do ręcznego trybu itd.) - InfoLabel istnieje
    /// tylko jako niewidoczny placeholder (Height=0), żeby nie trzeba było specjalnie
    /// omijać go w UpdateAutomationInfoLabel.
    /// </summary>
    private static SliderColumn AddBareChannelSlider(
        FlowLayoutPanel panel,
        Color trackColor,
        int width,
        int rightMargin,
        Action<int> applyValue,
        Func<int> readValue)
    {
        Panel column = new()
        {
            Width = width,
            Height = 250,
            Margin = new Padding(0, 0, rightMargin, 0)
        };

        Label valueLabel = new()
        {
            Dock = DockStyle.Top,
            Height = 18,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 8f, FontStyle.Bold)
        };

        Label hiddenInfoLabel = new() { Height = 0, Visible = false, Text = string.Empty };

        VerticalValueSlider slider = new()
        {
            Dock = DockStyle.Fill,
            Minimum = 0,
            Maximum = 100,
            TrackColor = trackColor,
            WheelStep = 1
        };

        column.Controls.Add(slider);
        column.Controls.Add(valueLabel);
        panel.Controls.Add(column);

        return new SliderColumn(
            column, slider, null, valueLabel, column, hiddenInfoLabel, applyValue, readValue,
            isRgbMaster: false, isRgbChannel: true);
    }

    /// <summary>
    /// Podwójny klik na nagłówek "RGB" (razem) przełącza na "osobno"; podwójny klik
    /// na nagłówek R, G albo B przełącza z powrotem na "razem".
    /// </summary>
    private void WireRgbToggle(Panel header, bool showIndividual)
    {
        header.DoubleClick += (_, _) => SetRgbMode(showIndividual);
        foreach (Control child in header.Controls)
        {
            child.DoubleClick += (_, _) => SetRgbMode(showIndividual);
        }
    }

    private void SetRgbMode(bool showIndividual)
    {
        if (_settings.ShowIndividualRgbChannels == showIndividual)
        {
            return;
        }

        _settings.ShowIndividualRgbChannels = showIndividual;
        _settings.Save();
        ApplyRgbModeVisibility();
    }

    private void ApplyRgbModeVisibility()
    {
        bool individual = _settings.ShowIndividualRgbChannels;
        _rgbCombinedView.Visible = !individual;
        _rgbIndividualView.Visible = individual;

        // Suwaki w niewidocznym widoku i tak trzymają swoją wartość zsynchronizowaną
        // (patrz OnColumnChanged/LoadValues) - to przełącza WYŁĄCZNIE widoczność,
        // celowo NIGDY nie zmienia rozmiaru _rgbHost, więc okno się nie rusza.
    }

    /// <summary>
    /// Buduje kolumnę suwaka "H" (przesunięcie czasowe aktywnego slotu, +/-8h), ustawianą
    /// na lewo od "Jasność". W przeciwieństwie do <see cref="AddSliderColumn"/> nie
    /// trafia do <c>_columns</c>/pipeline'u ManualValues - to osobne ustawienie profilu,
    /// niezależne od ręcznych wartości i nie wyłączające automatyzacji przy zmianie.
    /// </summary>
    private void BuildOffsetColumn(FlowLayoutPanel panel)
    {
        _offsetColumnHost.Width = ColumnWidth;
        _offsetColumnHost.Height = 250;
        _offsetColumnHost.Margin = new Padding(0, 0, 4, 0);
        _offsetColumnHost.Visible = false;

        Panel header = _offsetHeader;
        header.Dock = DockStyle.Top;
        header.Height = 42 + InfoLabelHeight;
        header.Padding = new Padding(90 - ColumnWidth, 0, 0, 0);

        // Pusty placeholder tej samej wysokości co drobna liczba z krzywej nad
        // pozostałymi suwakami (patrz AddSliderColumn/InfoLabelHeight) - dla "Czas"
        // nie ma czego tam pokazać, ale musi zostać zarezerwowane to samo miejsce,
        // żeby nagłówki wszystkich kolumn zaczynały się na tej samej wysokości.
        Label infoSpacer = new()
        {
            Dock = DockStyle.Top,
            Height = InfoLabelHeight,
            Text = string.Empty
        };

        Label caption = new()
        {
            Text = "Czas",
            Dock = DockStyle.Top,
            Height = 20,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(214, 218, 224)
        };

        _offsetValueLabel.Dock = DockStyle.Top;
        _offsetValueLabel.Height = 22;
        _offsetValueLabel.TextAlign = ContentAlignment.MiddleCenter;
        _offsetValueLabel.ForeColor = Color.White;
        _offsetValueLabel.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
        _offsetValueLabel.Text = "0:00";

        header.Controls.Add(_offsetValueLabel);
        header.Controls.Add(caption);
        header.Controls.Add(infoSpacer);

        // Niezawodny, zawsze dostępny sposób wyzerowania przesunięcia: podwójne
        // kliknięcie na etykietę wartości albo na napis "Czas" ustawia dokładnie 0,
        // niezależnie od tego, co suwak akurat pokazuje - na wypadek jakiegokolwiek
        // rozjazdu między tym, co widać, a tym, co faktycznie jest zapisane.
        _hOffsetToolTip.SetToolTip(_offsetValueLabel, "Podwójny klik: wyzeruj przesunięcie.");
        _hOffsetToolTip.SetToolTip(caption, "Podwójny klik: wyzeruj przesunięcie.");
        _offsetValueLabel.DoubleClick += (_, _) => ResetOffsetToZero();
        caption.DoubleClick += (_, _) => ResetOffsetToZero();

        Panel body = new()
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(0, 4, 0, 0)
        };

        // Pusty panel o tej samej szerokości co ValueClickStrip w innych kolumnach -
        // wyłącznie po to, żeby suwak wyrównał się wizualnie z resztą (patrz komentarz
        // w AddSliderColumn o wyliczeniu Padding nagłówka).
        Panel alignmentSpacer = new()
        {
            Dock = DockStyle.Left,
            Width = 24
        };

        _offsetSlider.Dock = DockStyle.Fill;
        _offsetSlider.Minimum = -MaxOffsetMinutes;
        _offsetSlider.Maximum = MaxOffsetMinutes;
        _offsetSlider.TrackColor = Color.FromArgb(178, 128, 255);
        _offsetSlider.WheelStep = OffsetWheelStepMinutes;
        _offsetSlider.Value = 0;

        body.Controls.Add(_offsetSlider);
        body.Controls.Add(alignmentSpacer);
        _offsetColumnHost.Controls.Add(body);
        _offsetColumnHost.Controls.Add(header);
        panel.Controls.Add(_offsetColumnHost);
    }

    private void WireEvents()
    {
        foreach (SliderColumn column in _columns)
        {
            column.Slider.ValuePreview += (_, _) => UpdateColumnLabel(column);
            column.Slider.ValueChanged += (_, _) => OnColumnChanged(column);
            if (column.ClickStrip is { } strip)
            {
                strip.ValueSelected += (_, _) =>
                {
                    if (column.Slider.Value == strip.Value)
                    {
                        // VerticalValueSlider.Value pomija ValueChanged, gdy nowa
                        // wartość jest identyczna z obecną - ale użytkownik i tak
                        // świadomie kliknął tę liczbę, więc mimo braku zmiany
                        // wartości traktujemy to tak samo: wyłączamy automatykę i
                        // wymuszamy ponowne zastosowanie na monitorze.
                        ApplyColumnValue(column, strip.Value);
                    }
                    else
                    {
                        column.Slider.Value = strip.Value;
                    }
                };
            }
        }

        _automationCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            bool turnedOn = _automationCheckBox.Checked;

            if (!turnedOn)
            {
                // Automatyka się wyłącza (ręcznie albo programowo - patrz
                // DisableAutomationIfNeeded) - zapamiętaj, czy "H" było w tym
                // momencie włączone. Dopiero to decyduje, czy przy wznowieniu
                // automatyki w ogóle warto stosować Guzik 2/3 z okna Ustawień.
                _hWasOnWhenAutomationDisabled = _hOffsetCheckBox.Checked;
            }

            bool applyHResume = turnedOn && _hWasOnWhenAutomationDisabled;
            if (applyHResume)
            {
                // Ustalamy docelowy stan "H" (Guzik 2) PRZED jedynym poniższym
                // wywołaniem UpdateOffsetVisibility/UpdateLayoutSize - inaczej kolumna
                // offsetu na moment pokazywała się (ze starym stanem "H"), żeby zaraz
                // potem zniknąć, co wyglądało jak mignięcie.
                bool reenableH = _settings.ReenableHAfterAutomationResume;
                _syncing = true;
                _hOffsetCheckBox.Checked = reenableH;
                _syncing = false;
                _settings.ShowSlotTimeOffsetPanel = reenableH;
                _hWasOnWhenAutomationDisabled = false;
            }

            _settings.AutomationEnabled = turnedOn;
            _settings.Save();
            _onAutomationChanged(turnedOn);
            UpdateAutomationInfoLabel();
            UpdateOffsetVisibility();
            UpdateLayoutSize(reposition: true);
            if (turnedOn)
            {
                _infoTimer.Start();

                // Guzik 3: jeśli "H" wróciło do stanu włączonego (patrz wyżej), to
                // ewentualnie zeruje przesunięcie. To już nie rusza widoczności/
                // rozmiaru okna (to już ustawione powyżej), więc nie ma ryzyka
                // kolejnego mignięcia.
                if (applyHResume
                    && _settings.ReenableHAfterAutomationResume
                    && _settings.ResetOffsetWhenHReenabledByAutomation)
                {
                    ResetOffsetToZero();
                }
            }
            else
            {
                _infoTimer.Stop();
            }
        };

        _hOffsetCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            bool turnedOn = _hOffsetCheckBox.Checked;
            _settings.ShowSlotTimeOffsetPanel = turnedOn;
            _settings.Save();
            UpdateOffsetVisibility();
            UpdateAutomationInfoLabel();
            UpdateLayoutSize(reposition: true);

            // Guzik 1 (okno Ustawienia): po ręcznym włączeniu "H" z powrotem,
            // ewentualnie zeruje przesunięcie zamiast zostawiać poprzednią wartość.
            if (turnedOn && _settings.ResetOffsetOnManualHToggle)
            {
                // ResetOffsetToZero() sam zapisuje i wymusza ponowne zastosowanie
                // (patrz FlushOffsetApply), więc pomijamy wywołanie poniżej - to by
                // je tylko zdublowało.
                ResetOffsetToZero();
            }
            else if (_settings.AutomationEnabled)
            {
                // Tak jak przy zmianie samej wartości przesunięcia (FlushOffsetApply) -
                // włączenie/wyłączenie "H" natychmiast zmienia, czy przesunięcie w ogóle
                // się liczy, więc od razu wymuszamy ponowne zastosowanie na monitorze
                // zamiast czekać do 60s na kolejny tick automatyki.
                _applier.ForceAutomationSync(_settings, _onValuesApplied);
            }
        };

        _offsetSlider.ValuePreview += (_, _) => UpdateOffsetValueLabel();
        _offsetSlider.ValueChanged += (_, _) => OnOffsetChanged();

        // Gamma jest w pełni ręczna, niezależna od "Krzywe"/automatyki - scroll na
        // pigułce od razu zapisuje i wysyła WYŁĄCZNIE gammę (ApplyGammaOnly), nie
        // ruszając jasności/kontrastu/saturacji/RGB, więc nie "walczy" z tym, co akurat
        // stosuje automatyka.
        _gammaPill.ValueChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            _settings.ActiveMonitor.ManualValues.Gamma = _gammaPill.Value;
            _settings.Save();
            _applier.ApplyGammaOnly(_gammaPill.Value, _settings);
        };
    }

    private void OnOffsetChanged()
    {
        if (_syncing)
        {
            return;
        }

        // Suwak wywołuje ValueChanged na każdym kroku przeciągania (nie tylko po
        // puszczeniu), więc zapis na dysk i ponowne zastosowanie na monitorze jest
        // debounce'owane - dokładnie tak samo, jak przy zwykłych suwakach Jasność/
        // Kontrast/Saturacja/RGB (patrz ScheduleApply/FlushApply).
        UpdateOffsetValueLabel();
        _offsetApplyDebounce.Stop();
        _offsetApplyDebounce.Start();
    }

    private void FlushOffsetApply()
    {
        _offsetApplyDebounce.Stop();
        _settings.ActiveMonitor.ActiveProfile.TimeOffsetMinutes = _offsetSlider.Value;
        _settings.Save();
        _applier.ForceAutomationSync(_settings, _onValuesApplied);
        UpdateAutomationInfoLabel();
    }

    /// <summary>
    /// Wywoływane przez podwójny klik na etykietę/nagłówek "Czas" - gwarantowany
    /// sposób ustawienia przesunięcia na dokładnie 0, niezależnie od tego, co suwak
    /// akurat wyświetla. Zapisuje i wymusza natychmiast (bez czekania na debounce),
    /// żeby efekt był widoczny od razu.
    /// </summary>
    private void ResetOffsetToZero()
    {
        _offsetApplyDebounce.Stop();
        _offsetSlider.Value = 0;
        UpdateOffsetValueLabel();
        FlushOffsetApply();
    }

    private void UpdateOffsetValueLabel()
    {
        _offsetValueLabel.Text = FormatOffset(_offsetSlider.Value);
    }

    private static string FormatOffset(int minutes)
    {
        string sign = minutes > 0 ? "+" : minutes < 0 ? "-" : "";
        int absMinutes = Math.Abs(minutes);
        int hours = absMinutes / 60;
        int remainderMinutes = absMinutes % 60;
        return $"{sign}{hours}:{remainderMinutes:D2}";
    }

    private void UpdateOffsetVisibility()
    {
        bool automationOn = _automationCheckBox.Checked;
        _hOffsetCheckBox.Visible = automationOn;
        // Chowamy CAŁY wrapper "H", nie tylko sam checkbox w środku - inaczej po
        // schowaniu checkboxa jego opakowanie (o stałej szerokości - patrz
        // FillCenteredInFixedHeightPanel) zostawało puste, a pigułka gammy "dziwnie
        // wisiała" oddzielona od "Krzywe" pustą przestrzenią zamiast się do niego
        // przysunąć.
        _hWrapper.Visible = automationOn;
        _offsetColumnShouldBeVisible = automationOn && _hOffsetCheckBox.Checked;
        _offsetColumnHost.Visible = _offsetColumnShouldBeVisible;
    }

    private void RebuildMonitorButtons()
    {
        _monitorButtonsPanel.Controls.Clear();
        _monitorButtons.Clear();

        List<MonitorConfiguration> monitors = _settings.Monitors
            .OrderBy(monitor => monitor.DisplayNumber)
            .ToList();

        foreach (MonitorConfiguration monitor in monitors)
        {
            int capturedIndex = _settings.Monitors.IndexOf(monitor);
            int capturedNumber = monitor.DisplayNumber;
            MonitorBadge badge = new()
            {
                MonitorNumber = capturedNumber,
                Margin = new Padding(0, 2, 6, 0),
                Tag = capturedIndex
            };
            badge.Selected += (_, _) => SelectMonitor(capturedIndex);
            _monitorButtons[capturedNumber] = badge;
            _monitorButtonsPanel.Controls.Add(badge);
        }

        // Z jednym monitorem selektor "1" nie ma żadnego zastosowania (nie ma
        // między czym przełączać) - graficznie zbędny, więc chowamy cały panel.
        // Jeśli kiedyś dojdzie drugi monitor, wróci automatycznie.
        _monitorButtonsPanel.Visible = monitors.Count > 1;

        UpdateMonitorButtonStyles();
    }

    private void SelectMonitor(int index)
    {
        if (_syncing || index < 0 || index >= _settings.Monitors.Count)
        {
            return;
        }

        _settings.ActiveMonitorIndex = index;
        _settings.Save();
        LoadValues();
        UpdateMonitorButtonStyles();
        UpdateAutomationInfoLabel();
    }

    private void UpdateMonitorButtonStyles()
    {
        foreach (KeyValuePair<int, MonitorBadge> entry in _monitorButtons)
        {
            bool active = entry.Value.Tag is int index && index == _settings.ActiveMonitorIndex;
            entry.Value.Active = active;
        }
    }

    private void UpdateAutomationInfoLabel()
    {
        _freezeToManualButton.Visible = _settings.AutomationEnabled;

        if (!_settings.AutomationEnabled)
        {
            _brightnessColumn.InfoLabel.Text = string.Empty;
            _contrastColumn.InfoLabel.Text = string.Empty;
            _saturationColumn.InfoLabel.Text = string.Empty;
            _rgbMasterColumn.InfoLabel.Text = string.Empty;
            _redColumn.InfoLabel.Text = string.Empty;
            return;
        }

        Profile profile = _settings.ActiveMonitor.ActiveProfile;
        TimeOnly now = TimeOnly.FromDateTime(DateTime.Now);
        TimeOnly effectiveNow = profile.GetEffectiveTime(now, _settings.ShowSlotTimeOffsetPanel);
        int brightness = profile.Brightness.GetValueAt(effectiveNow);
        int contrast = profile.Contrast.GetValueAt(effectiveNow);
        int saturation = profile.Saturation.GetValueAt(effectiveNow);
        int rgb = profile.Rgb.GetValueAt(effectiveNow);

        _brightnessColumn.InfoLabel.Text = brightness.ToString();
        _contrastColumn.InfoLabel.Text = contrast.ToString();
        _saturationColumn.InfoLabel.Text = saturation.ToString();
        _rgbMasterColumn.InfoLabel.Text = rgb.ToString();
        _redColumn.InfoLabel.Text = rgb.ToString();
    }

    private void OnColumnChanged(SliderColumn column)
    {
        if (_syncing)
        {
            return;
        }

        ApplyColumnValue(column, column.Slider.Value);
    }

    private void ApplyColumnValue(SliderColumn column, int value)
    {
        column.ApplyValue(value);

        if (column.IsRgbMaster)
        {
            _syncing = true;
            int rgb = ActiveValues.UnifiedRgb;
            foreach (SliderColumn rgbColumn in _columns.Where(item => item.IsRgbChannel))
            {
                rgbColumn.Slider.SetPreviewValue(rgb);
                UpdateColumnLabel(rgbColumn);
            }

            _syncing = false;
        }

        UpdateColumnLabel(column);
        DisableAutomationIfNeeded();
        ScheduleApply();
    }

    private void DisableAutomationIfNeeded()
    {
        if (!_settings.AutomationEnabled)
        {
            return;
        }

        _settings.AutomationEnabled = false;
        _automationCheckBox.Checked = false;
        _onAutomationChanged(false);
        UpdateAutomationInfoLabel();
        _infoTimer.Stop();
    }

    /// <summary>
    /// Odpowiada za klik w subtelny "+": bierze wartości aktualnie wyliczone z krzywych
    /// (dokładnie te same, które są pokazane w linijce nad suwakami - jasność/kontrast/
    /// saturacja/RGB - czyli już z uwzględnieniem przesunięcia czasowego, jeśli panel
    /// "H" jest włączony), przepisuje je na suwaki ręczne i wyłącza "Krzywe".
    /// </summary>
    private void FreezeCurveValuesToManual()
    {
        if (!_settings.AutomationEnabled)
        {
            return;
        }

        Profile profile = _settings.ActiveMonitor.ActiveProfile;
        TimeOnly now = TimeOnly.FromDateTime(DateTime.Now);
        TimeOnly effectiveNow = profile.GetEffectiveTime(now, _settings.ShowSlotTimeOffsetPanel);

        int brightness = profile.Brightness.GetValueAt(effectiveNow);
        int contrast = profile.Contrast.GetValueAt(effectiveNow);
        int saturation = profile.Saturation.GetValueAt(effectiveNow);
        int rgb = profile.Rgb.GetValueAt(effectiveNow);

        // Ustawiamy ActiveValues bezpośrednio (a nie tylko przez Slider.Value), bo
        // VerticalValueSlider pomija ValueChanged, gdy nowa wartość jest identyczna
        // z obecną - a wtedy poleganie wyłącznie na zdarzeniu mogłoby w rzadkim
        // przypadku (wszystkie 4 wartości akurat już zgodne) w ogóle nie wyłączyć
        // automatyki. Dzięki jawnemu ustawieniu poniżej działa to w 100% przypadków.
        ActiveValues.Brightness = brightness;
        ActiveValues.Contrast = contrast;
        ActiveValues.Saturation = saturation;
        ActiveValues.SetUnifiedRgb(rgb);
        ActiveValues.Clamp();

        _syncing = true;
        _brightnessColumn.Slider.SetPreviewValue(brightness);
        UpdateColumnLabel(_brightnessColumn);
        _contrastColumn.Slider.SetPreviewValue(contrast);
        UpdateColumnLabel(_contrastColumn);
        _saturationColumn.Slider.SetPreviewValue(saturation);
        UpdateColumnLabel(_saturationColumn);
        _rgbMasterColumn.Slider.SetPreviewValue(rgb);
        UpdateColumnLabel(_rgbMasterColumn);
        foreach (SliderColumn rgbColumn in _columns.Where(item => item.IsRgbChannel))
        {
            rgbColumn.Slider.SetPreviewValue(rgb);
            UpdateColumnLabel(rgbColumn);
        }

        _syncing = false;

        DisableAutomationIfNeeded();
        ScheduleApply();
    }

    private void ScheduleApply()
    {
        _applyDebounce.Stop();
        _applyDebounce.Start();
    }

    private void FlushApply()
    {
        _applyDebounce.Stop();
        if (!_settings.AppEnabled)
        {
            return;
        }

        _settings.ManualValues.CopyFrom(ActiveValues);
        _settings.Save();
        _applier.ApplyManualNow(_settings, _onValuesApplied);
    }

    private void LoadValues()
    {
        _syncing = true;
        foreach (SliderColumn column in _columns)
        {
            int value = column.ReadValue();
            column.Slider.Value = value;
            if (column.ClickStrip is not null)
            {
                column.ClickStrip.Value = value;
            }

            UpdateColumnLabel(column);
        }

        _automationCheckBox.Checked = _settings.AutomationEnabled;
        _hOffsetCheckBox.Checked = _settings.ShowSlotTimeOffsetPanel;
        _gammaPill.Value = _settings.ActiveMonitor.ManualValues.Gamma;
        ApplyRgbModeVisibility();
        _offsetSlider.Value = Math.Clamp(
            _settings.ActiveMonitor.ActiveProfile.TimeOffsetMinutes,
            -MaxOffsetMinutes,
            MaxOffsetMinutes);
        UpdateOffsetValueLabel();
        UpdateOffsetVisibility();
        UpdateMonitorButtonStyles();
        UpdateAutomationInfoLabel();
        _syncing = false;
    }

    private int CalculateWidth()
    {
        // Each column consumes its own width plus the 4px right margin set on the
        // column panel in AddSliderColumn - including the last one, since
        // FlowLayoutPanel counts trailing margins in its required content width too.
        // RGB always counts as exactly ONE slot regardless of combined/individual
        // mode - the RGB host has a fixed width and only its internal content
        // toggles visibility, so the window never resizes when switching modes.
        const int ColumnSlot = ColumnWidth + 4;
        int visibleColumns = 4 + (_offsetColumnShouldBeVisible ? 1 : 0);

        // Small buffer so the rounded window corners (see UpdateWindowRegion) never
        // clip the last column's content.
        const int EdgeBuffer = 6;

        return Padding.Horizontal + (visibleColumns * ColumnSlot) + EdgeBuffer;
    }

    // Wysokość jest teraz stała poza jednym wyjątkiem: kolumna "Czas"/H (patrz
    // CalculateWidth) - włączanie/wyłączanie "Krzywe" albo przełączanie RGB
    // razem/osobno NIGDY nie zmienia rozmiaru okna, bo miejsce na drobną liczbę z
    // krzywej nad każdym suwakiem jest zarezerwowane zawsze (InfoLabelHeight), a RGB
    // ma stałą szerokość niezależnie od trybu.
    private int CalculateHeight() => BaseFormHeight;

    private void UpdateLayoutSize(bool reposition = false)
    {
        int right = Right;
        int bottom = Bottom;
        int width = CalculateWidth();
        int height = CalculateHeight();
        int x = reposition ? right - width : Left;
        int y = reposition ? bottom - height : Top;

        SuspendLayout();
        // Jedno wywołanie SetBounds zamiast osobno Width/Height/Location - każda z
        // tych osobnych zmian generuje własny komunikat zmiany rozmiaru/pozycji
        // (i własny przerysowanie), co przy szybkim następowaniu po sobie widać jako
        // migotanie. WS_EX_COMPOSITED (patrz CreateParams) dodatkowo scala to w
        // jedną klatkę.
        SetBounds(x, y, width, height);
        UpdateWindowRegion();
        ResumeLayout(performLayout: true);
    }

    private void PositionNearTray()
    {
        Rectangle workArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        int width = CalculateWidth();
        int height = CalculateHeight();
        SuspendLayout();
        SetBounds(workArea.Right - width, workArea.Bottom - height, width, height);
        ResumeLayout(performLayout: true);
    }

    private void UpdateWindowRegion()
    {
        Region?.Dispose();
        Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
    }

    private void UpdateColumnLabel(SliderColumn column)
    {
        column.ValueLabel.Text = column.Slider.Value.ToString();
        if (column.ClickStrip is not null)
        {
            column.ClickStrip.Value = column.Slider.Value;
        }
    }

    private ManualMonitorValues ActiveValues => _settings.ActiveMonitor.ManualValues;

    private SliderColumn AddSliderColumn(
        Panel panel,
        string title,
        Color trackColor,
        int minimum,
        int maximum,
        int[] labelValues,
        int wheelStep,
        Action<int> applyValue,
        Func<int> readValue,
        bool isRgbMaster = false,
        bool isRgbChannel = false,
        int[]? wheelGrid = null,
        float labelFontSize = 8.5f,
        bool showClickStrip = true,
        bool dockFill = false,
        int? columnWidthOverride = null,
        int rightMargin = 4)
    {
        int columnWidth = columnWidthOverride ?? ColumnWidth;

        Panel column = new()
        {
            Height = 250
        };

        if (dockFill)
        {
            column.Dock = DockStyle.Fill;
        }
        else
        {
            column.Width = columnWidth;
            column.Margin = new Padding(0, 0, rightMargin, 0);
        }

        // The slider draws its track/thumb at a fixed offset from its own left edge
        // (see VerticalValueSlider: track starts at local x=16, is 10px wide) rather
        // than stretching across the whole control, so its true visual centre - in
        // column-relative coordinates - sits at (click strip width) + 21px, not at
        // the midpoint of the slider's full width. Padding.Left is chosen so the
        // header's centered content lands on that same x, i.e.
        // (padLeft + columnWidth) / 2 = (clickStripWidth + 21)
        // => padLeft = 2 * (clickStripWidth + 21) - columnWidth.
        // With no click strip at all, the slider fills the whole column, so its
        // centre is simply columnWidth / 2 => padLeft = 0.
        int clickStripWidth = showClickStrip ? 24 : 0;
        int headerPadLeft = showClickStrip ? Math.Max(0, 2 * (clickStripWidth + 21) - columnWidth) : 0;

        Panel header = new()
        {
            Dock = DockStyle.Top,
            Height = 42 + InfoLabelHeight,
            Padding = new Padding(headerPadLeft, 0, 0, 0)
        };

        // Drobna liczba pokazująca obecną wartość wyliczoną z krzywej (automatyki) -
        // ZAWSZE zarezerwowana wysokość, tekst bywa tylko pusty, gdy "Krzywe" jest
        // wyłączone - patrz komentarz przy InfoLabelHeight.
        Label infoLabel = new()
        {
            Dock = DockStyle.Top,
            Height = InfoLabelHeight,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(140, 148, 158),
            Font = new Font("Segoe UI", 7.5f),
            Text = string.Empty
        };

        Label caption = new()
        {
            Text = title,
            Dock = DockStyle.Top,
            Height = 20,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(214, 218, 224)
        };

        Label valueLabel = new()
        {
            Dock = DockStyle.Top,
            Height = 22,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 10f, FontStyle.Bold)
        };

        // Kolejność dodawania ma znaczenie: dla wielu dzieci Dock=Top ostatnio
        // dodane trafia najbliżej górnej krawędzi. Chcemy od góry: infoLabel,
        // caption, valueLabel - więc dodajemy w odwrotnej kolejności.
        header.Controls.Add(valueLabel);
        header.Controls.Add(caption);
        header.Controls.Add(infoLabel);

        Panel body = new()
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(0, 4, 0, 0)
        };

        ValueClickStrip? clickStrip = null;
        if (showClickStrip)
        {
            clickStrip = new ValueClickStrip
            {
                Dock = DockStyle.Left,
                Width = clickStripWidth,
                MaxFontSize = labelFontSize
            };
            clickStrip.SetValues(labelValues);
        }

        VerticalValueSlider slider = new()
        {
            Dock = DockStyle.Fill,
            Minimum = minimum,
            Maximum = maximum,
            TrackColor = trackColor
        };

        if (wheelGrid is not null)
        {
            slider.SetWheelGrid(wheelGrid);
        }
        else
        {
            slider.WheelStep = wheelStep;
        }

        body.Controls.Add(slider);
        if (clickStrip is not null)
        {
            body.Controls.Add(clickStrip);
        }

        column.Controls.Add(body);
        column.Controls.Add(header);
        panel.Controls.Add(column);

        return new SliderColumn(
            column, slider, clickStrip, valueLabel, header, infoLabel, applyValue, readValue, isRgbMaster, isRgbChannel);
    }

    [System.Runtime.InteropServices.DllImport("gdi32.dll")]
    private static extern IntPtr CreateRoundRectRgn(
        int left,
        int top,
        int right,
        int bottom,
        int widthEllipse,
        int heightEllipse);

    private sealed class SliderColumn(
        Panel host,
        VerticalValueSlider slider,
        ValueClickStrip? clickStrip,
        Label valueLabel,
        Panel header,
        Label infoLabel,
        Action<int> applyValue,
        Func<int> readValue,
        bool isRgbMaster,
        bool isRgbChannel)
    {
        public Panel Host { get; } = host;
        public VerticalValueSlider Slider { get; } = slider;
        public ValueClickStrip? ClickStrip { get; } = clickStrip;
        public Label ValueLabel { get; } = valueLabel;
        public Panel Header { get; } = header;
        public Label InfoLabel { get; } = infoLabel;
        public bool IsRgbMaster { get; } = isRgbMaster;
        public bool IsRgbChannel { get; } = isRgbChannel;

        public void ApplyValue(int value) => applyValue(value);
        public int ReadValue() => readValue();
    }
}
