using System.Drawing.Drawing2D;

namespace LightSter;

internal sealed class TimelineControl : Control
{
    private const int MaxHistorySteps = 10;

    private readonly Font _smallFont;
    private List<CurvePoint> _points = [];
    private int _selectedIndex = -1;
    private bool _dragging;
    private bool _dragChanged;
    private int _maxValue = 100;
    private bool _darkMode;

    // Kolor krzywej aktywnie edytowanej ("na wierzchu") - MainForm ustawia go na
    // kolor odpowiadający wybranemu parametrowi (jasność/kontrast/saturacja/RGB).
    private Color _activeCurveColor = Color.FromArgb(21, 87, 129);

    // Pozostałe krzywe (te, których teraz NIE edytujemy) - rysowane pod spodem,
    // przyciemnione, wyłącznie do podglądu. Nie biorą udziału w HitTest/przeciąganiu,
    // więc nie da się ich przypadkiem dotknąć bez przełączenia na nie z listy wyżej.
    private IReadOnlyList<(Color Color, IReadOnlyList<CurvePoint> Points)> _backgroundCurves = [];

    private readonly List<List<CurvePoint>> _undoStack = [];
    private readonly List<List<CurvePoint>> _redoStack = [];

    public event EventHandler? PointsChanged;
    public event EventHandler? SelectedPointChanged;

    /// <summary>
    /// Włącza ciemny motyw kolorystyczny samego wykresu (osie, siatka, opisy,
    /// krzywa). Reszta okna jest przełączana osobno przez MainForm.
    /// </summary>
    public bool DarkMode
    {
        get => _darkMode;
        set
        {
            _darkMode = value;
            BackColor = _darkMode ? Color.FromArgb(30, 31, 34) : Color.FromArgb(250, 250, 248);
            ForeColor = _darkMode ? Color.FromArgb(224, 226, 230) : Color.FromArgb(28, 31, 35);
            Invalidate();
        }
    }

    public bool CanUndo => _undoStack.Count > 0;
    public bool CanRedo => _redoStack.Count > 0;

    /// <summary>
    /// Kolor krzywej aktywnie edytowanej. Ustawiane przez MainForm zgodnie z
    /// wybranym parametrem (jasność/kontrast/saturacja/RGB mają swoje kolory).
    /// </summary>
    public Color ActiveCurveColor
    {
        get => _activeCurveColor;
        set
        {
            _activeCurveColor = value;
            Invalidate();
        }
    }

    /// <summary>
    /// Ustawia pozostałe (nieedytowane teraz) krzywe do pokazania w tle,
    /// przyciemnione i wyłącznie do podglądu - patrz komentarz przy polu
    /// _backgroundCurves. Zakłada, że wszystkie mają tę samą skalę co aktywna
    /// (MaxValue tego kontrolki) - co jest prawdą dla jasności/kontrastu/
    /// saturacji/RGB, wszystkie teraz 0-100.
    /// </summary>
    public void SetBackgroundCurves(IReadOnlyList<(Color Color, IReadOnlyList<CurvePoint> Points)> curves)
    {
        _backgroundCurves = curves;
        Invalidate();
    }

    public TimelineControl()
    {
        DoubleBuffered = true;
        BackColor = Color.FromArgb(250, 250, 248);
        ForeColor = Color.FromArgb(28, 31, 35);
        _smallFont = new Font(Font.FontFamily, 8.5f);
        Cursor = Cursors.Cross;
        MinimumSize = new Size(520, 280);
    }

    public int MaxValue
    {
        get => _maxValue;
        set
        {
            _maxValue = Math.Max(1, value);
            foreach (CurvePoint point in _points)
            {
                point.Value = Math.Clamp(point.Value, 0, _maxValue);
            }

            Invalidate();
        }
    }

    public List<CurvePoint> Points
    {
        get => _points;
        set
        {
            _points = value;
            Normalize();
            _selectedIndex = _points.Count > 0 ? 0 : -1;
            // Nowa krzywa (zmiana slotu/parametru albo ponowne otwarcie okna)
            // zaczyna z czystym buforem cofania/przywracania.
            _undoStack.Clear();
            _redoStack.Clear();
            Invalidate();
            SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    public CurvePoint? SelectedPoint =>
        _selectedIndex >= 0 && _selectedIndex < _points.Count ? _points[_selectedIndex] : null;

    public void AddPoint(int minute, int value)
    {
        PushHistorySnapshot();
        _points.Add(new CurvePoint(minute, value, _maxValue));
        Normalize();
        _selectedIndex = _points.FindIndex(point => point.Minute == Math.Clamp(minute, 0, 1439));
        PointsChanged?.Invoke(this, EventArgs.Empty);
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    public void DeleteSelectedPoint()
    {
        if (_points.Count <= 1 || SelectedPoint is null)
        {
            return;
        }

        PushHistorySnapshot();
        _points.RemoveAt(_selectedIndex);
        _selectedIndex = Math.Clamp(_selectedIndex, 0, _points.Count - 1);
        PointsChanged?.Invoke(this, EventArgs.Empty);
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    public void UpdateSelectedPoint(int minute, int value)
    {
        if (SelectedPoint is null)
        {
            return;
        }

        PushHistorySnapshot();
        SelectedPoint.Minute = Math.Clamp(minute, 0, 1439);
        SelectedPoint.Value = Math.Clamp(value, 0, _maxValue);
        Normalize();
        _selectedIndex = _points.FindIndex(point => point.Minute == Math.Clamp(minute, 0, 1439));
        PointsChanged?.Invoke(this, EventArgs.Empty);
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    /// <summary>Cofa ostatnią zmianę (Ctrl+Z). Do 10 kroków wstecz.</summary>
    public void Undo()
    {
        if (_undoStack.Count == 0)
        {
            return;
        }

        List<CurvePoint> previous = _undoStack[^1];
        _undoStack.RemoveAt(_undoStack.Count - 1);

        _redoStack.Add(ClonePoints());
        if (_redoStack.Count > MaxHistorySteps)
        {
            _redoStack.RemoveAt(0);
        }

        _points = previous;
        Normalize();
        _selectedIndex = _points.Count > 0 ? Math.Clamp(_selectedIndex, 0, _points.Count - 1) : -1;
        PointsChanged?.Invoke(this, EventArgs.Empty);
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    /// <summary>Przywraca zmianę cofniętą przez Undo (Ctrl+Shift+Z). Do 10 kroków w przód.</summary>
    public void Redo()
    {
        if (_redoStack.Count == 0)
        {
            return;
        }

        List<CurvePoint> next = _redoStack[^1];
        _redoStack.RemoveAt(_redoStack.Count - 1);

        _undoStack.Add(ClonePoints());
        if (_undoStack.Count > MaxHistorySteps)
        {
            _undoStack.RemoveAt(0);
        }

        _points = next;
        Normalize();
        _selectedIndex = _points.Count > 0 ? Math.Clamp(_selectedIndex, 0, _points.Count - 1) : -1;
        PointsChanged?.Invoke(this, EventArgs.Empty);
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    private List<CurvePoint> ClonePoints()
    {
        return _points.Select(point => new CurvePoint(point.Minute, point.Value, _maxValue)).ToList();
    }

    private void PushHistorySnapshot()
    {
        _undoStack.Add(ClonePoints());
        if (_undoStack.Count > MaxHistorySteps)
        {
            _undoStack.RemoveAt(0);
        }

        _redoStack.Clear();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        Graphics graphics = e.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle plot = PlotRectangle();

        Color axisColor = _darkMode ? Color.FromArgb(205, 208, 212) : Color.FromArgb(35, 35, 35);
        Color gridColor = _darkMode ? Color.FromArgb(60, 63, 68) : Color.FromArgb(222, 224, 226);
        Color textColor = _darkMode ? Color.FromArgb(214, 217, 222) : Color.FromArgb(64, 70, 78);

        using Pen axisPen = new(axisColor, 2);
        using Pen gridPen = new(gridColor, 1);
        using Pen curvePen = new(_activeCurveColor, 3);
        using Brush textBrush = new SolidBrush(textColor);
        using Brush pointBrush = new SolidBrush(Color.FromArgb(245, 151, 52));
        using Brush selectedBrush = new SolidBrush(Color.FromArgb(204, 49, 49));

        graphics.FillRectangle(new SolidBrush(BackColor), ClientRectangle);

        int gridStep = _maxValue <= 100 ? 25 : 64;
        for (int value = 0; value <= _maxValue; value += gridStep)
        {
            float y = ValueToY(value, plot);
            graphics.DrawLine(gridPen, plot.Left, y, plot.Right, y);
            graphics.DrawString(value.ToString(), _smallFont, textBrush, 8, y - 8);
        }

        for (int hour = 0; hour <= 24; hour += 3)
        {
            float x = MinuteToX(hour * 60, plot);
            graphics.DrawLine(gridPen, x, plot.Top, x, plot.Bottom);
            if (hour % 6 == 0)
            {
                string label = hour == 24 ? "24:00" : $"{hour:00}:00";
                SizeF size = graphics.MeasureString(label, _smallFont);
                graphics.DrawString(label, _smallFont, textBrush, x - size.Width / 2, plot.Bottom + 10);
            }
        }

        graphics.DrawRectangle(axisPen, plot);

        // Pozostałe krzywe (nieedytowane teraz) - przyciemnione, pod spodem, ZAWSZE
        // rysowane PRZED aktywną krzywą i jej punktami, żeby ta była wyraźnie "na
        // wierzchu". Bez punktów/uchwytów - to czysty podgląd.
        foreach ((Color color, IReadOnlyList<CurvePoint> points) in _backgroundCurves)
        {
            using Pen dimmedPen = new(Color.FromArgb(85, color.R, color.G, color.B), 2.5f);
            List<PointF> dimmedPath = ComputeCurvePath(points, _maxValue, plot);
            if (dimmedPath.Count > 1)
            {
                graphics.DrawLines(dimmedPen, dimmedPath.ToArray());
            }
        }

        if (_points.Count > 0)
        {
            DrawCurve(graphics, plot, curvePen);

            for (int index = 0; index < _points.Count; index++)
            {
                PointF location = ToPoint(_points[index], plot);
                float radius = index == _selectedIndex ? 6.5f : 5f;
                graphics.FillEllipse(
                    index == _selectedIndex ? selectedBrush : pointBrush,
                    location.X - radius,
                    location.Y - radius,
                    radius * 2,
                    radius * 2);
                graphics.DrawEllipse(Pens.White, location.X - radius, location.Y - radius, radius * 2, radius * 2);
            }
        }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        Focus();

        int hit = HitTest(e.Location);
        if (e.Button == MouseButtons.Right)
        {
            if (hit >= 0)
            {
                _selectedIndex = hit;
                DeleteSelectedPoint();
            }

            return;
        }

        if (e.Button != MouseButtons.Left)
        {
            return;
        }

        if (hit >= 0)
        {
            _selectedIndex = hit;
        }
        else
        {
            PushHistorySnapshot();
            CurvePoint point = FromPoint(e.Location);
            _points.Add(point);
            Normalize();
            _selectedIndex = _points.FindIndex(candidate => candidate.Minute == point.Minute);
            PointsChanged?.Invoke(this, EventArgs.Empty);
        }

        _dragging = true;
        _dragChanged = false;
        Capture = true;
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);

        if (!_dragging || SelectedPoint is null)
        {
            Cursor = HitTest(e.Location) >= 0 ? Cursors.Hand : Cursors.Cross;
            return;
        }

        CurvePoint point = FromPoint(e.Location);
        if (!_dragChanged && (point.Minute != SelectedPoint.Minute || point.Value != SelectedPoint.Value))
        {
            // Pierwszy realny ruch w tym przeciągnięciu - zapisz stan sprzed
            // zmiany jako jeden krok do cofnięcia.
            PushHistorySnapshot();
        }

        SelectedPoint.Minute = point.Minute;
        SelectedPoint.Value = point.Value;
        Normalize();
        _selectedIndex = _points.FindIndex(candidate => candidate.Minute == point.Minute);
        _dragChanged = true;
        SelectedPointChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (_dragging && _dragChanged)
        {
            PointsChanged?.Invoke(this, EventArgs.Empty);
        }

        _dragging = false;
        _dragChanged = false;
        Capture = false;
    }

    private void DrawCurve(Graphics graphics, Rectangle plot, Pen curvePen)
    {
        List<PointF> path = ComputeCurvePath(_points, _maxValue, plot);
        if (path.Count > 1)
        {
            graphics.DrawLines(curvePen, path.ToArray());
        }
    }

    /// <summary>
    /// Liczy ścieżkę (w pikselach) dla dowolnej krzywej o danych punktach i skali -
    /// wspólne dla aktywnej krzywej i krzywych w tle, żeby obie rysowały się
    /// dokładnie tą samą logiką interpolacji (ParameterCurve.GetValueAt).
    /// </summary>
    private static List<PointF> ComputeCurvePath(IReadOnlyList<CurvePoint> points, int maxValue, Rectangle plot)
    {
        List<PointF> path = [];
        if (points.Count == 0)
        {
            return path;
        }

        ParameterCurve curve = new()
        {
            Points = points.Select(point => new CurvePoint(point.Minute, point.Value, maxValue)).ToList(),
            MaxValue = maxValue
        };

        for (int minute = 0; minute <= 1440; minute += 10)
        {
            int clampedMinute = minute == 1440 ? 1439 : minute;
            int value = curve.GetValueAt(TimeOnly.FromTimeSpan(TimeSpan.FromMinutes(clampedMinute)));
            path.Add(new PointF(MinuteToX(minute, plot), ValueToYStatic(value, maxValue, plot)));
        }

        return path;
    }

    private int HitTest(Point location)
    {
        Rectangle plot = PlotRectangle();
        for (int index = 0; index < _points.Count; index++)
        {
            PointF point = ToPoint(_points[index], plot);
            double distance = Math.Sqrt(Math.Pow(point.X - location.X, 2) + Math.Pow(point.Y - location.Y, 2));
            if (distance <= 10)
            {
                return index;
            }
        }

        return -1;
    }

    private CurvePoint FromPoint(Point location)
    {
        Rectangle plot = PlotRectangle();
        double x = Math.Clamp(location.X, plot.Left, plot.Right);
        double y = Math.Clamp(location.Y, plot.Top, plot.Bottom);
        // Punkty przyciągają się do siatki co pół godziny (30 minut), a nie co 5 minut.
        int minute = (int)Math.Round((x - plot.Left) / plot.Width * 1439 / 30) * 30;
        int value = (int)Math.Round((plot.Bottom - y) / plot.Height * _maxValue);
        return new CurvePoint(minute, value, _maxValue);
    }

    private PointF ToPoint(CurvePoint point, Rectangle plot)
    {
        return new PointF(MinuteToX(point.Minute, plot), ValueToY(point.Value, plot));
    }

    private static float MinuteToX(int minute, Rectangle plot)
    {
        return plot.Left + Math.Clamp(minute, 0, 1440) / 1440f * plot.Width;
    }

    private float ValueToY(int value, Rectangle plot) => ValueToYStatic(value, _maxValue, plot);

    private static float ValueToYStatic(int value, int maxValue, Rectangle plot)
    {
        return plot.Bottom - Math.Clamp(value, 0, maxValue) / (float)maxValue * plot.Height;
    }

    private Rectangle PlotRectangle()
    {
        return new Rectangle(54, 26, Math.Max(50, Width - 84), Math.Max(50, Height - 74));
    }

    private void Normalize()
    {
        _points = _points
            .Select(point => new CurvePoint(point.Minute, point.Value, _maxValue))
            .GroupBy(point => point.Minute)
            .Select(group => group.Last())
            .OrderBy(point => point.Minute)
            .ToList();
    }
}
