namespace LightSter;

internal sealed class TrayPopupMenu : Form
{
    // Wydłużone o ~50% względem poprzednich wartości, żeby zamykanie po
    // zabraniu kursora nie było aż tak szybkie.
    private const int HideDelayMs = 495;

    // Ile czasu ufamy zewnętrznemu sprawdzeniu "kursor jest przy zasobniku"
    // (opartemu o globalną pozycję kursora). W trybie pełnoekranowym niektórych
    // gier (np. wyłączny fullscreen) globalna pozycja kursora bywa nieaktualna,
    // więc po tym czasie przestajemy jej ufać i polegamy tylko na realnym
    // najechaniu na samo okno menu.
    private const int TrayProximityTrustMs = 6000;

    // Absolutny "wentyl bezpieczeństwa" - menu nigdy nie zostanie otwarte
    // dłużej niż tyle, niezależnie od tego, czy uda się poprawnie wykryć
    // pozycję kursora, czy nie.
    private const int MaxAutoHideMs = 7500;

    // Jak długo trzeba potrzymać kursor nad kwadratem numeru slotu, zanim
    // pokaże się jego nazwa - celowo nieszybko, żeby nie migało przy zwykłym
    // przejeżdżaniu myszą po pasku slotów.
    private const int SlotNameTooltipDelayMs = 800;

    private static readonly Color MenuBackground = Color.FromArgb(34, 38, 44);
    private static readonly Color MenuForeground = Color.FromArgb(224, 228, 234);
    private static readonly Color MenuHover = Color.FromArgb(52, 58, 68);
    private static readonly Color MenuSeparator = Color.FromArgb(68, 74, 84);
    private static readonly Color MenuActive = Color.FromArgb(96, 104, 116);
    private static readonly Color MenuInactive = Color.FromArgb(44, 48, 56);
    private static readonly Color MenuBorder = Color.FromArgb(90, 96, 104);

    private readonly FlowLayoutPanel _itemsPanel = new();
    private readonly System.Windows.Forms.Timer _hideTimer = new() { Interval = 100 };

    // Własny, w pełni kontrolowany dymek z nazwą slotu zamiast wbudowanego
    // ToolTip - ten ostatni potrafi się nie pokazywać (albo pokazywać
    // niemiarodajnie) na oknach TopMost/WS_EX_TOOLWINDOW takich jak to menu,
    // szczególnie gdy okno nigdy nie jest "aktywne" w sensie Windows.
    private readonly SlotNameTooltip _slotNameTooltip = new();
    private readonly System.Windows.Forms.Timer _slotTooltipDelayTimer = new() { Interval = SlotNameTooltipDelayMs };
    private Button? _slotTooltipPendingButton;
    private string _slotTooltipPendingText = string.Empty;

    private DateTime _mouseLeftAt = DateTime.MinValue;
    private DateTime _shownAt = DateTime.MinValue;
    private Func<bool>? _isNearTray;

    public TrayPopupMenu()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        BackColor = MenuBackground;
        Font = new Font("Segoe UI", 9f);
        Padding = new Padding(4);
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;

        _itemsPanel.FlowDirection = FlowDirection.TopDown;
        _itemsPanel.WrapContents = false;
        _itemsPanel.AutoSize = true;
        _itemsPanel.Dock = DockStyle.Fill;
        _itemsPanel.BackColor = MenuBackground;
        Controls.Add(_itemsPanel);

        _hideTimer.Tick += (_, _) => CheckAutoHide();
        Deactivate += (_, _) => _mouseLeftAt = DateTime.UtcNow;

        _slotTooltipDelayTimer.Tick += (_, _) =>
        {
            _slotTooltipDelayTimer.Stop();
            if (_slotTooltipPendingButton is { IsDisposed: false, IsHandleCreated: true } button)
            {
                Point anchor = button.PointToScreen(new Point(0, button.Height + 4));
                _slotNameTooltip.ShowFor(_slotTooltipPendingText, anchor);
            }
        };
    }

    public void SetTrayProximityCheck(Func<bool> isNearTray)
    {
        _isNearTray = isNearTray;
    }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x00000080;
            return cp;
        }
    }

    public void SetItems(IEnumerable<TrayMenuEntry> entries)
    {
        _slotTooltipDelayTimer.Stop();
        _slotTooltipPendingButton = null;
        _slotNameTooltip.HideTooltip();

        _itemsPanel.Controls.Clear();
        const int menuWidth = 190;

        foreach (TrayMenuEntry entry in entries)
        {
            if (entry.IsSeparator)
            {
                Panel separator = new()
                {
                    Height = 1,
                    Width = menuWidth,
                    BackColor = MenuSeparator,
                    Margin = new Padding(4, 4, 4, 4)
                };
                _itemsPanel.Controls.Add(separator);
                continue;
            }

            if (entry.IsCurveSlotBar)
            {
                _itemsPanel.Controls.Add(BuildCurveSlotBar(
                    menuWidth,
                    entry.CurveSlotCount,
                    entry.ActiveCurveSlot,
                    entry.SlotAction,
                    entry.SlotNames));
                continue;
            }

            Button button = new()
            {
                Text = entry.Text,
                Width = menuWidth,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0),
                BackColor = MenuBackground,
                ForeColor = entry.Enabled ? MenuForeground : Color.FromArgb(110, 116, 126),
                Margin = new Padding(0, 0, 0, 1),
                Enabled = entry.Enabled,
                // Ten przycisk nigdy nie powinien pokazywać kropkowanej ramki
                // fokusu (widocznej np. na "000" na pierwszym screenie, gdy
                // pokazuje się dymek z nazwą slotu) - to menu nie jest
                // nawigowane klawiaturą, więc fokus klawiatury i tak nie ma
                // tu żadnej roli.
                TabStop = false
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = MenuHover;
            if (entry.Checked)
            {
                button.Font = new Font(button.Font, FontStyle.Bold);
            }

            TrayMenuEntry captured = entry;
            button.Click += (_, _) =>
            {
                HideMenu();
                captured.Action?.Invoke();
            };
            _itemsPanel.Controls.Add(button);
        }

        Size = new Size(menuWidth + 12, Math.Min(460, _itemsPanel.PreferredSize.Height + 12));
    }

    private Control BuildCurveSlotBar(int width, int slotCount, int activeSlot, Action<int>? slotAction, IReadOnlyList<string> slotNames)
    {
        IReadOnlyList<int> layout = SlotRowLayout.Compute(slotCount);
        Panel host = new()
        {
            Width = width,
            Margin = new Padding(0, 0, 0, 1),
            BackColor = MenuBackground
        };

        int slotNumber = 1;
        int rowTop = 2;
        const int rowHeight = 32;
        const int rowGap = 2;

        foreach (int columns in layout)
        {
            int buttonWidth = Math.Max(28, (width - 8) / columns);
            for (int column = 0; column < columns; column++)
            {
                int captured = slotNumber++;
                bool active = captured == activeSlot;
                Button button = new()
                {
                    Text = captured.ToString(),
                    Width = buttonWidth,
                    Height = rowHeight,
                    Left = column * buttonWidth + 2,
                    Top = rowTop,
                    FlatStyle = FlatStyle.Flat,
                    BackColor = active ? MenuActive : MenuInactive,
                    ForeColor = active ? Color.White : Color.FromArgb(180, 186, 194),
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    TabStop = false
                };
                button.FlatAppearance.BorderSize = 1;
                button.FlatAppearance.BorderColor = MenuBorder;
                button.FlatAppearance.MouseOverBackColor = MenuHover;
                button.Click += (_, _) =>
                {
                    if (host.FindForm() is TrayPopupMenu menu)
                    {
                        menu.HideMenu();
                    }

                    slotAction?.Invoke(captured);
                };

                // Nazwa slotu jako podpowiedź po dłuższym najechaniu - żeby wiadomo
                // było, który slot to który. Własny dymek (SlotNameTooltip) zamiast
                // wbudowanego ToolTip, bo ten ostatni bywa niemiarodajny na tego typu
                // oknach (TopMost/WS_EX_TOOLWINDOW, nigdy "aktywnych" wg Windows).
                // Chowa się natychmiast po zjechaniu z danego kwadratu, więc najechanie
                // na inny od razu pokazuje - po odpowiednim opóźnieniu - jego własną
                // nazwę. Pozycjonowanie w SlotNameTooltip.ShowFor dba o to, by dymek
                // nie wyszedł poza krawędź ekranu.
                string tipText = captured - 1 < slotNames.Count && !string.IsNullOrWhiteSpace(slotNames[captured - 1])
                    ? slotNames[captured - 1]
                    : $"Slot {captured}";
                button.MouseEnter += (_, _) =>
                {
                    _slotTooltipPendingButton = button;
                    _slotTooltipPendingText = tipText;
                    _slotTooltipDelayTimer.Stop();
                    _slotTooltipDelayTimer.Start();
                };
                button.MouseLeave += (_, _) =>
                {
                    _slotTooltipDelayTimer.Stop();
                    _slotTooltipPendingButton = null;
                    _slotNameTooltip.HideTooltip();
                };

                host.Controls.Add(button);
            }

            rowTop += rowHeight + rowGap;
        }

        host.Height = rowTop + 2;
        return host;
    }

    public void ShowNearTray(Point cursorPosition)
    {
        Rectangle workArea = Screen.FromPoint(cursorPosition).WorkingArea;
        int x = workArea.Right - Width;
        int y = cursorPosition.Y - Height - 6;

        if (y < workArea.Top)
        {
            y = workArea.Top + 4;
        }

        if (y + Height > workArea.Bottom)
        {
            y = workArea.Bottom - Height - 4;
        }

        Location = new Point(x, y);
        if (!Visible)
        {
            Show();
        }

        Activate();
        _hideTimer.Start();
        _mouseLeftAt = DateTime.MinValue;
        _shownAt = DateTime.UtcNow;
    }

    public void HideMenu()
    {
        _hideTimer.Stop();
        _slotTooltipDelayTimer.Stop();
        _slotTooltipPendingButton = null;
        _slotNameTooltip.HideTooltip();
        Hide();
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        base.OnMouseEnter(e);
        _mouseLeftAt = DateTime.MinValue;
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        if (!ClientRectangle.Contains(PointToClient(Cursor.Position)))
        {
            _mouseLeftAt = DateTime.UtcNow;
        }
    }

    private void CheckAutoHide()
    {
        double elapsedSinceShown = (DateTime.UtcNow - _shownAt).TotalMilliseconds;

        // Przez pierwsze kilka sekund ufamy sprawdzeniu "kursor przy zasobniku"
        // (oparte o globalną pozycję kursora - zwykle działa dobrze).
        bool trustTrayProximity = elapsedSinceShown < TrayProximityTrustMs;
        if (trustTrayProximity && _isNearTray?.Invoke() == true)
        {
            _mouseLeftAt = DateTime.MinValue;
            return;
        }

        Point cursor = PointToClient(Cursor.Position);
        if (ClientRectangle.Contains(cursor))
        {
            _mouseLeftAt = DateTime.MinValue;
            return;
        }

        if (_mouseLeftAt == DateTime.MinValue)
        {
            _mouseLeftAt = DateTime.UtcNow;
        }

        bool hoverGraceExpired = (DateTime.UtcNow - _mouseLeftAt).TotalMilliseconds >= HideDelayMs;

        // Jeśli z jakiegokolwiek powodu (np. aplikacja pełnoekranowa blokująca
        // odczyt pozycji kursora) nie da się wiarygodnie ustalić, czy kursor
        // znajduje się na oknie/ikonie, to i tak chowamy menu po max. ok. 5s.
        bool hardTimeoutExpired = elapsedSinceShown >= MaxAutoHideMs;

        if (hoverGraceExpired || hardTimeoutExpired)
        {
            HideMenu();
        }
    }
}

/// <summary>
/// Mały, własnoręcznie rysowany dymek z nazwą slotu, pokazywany po najechaniu
/// na kwadrat numeru w <see cref="TrayPopupMenu"/>. Zastępuje wbudowany
/// <see cref="ToolTip"/>, który na oknach TopMost/WS_EX_TOOLWINDOW (nigdy
/// "aktywnych" wg Windows) potrafi się nie pokazywać w ogóle albo pokazywać
/// niemiarodajnie. WS_EX_NOACTIVATE + ShowWithoutActivation gwarantują, że
/// samo pokazanie dymka nie odbierze fokusu oknu menu (co inaczej mogłoby
/// wywołać jego Deactivate i przedwcześnie uruchomić auto-chowanie).
/// </summary>
internal sealed class SlotNameTooltip : Form
{
    private readonly Label _label = new();

    public SlotNameTooltip()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        BackColor = Color.FromArgb(90, 96, 104);
        Padding = new Padding(1);
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;

        _label.AutoSize = true;
        _label.ForeColor = Color.FromArgb(224, 228, 234);
        _label.BackColor = Color.FromArgb(40, 44, 51);
        _label.Font = new Font("Segoe UI", 8.5f);
        _label.Padding = new Padding(7, 4, 7, 4);
        Controls.Add(_label);
    }

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            // WS_EX_TOOLWINDOW (nie pokazuj w Alt+Tab) | WS_EX_NOACTIVATE (nigdy nie
            // przejmuj fokusu przy pokazywaniu).
            cp.ExStyle |= 0x00000080 | 0x08000000;
            return cp;
        }
    }

    public void ShowFor(string text, Point anchorScreenPoint)
    {
        _label.Text = text;
        _label.PerformLayout();
        Size = _label.PreferredSize;

        Rectangle workArea = Screen.FromPoint(anchorScreenPoint).WorkingArea;
        int x = anchorScreenPoint.X;
        int y = anchorScreenPoint.Y;

        if (x + Width > workArea.Right)
        {
            x = workArea.Right - Width;
        }

        if (x < workArea.Left)
        {
            x = workArea.Left;
        }

        if (y + Height > workArea.Bottom)
        {
            // Nie mieści się pod kwadratem - pokaż nad punktem zaczepienia zamiast.
            y = anchorScreenPoint.Y - Height - 24;
        }

        if (y < workArea.Top)
        {
            y = workArea.Top;
        }

        Location = new Point(x, y);
        if (!Visible)
        {
            Show();
        }
    }

    public void HideTooltip()
    {
        if (Visible)
        {
            Hide();
        }
    }
}

internal sealed class TrayMenuEntry
{
    public string Text { get; init; } = string.Empty;
    public bool Enabled { get; init; } = true;
    public bool Checked { get; init; }
    public bool IsSeparator { get; init; }
    public bool IsCurveSlotBar { get; init; }
    public int CurveSlotCount { get; init; } = 3;
    public int ActiveCurveSlot { get; init; } = 1;
    public Action? Action { get; init; }
    public Action<int>? SlotAction { get; init; }
    public IReadOnlyList<string> SlotNames { get; init; } = [];

    public static TrayMenuEntry Separator() => new() { IsSeparator = true };
}
