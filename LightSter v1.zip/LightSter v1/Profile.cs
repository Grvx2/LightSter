namespace LightSter;

internal sealed class Profile
{
    public string Name { get; set; } = string.Empty;
    public ParameterCurve Brightness { get; set; } = ParameterCurve.Default(55);
    public ParameterCurve Contrast { get; set; } = ParameterCurve.Default(70);
    public ParameterCurve Saturation { get; set; } = ParameterCurve.Default(50);
    public ParameterCurve Rgb { get; set; } = ParameterCurve.Default(50, 100);

    /// <summary>
    /// Przesunięcie czasowe (w minutach) stosowane do wszystkich krzywych tego slotu
    /// przy odczycie wartości "na żywo" - nie zmienia samych punktów krzywej, tylko
    /// to, w jakiej chwili dana wartość zaczyna obowiązywać. Dodatnie przesuwa slot
    /// "do przodu" (np. punkt o 12:00 zaczyna obowiązywać o 12:30), ujemne "do tyłu".
    /// Zakres +/-8h (480 minut), zapisywane i przypisane osobno dla każdego slotu.
    /// </summary>
    public int TimeOffsetMinutes { get; set; }

    private const int MaxTimeOffsetMinutes = 8 * 60;

    public ParameterCurve Curve(ParameterKind kind)
    {
        return kind switch
        {
            ParameterKind.Brightness => Brightness,
            ParameterKind.Contrast => Contrast,
            ParameterKind.Saturation => Saturation,
            ParameterKind.Rgb => Rgb,
            _ => Brightness
        };
    }

    /// <summary>
    /// Zwraca chwilę, pod którą należy odpytać krzywe tego slotu, żeby uwzględnić
    /// <see cref="TimeOffsetMinutes"/>. Działa jak zwykłe dodawanie: dodatnie
    /// przesunięcie o X minut oznacza "sprawdź krzywą X minut później" (np. o 12:00
    /// z przesunięciem +2h dostajesz wartość, którą krzywa ma o 14:00), ujemne
    /// "X minut wcześniej" (o 12:00 z przesunięciem -2h dostajesz wartość z 10:00).
    /// </summary>
    /// <param name="offsetEnabled">
    /// Jeżeli false (panel "H" jest wyłączony), przesunięcie jest całkowicie
    /// pomijane - liczy się tak, jakby <see cref="TimeOffsetMinutes"/> wynosiło 0,
    /// niezależnie od tego, na co jest faktycznie ustawione.
    /// </param>
    public TimeOnly GetEffectiveTime(TimeOnly time, bool offsetEnabled = true)
    {
        if (!offsetEnabled)
        {
            return time;
        }

        int offset = Math.Clamp(TimeOffsetMinutes, -MaxTimeOffsetMinutes, MaxTimeOffsetMinutes);
        if (offset == 0)
        {
            return time;
        }

        int totalMinutes = time.Hour * 60 + time.Minute;
        int shifted = ((totalMinutes + offset) % 1440 + 1440) % 1440;
        return TimeOnly.FromTimeSpan(TimeSpan.FromMinutes(shifted));
    }

    public static Profile CreateDefault(int index)
    {
        // Nowy slot startuje z pojedynczym punktem o godz. 12:00 dla każdego
        // parametru: jasność 40, kontrast 50, saturacja 50, RGB 100.
        // Nazwa zostaje pusta - użytkownik sam ją wpisuje, zamiast dostawać
        // wymuszone "Profil N".
        return new Profile
        {
            Name = string.Empty,
            Brightness = ParameterCurve.SinglePointNoon(40, 100),
            Contrast = ParameterCurve.SinglePointNoon(50, 100),
            Saturation = ParameterCurve.SinglePointNoon(50, 100),
            Rgb = ParameterCurve.SinglePointNoon(100, 100)
        };
    }
}
