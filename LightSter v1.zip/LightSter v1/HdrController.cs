using System.Runtime.InteropServices;

namespace LightSter;

/// <summary>
/// Odczyt i przełączanie HDR ("Advanced Color") dla aktywnych ekranów, przez
/// publiczne (udokumentowane) Windowsowe API CCD - DisplayConfigGetDeviceInfo /
/// DisplayConfigSetDeviceInfo z DISPLAYCONFIG_DEVICE_INFO_GET_ADVANCED_COLOR_INFO
/// / DISPLAYCONFIG_DEVICE_INFO_SET_ADVANCED_COLOR_STATE. To dokładnie ten sam
/// mechanizm, którego używa Ustawienia Windows ("Windows HD Color") oraz skrót
/// Win+Alt+B - nie ma tu żadnej zależności od zewnętrznych plików/exe.
///
/// Celowo tylko to: włącz / wyłącz / sprawdź stan. Żadnego sterowania jasnością,
/// kontrastem itp. w trybie HDR przez tę klasę - to zostało z tej wersji LightStera
/// świadomie wycofane.
/// </summary>
internal static class HdrController
{
    private const int ErrorSuccess = 0;
    private const uint QdcOnlyActivePaths = 0x00000002;

    private enum DisplayConfigDeviceInfoType : uint
    {
        GetAdvancedColorInfo = 9,
        SetAdvancedColorState = 10,
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Luid
    {
        public uint LowPart;
        public int HighPart;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigDeviceInfoHeader
    {
        public DisplayConfigDeviceInfoType Type;
        public uint Size;
        public Luid AdapterId;
        public uint Id;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigGetAdvancedColorInfo
    {
        public DisplayConfigDeviceInfoHeader Header;

        // Bitfield: bit0 = advancedColorSupported, bit1 = advancedColorEnabled,
        // bit2 = wideColorEnforced, bit3 = advancedColorForceDisabled.
        public uint Value;
        public uint ColorEncoding;
        public uint BitsPerColorChannel;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigSetAdvancedColorState
    {
        public DisplayConfigDeviceInfoHeader Header;

        // Bitfield: bit0 = enableAdvancedColor.
        public uint Value;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigRational
    {
        public uint Numerator;
        public uint Denominator;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigPathSourceInfo
    {
        public Luid AdapterId;
        public uint Id;
        public uint ModeInfoIdx;
        public uint StatusFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigPathTargetInfo
    {
        public Luid AdapterId;
        public uint Id;
        public uint ModeInfoIdx;
        public uint OutputTechnology;
        public uint Rotation;
        public uint Scaling;
        public DisplayConfigRational RefreshRate;
        public uint ScanLineOrdering;
        [MarshalAs(UnmanagedType.Bool)]
        public bool TargetAvailable;
        public uint StatusFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DisplayConfigPathInfo
    {
        public DisplayConfigPathSourceInfo SourceInfo;
        public DisplayConfigPathTargetInfo TargetInfo;
        public uint Flags;
    }

    // Zawartość tej struktury (unia trybów źródła/celu) nas nie interesuje - liczy
    // się wyłącznie jej dokładny ROZMIAR (64 bajty na x64), żeby QueryDisplayConfig
    // poprawnie wyliczało odstępy kolejnych elementów tablicy modeInfoArray.
    [StructLayout(LayoutKind.Explicit, Size = 64)]
    private struct DisplayConfigModeInfo
    {
        [FieldOffset(0)]
        private readonly ulong _reserved;
    }

    [DllImport("user32.dll")]
    private static extern int GetDisplayConfigBufferSizes(
        uint flags, out uint numPathArrayElements, out uint numModeInfoArrayElements);

    [DllImport("user32.dll")]
    private static extern int QueryDisplayConfig(
        uint flags,
        ref uint numPathArrayElements,
        [Out] DisplayConfigPathInfo[] pathArray,
        ref uint numModeInfoArrayElements,
        [Out] DisplayConfigModeInfo[] modeInfoArray,
        IntPtr currentTopologyId);

    [DllImport("user32.dll")]
    private static extern int DisplayConfigGetDeviceInfo(ref DisplayConfigGetAdvancedColorInfo requestPacket);

    [DllImport("user32.dll")]
    private static extern int DisplayConfigSetDeviceInfo(ref DisplayConfigSetAdvancedColorState requestPacket);

    private static bool TryGetActivePaths(out DisplayConfigPathInfo[] paths)
    {
        paths = [];

        try
        {
            int result = GetDisplayConfigBufferSizes(QdcOnlyActivePaths, out uint pathCount, out uint modeCount);
            if (result != ErrorSuccess || pathCount == 0)
            {
                return false;
            }

            DisplayConfigPathInfo[] pathArray = new DisplayConfigPathInfo[pathCount];
            DisplayConfigModeInfo[] modeArray = new DisplayConfigModeInfo[modeCount];
            result = QueryDisplayConfig(
                QdcOnlyActivePaths, ref pathCount, pathArray, ref modeCount, modeArray, IntPtr.Zero);
            if (result != ErrorSuccess)
            {
                return false;
            }

            paths = pathArray;
            return true;
        }
        catch
        {
            // Brak user32/eksportów na starszym Windows albo dowolny inny problem
            // z natywnym wywołaniem - traktujemy tak samo, jak "HDR niedostępny".
            return false;
        }
    }

    private static bool TryGetColorInfo(DisplayConfigPathTargetInfo target, out DisplayConfigGetAdvancedColorInfo info)
    {
        info = new DisplayConfigGetAdvancedColorInfo
        {
            Header = new DisplayConfigDeviceInfoHeader
            {
                Type = DisplayConfigDeviceInfoType.GetAdvancedColorInfo,
                Size = (uint)Marshal.SizeOf<DisplayConfigGetAdvancedColorInfo>(),
                AdapterId = target.AdapterId,
                Id = target.Id,
            }
        };

        try
        {
            return DisplayConfigGetDeviceInfo(ref info) == ErrorSuccess;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// True, jeśli przynajmniej jeden aktywny ekran zgłasza obsługę HDR
    /// ("Advanced Color") - czyli da się w ogóle przełączać.
    /// </summary>
    public static bool IsSupported()
    {
        if (!TryGetActivePaths(out DisplayConfigPathInfo[] paths))
        {
            return false;
        }

        foreach (DisplayConfigPathInfo path in paths)
        {
            if (TryGetColorInfo(path.TargetInfo, out DisplayConfigGetAdvancedColorInfo info)
                && (info.Value & 0x1) != 0)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// True, jeśli HDR jest obecnie włączony na przynajmniej jednym aktywnym,
    /// obsługującym go ekranie. Odczytywane na żywo z systemu (nie z ustawień
    /// aplikacji), więc zawsze zgadza się z tym, co widać w Windows - także gdy
    /// ktoś przełączył HDR spoza LightStera (np. skrótem Win+Alt+B).
    /// </summary>
    public static bool IsEnabled()
    {
        if (!TryGetActivePaths(out DisplayConfigPathInfo[] paths))
        {
            return false;
        }

        foreach (DisplayConfigPathInfo path in paths)
        {
            if (TryGetColorInfo(path.TargetInfo, out DisplayConfigGetAdvancedColorInfo info)
                && (info.Value & 0x1) != 0 // advancedColorSupported
                && (info.Value & 0x2) != 0) // advancedColorEnabled
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Ustawia HDR na wszystkich aktywnych ekranach, które go obsługują (te, które
    /// go nie obsługują, są po cichu pomijane). Zwraca true, jeśli udało się to
    /// zastosować na przynajmniej jednym ekranie.
    /// </summary>
    public static bool SetEnabled(bool enable)
    {
        if (!TryGetActivePaths(out DisplayConfigPathInfo[] paths))
        {
            return false;
        }

        bool appliedAny = false;
        foreach (DisplayConfigPathInfo path in paths)
        {
            if (!TryGetColorInfo(path.TargetInfo, out DisplayConfigGetAdvancedColorInfo colorInfo)
                || (colorInfo.Value & 0x1) == 0)
            {
                continue;
            }

            DisplayConfigSetAdvancedColorState setPacket = new()
            {
                Header = new DisplayConfigDeviceInfoHeader
                {
                    Type = DisplayConfigDeviceInfoType.SetAdvancedColorState,
                    Size = (uint)Marshal.SizeOf<DisplayConfigSetAdvancedColorState>(),
                    AdapterId = path.TargetInfo.AdapterId,
                    Id = path.TargetInfo.Id,
                },
                Value = enable ? 1u : 0u,
            };

            try
            {
                if (DisplayConfigSetDeviceInfo(ref setPacket) == ErrorSuccess)
                {
                    appliedAny = true;
                }
            }
            catch
            {
                // Kontynuujemy z kolejnymi ekranami nawet jeśli jeden zawiedzie.
            }
        }

        return appliedAny;
    }

    /// <summary>
    /// Przełącza HDR na przeciwny stan względem obecnego (patrz IsEnabled) na
    /// wszystkich obsługujących go aktywnych ekranach. Zwraca nowy stan.
    /// </summary>
    public static bool Toggle()
    {
        bool next = !IsEnabled();
        SetEnabled(next);
        return next;
    }
}
