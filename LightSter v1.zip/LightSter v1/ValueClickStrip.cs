namespace LightSter;

internal sealed class ValueClickStrip : Control
{
    // Stored descending (largest first) so index 0 is drawn at the top and the last
    // index is drawn at the bottom - matching the slider (max at top, min at bottom).
    private List<int> _values = [100, 0];

    public event EventHandler? ValueSelected;

    public ValueClickStrip()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        Width = 22;
        Cursor = Cursors.Hand;
    }

    public int Minimum => _values.Count > 0 ? _values[^1] : 0;

    public int Maximum => _values.Count > 0 ? _values[0] : 0;

    /// <summary>
    /// Sets the explicit list of values shown (and clickable) next to the slider.
    /// The list does not need to use a uniform step; entries are always drawn with
    /// equal vertical spacing regardless of the numeric gaps between them.
    /// </summary>
    public void SetValues(IEnumerable<int> values)
    {
        List<int> ordered = values.Distinct().OrderByDescending(v => v).ToList();
        if (ordered.Count == 0)
        {
            ordered.Add(0);
        }

        _values = ordered;
        Invalidate();
    }

    public int Value { get; set; }

    /// <summary>
    /// Largest font size this strip will grow to. Columns with fewer stops (and thus
    /// more vertical room per label, e.g. Jasność/Kontrast/Saturacja/RGB) can afford a
    /// bigger value than the tighter 14-stop R/G/B channel strips.
    /// </summary>
    public float MaxFontSize { get; set; } = 8.5f;

    private const float MinFontSize = 6f;

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        Graphics graphics = e.Graphics;
        graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        Rectangle area = new(1, 8, Width - 2, Height - 16);
        using SolidBrush textBrush = new(Color.FromArgb(168, 174, 182));

        float gap = area.Height / (float)Math.Max(1, _values.Count - 1);

        // Pick the biggest font (up to MaxFontSize) whose line height still leaves at
        // least a 1px gap between adjacent labels, so bumping the size never lets
        // neighbouring numbers touch or overlap (this used to happen most often with
        // the "0" in adjacent values) - even for the longest lists (e.g. the 14-stop
        // R/G/B strips).
        float fontSize = MaxFontSize;
        using Font probeFont = new("Segoe UI", fontSize);
        float probeHeight = graphics.MeasureString("0", probeFont).Height;
        float allowedHeight = Math.Max(1f, gap - 1.5f);
        if (probeHeight > allowedHeight && probeHeight > 0)
        {
            fontSize = Math.Clamp(fontSize * (allowedHeight / probeHeight), MinFontSize, MaxFontSize);
        }

        using Font font = new("Segoe UI", fontSize);

        for (int index = 0; index < _values.Count; index++)
        {
            int candidate = _values[index];
            float y = area.Top + index / (float)Math.Max(1, _values.Count - 1) * area.Height;
            string label = candidate.ToString();
            SizeF size = graphics.MeasureString(label, font);
            graphics.DrawString(label, font, textBrush, Width / 2f - size.Width / 2f, y - size.Height / 2f);
        }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left)
        {
            return;
        }

        int selected = HitValue(e.Y);
        Value = selected;
        ValueSelected?.Invoke(this, EventArgs.Empty);
    }

    private int HitValue(int y)
    {
        Rectangle area = new(2, 8, Width - 4, Height - 16);

        int bestValue = _values.Count > 0 ? _values[0] : 0;
        float bestDistance = float.MaxValue;

        for (int index = 0; index < _values.Count; index++)
        {
            float itemY = area.Top + index / (float)Math.Max(1, _values.Count - 1) * area.Height;
            float distance = Math.Abs(itemY - y);
            if (distance < bestDistance)
            {
                bestDistance = distance;
                bestValue = _values[index];
            }
        }

        return bestValue;
    }
}
