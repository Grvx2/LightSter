namespace LightSter;

/// <summary>
/// 5 dyskretnych wartości gammy obsługiwanych przez monitor przez DDC/CI (VCP 0x72).
/// Współdzielone przez: pigułkę gammy w QuickAdjustForm (scroll, bez zawijania),
/// kafelki gammy w edytorze krzywych (MainForm), rozwijane menu w "Presety ręczne"
/// i sam sterownik DDC (mapowanie wartość &lt;-&gt; indeks VCP).
/// </summary>
internal static class GammaSteps
{
    public static readonly double[] Values = [1.8, 2.0, 2.2, 2.4, 2.6];

    /// <summary>
    /// Dopasowuje dowolną wartość double do najbliższego z 5 kroków. Null zostaje
    /// null (oznacza "None" - brak wpływu na gammę).
    /// </summary>
    public static double? Snap(double? value)
    {
        if (value is not { } raw)
        {
            return null;
        }

        return Values.OrderBy(candidate => Math.Abs(candidate - raw)).First();
    }

    public static int IndexOf(double value)
    {
        int index = Array.FindIndex(Values, candidate => Math.Abs(candidate - value) < 0.01);
        return index < 0 ? 1 : index; // domyślnie 2.0, gdyby coś się nie zgadzało
    }

    /// <summary>
    /// Przesuwa o krok w indeksach BEZ zawijania - na krańcach (1.8 albo 2.6)
    /// dalsze przesuwanie w tym samym kierunku nic nie zmienia.
    /// </summary>
    public static double Step(double current, int direction)
    {
        int index = IndexOf(current);
        int next = Math.Clamp(index + Math.Sign(direction), 0, Values.Length - 1);
        return Values[next];
    }

    public static string Format(double? value) => value is { } v ? v.ToString("0.0") : "None";
}
