using NvAPIWrapper;
using NvAPIWrapper.Native;
using NvAPIWrapper.Native.Display.Structures;

namespace LightSter;

// Steruje saturacja obrazu za pomoca funkcji "Digital Vibrance Control" (DVC) sterownika
// NVIDIA (NVAPI), zamiast przez DDC/CI (ktore dla saturacji nie dziala na niektorych monitorach).
// Reszta parametrow (jasnosc, kontrast, RGB) nadal idzie przez DDC - ten kontroler obsluguje
// wylacznie saturacje.
//
// KALIBRACJA (na podstawie testow na rzeczywistym sprzecie, wersja 2):
// Pierwsza wersja mnozyla wartosc suwaka aplikacji razy 1.26 (appValue 50 -> poziom 63),
// zakladajac ze poziom 63 to "wyglad natywny" i ze sterownik/karta wspiera poziomy powyzej
// 100 (do ~126). Testy pokazaly, ze tak NIE jest:
//  - realny, efektywny sufit poziomu DVC na tej karcie/sterowniku to 100 (nie 126/200) -
//    kazda wartosc powyzej 100 byla po prostu przycinana do 100,
//  - w efekcie appValue 80, 90 i 100 dawaly identyczny wynik (100) w panelu NVIDIA,
//  - a appValue 50 pokazywal w panelu 63 zamiast 50, czyli suwak aplikacji NIE
//    odpowiadal 1:1 wartosci widocznej w panelu NVIDIA - czego oczekuje uzytkownik.
// Dlatego teraz mapowanie jest TOZSAMOSCIOWE (bez mnoznika): appValue 0-100 przekladane
// jest wprost na poziom DVC 0-100. appValue 50 -> poziom 50, appValue 70 -> poziom 70, itd.
// Suwak aplikacji ma teraz dokladnie taka sama skale, jak wartosc widoczna w panelu NVIDIA
// ("Cyfrowa poswiata").
internal sealed class MonitorVibranceController
{
    // Jeden lock na WSZYSTKIE wywolania NVAPI w calej aplikacji (inicjalizacja, enumeracja,
    // ustawianie poziomu) - eliminuje ewentualne konflikty przy rownoleglych wywolaniach.
    private static readonly object NvapiLock = new();

    private static bool _initialized;
    private static bool _initializationFailed;

    // Cache rozwiazanego uchwytu NVIDIA per nazwa urzadzenia GDI (np. "\\.\DISPLAY1"),
    // zeby NIE robic pelnej enumeracji przy kazdej zmianie suwaka - to byla glowna
    // przyczyna losowych opoznien/pomijania zmian.
    private static readonly Dictionary<string, DisplayHandle> HandleCache =
        new(StringComparer.OrdinalIgnoreCase);

    // Fallback gdy nie mamy nazwy GDI, a jest tylko jeden ekran obslugiwany przez NVIDIA.
    private static DisplayHandle? _singleDisplayFallback;

    // Ostatni blad - do wyswietlenia/zalogowania zamiast cichego "nie zadzialalo".
    public string? LastError { get; private set; }

    private static bool EnsureInitialized()
    {
        if (_initialized)
        {
            return true;
        }

        if (_initializationFailed)
        {
            return false;
        }

        try
        {
            NVIDIA.Initialize();
            _initialized = true;
            return true;
        }
        catch
        {
            // Brak karty NVIDIA, brak sterownika NVAPI, lub inny problem z inicjalizacja.
            _initializationFailed = true;
            return false;
        }
    }

    // Ustawia poziom saturacji (Digital Vibrance) na monitorze odpowiadajacym podanej
    // nazwie urzadzenia GDI (np. "\\.\DISPLAY1"). Zaprojektowane tak, aby przy normalnym
    // dzialaniu (uchwyt juz w cache'u) byc PRAKTYCZNIE NATYCHMIASTOWE - bez enumeracji.
    public bool TrySetSaturation(string? gdiDeviceName, int appSaturation0To100)
    {
        // Mapowanie 1:1 - appValue 0-100 to bezposrednio poziom DVC 0-100 (patrz komentarz
        // kalibracyjny na gorze pliku). Zaden mnoznik.
        int level = Math.Clamp(appSaturation0To100, 0, 100);

        lock (NvapiLock)
        {
            if (!EnsureInitialized())
            {
                LastError = "Inicjalizacja NVAPI nie powiodla sie (brak karty/sterownika NVIDIA?).";
                return false;
            }

            // Szybka sciezka: mamy juz zapamietany, dzialajacy uchwyt.

            if (gdiDeviceName is not null && HandleCache.TryGetValue(gdiDeviceName, out DisplayHandle cachedHandle))
            {
                if (TryApply(cachedHandle, level))
                {
                    return true;
                }

                // Uchwyt sie zdezaktualizowal (np. zmiana konfiguracji monitorow) - usun z cache
                // i sprobuj rozwiazac go od nowa ponizej.
                HandleCache.Remove(gdiDeviceName);
            }
            else if (gdiDeviceName is null && _singleDisplayFallback is { } fallbackHandle)
            {
                if (TryApply(fallbackHandle, level))
                {
                    return true;
                }

                _singleDisplayFallback = null;
            }

            // Wolna sciezka: pelna enumeracja - tylko gdy cache chybil (pierwsze wywolanie
            // po starcie albo po zmianie konfiguracji monitorow).
            return ResolveAndApply(gdiDeviceName, level);
        }
    }

    private bool TryApply(DisplayHandle handle, int level)
    {
        try
        {
            DisplayApi.SetDVCLevelEx(handle, level);
            return true;
        }
        catch (Exception ex)
        {
            LastError = ex.Message;
            return false;
        }
    }

    private bool ResolveAndApply(string? gdiDeviceName, int level)
    {
        try
        {
            DisplayHandle[] handles = DisplayApi.EnumNvidiaDisplayHandle();
            if (handles.Length == 0)
            {
                LastError = "NVAPI nie zwrocilo zadnego wyswietlacza (EnumNvidiaDisplayHandle).";
                return false;
            }

            DisplayHandle? target = null;

            if (!string.IsNullOrEmpty(gdiDeviceName))
            {
                foreach (DisplayHandle handle in handles)
                {
                    string? name = TryGetDisplayName(handle);
                    if (string.Equals(name, gdiDeviceName, StringComparison.OrdinalIgnoreCase))
                    {
                        target = handle;
                        break;
                    }
                }
            }

            // Fallback: jesli nie udalo sie dopasowac po nazwie (np. roznice w formacie nazwy
            // miedzy Windows a NVAPI), a jest tylko jeden ekran obslugiwany przez NVIDIA, uzyj go.
            if (target is null && handles.Length == 1)
            {
                target = handles[0];
            }

            if (target is null)
            {
                LastError = "Nie udalo sie dopasowac monitora GDI do wyswietlacza NVIDIA.";
                return false;
            }

            DisplayApi.SetDVCLevelEx(target.Value, level);

            // Zapamietaj uchwyt, zeby kolejne wywolania byly natychmiastowe.
            if (gdiDeviceName is not null)
            {
                HandleCache[gdiDeviceName] = target.Value;
            }
            else
            {
                _singleDisplayFallback = target.Value;
            }

            return true;
        }
        catch (Exception ex)
        {
            LastError = ex.Message;
            return false;
        }
    }

    private static string? TryGetDisplayName(DisplayHandle handle)
    {
        try
        {
            return DisplayApi.GetAssociatedNvidiaDisplayName(handle);
        }
        catch
        {
            return null;
        }
    }
}
