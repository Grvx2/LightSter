namespace LightSter;

/// <summary>
/// NumericUpDown do pola "Min." - jedno kliknięcie strzałki w górę zaokrągla
/// w górę do kolejnej wielokrotności 10 (np. 13 -> 20), a strzałka w dół
/// zaokrągla w dół do poprzedniej wielokrotności 10 (np. 13 -> 10),
/// zamiast zwyczajnie dodawać/odejmować 1.
/// </summary>
internal sealed class MinuteStepNumericUpDown : NumericUpDown
{
    // Skok stosowany, gdy użytkownik kręci kółkiem myszy nad polem - większy niż
    // przy strzałkach (które poruszają się po siatce co 10), żeby dużą zmianę dało
    // się zrobić szybciej niż pojedynczymi minutami.
    private const int WheelStepMinutes = 30;

    public override void UpButton()
    {
        int current = (int)Value;
        int next = current / 10 * 10 + 10;
        int max = (int)Maximum;
        // Zamiast zatrzymywać się na maksimum (np. 59), po przekroczeniu
        // zakresu wraca do 0 - tak jak zegar, a nie jak zwykłe pole liczbowe.
        Value = next > max ? 0 : next;
    }

    public override void DownButton()
    {
        int current = (int)Value;
        int max = (int)Maximum;
        int min = (int)Minimum;

        if (current <= 0)
        {
            // Zawinięcie "jak zegar" w drugą stronę: zamiast zatrzymywać się na 0,
            // wraca do najwyższego pełnego dziesiątka w zakresie (np. 50 dla 0-59) -
            // czyli tego samego miejsca, z którego UpButton zawija się do 0.
            Value = max / 10 * 10;
            return;
        }

        int next = (current - 1) / 10 * 10;
        Value = next < min ? min : next;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        int notch = Math.Max(1, SystemInformation.MouseWheelScrollDelta);
        int notches = e.Delta / notch;
        if (notches == 0)
        {
            return;
        }

        int min = (int)Minimum;
        int max = (int)Maximum;
        int span = max - min + 1;
        int current = (int)Value;
        int next = current + notches * WheelStepMinutes;
        // Zawija się jak zegar zamiast zatrzymywać na krańcach zakresu.
        next = ((next - min) % span + span) % span + min;
        Value = next;

        if (e is HandledMouseEventArgs handledArgs)
        {
            handledArgs.Handled = true;
        }
    }
}
