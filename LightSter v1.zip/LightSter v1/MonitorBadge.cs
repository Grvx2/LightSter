namespace LightSter;

/// <summary>
/// Small square badge used to pick which connected monitor is being edited.
/// Drawn as a plain white outline square with a bold centered number, rather than
/// a stock Button, so a row of badges (1, 2, 3, ...) always lines up perfectly and
/// never shows the OS's own hover/focus chrome.
/// </summary>
internal sealed class MonitorBadge : Control
{
    private bool _active;
    private bool _hovering;

    public event EventHandler? Selected;

    public MonitorBadge()
    {
        SetStyle(
            ControlStyles.AllPaintingInWmPaint
            | ControlStyles.OptimizedDoubleBuffer
            | ControlStyles.UserPaint
            | ControlStyles.ResizeRedraw,
            true);
        Width = 24;
        Height = 24;
        Cursor = Cursors.Hand;
    }

    public int MonitorNumber { get; set; }

    public bool Active
    {
        get => _active;
        set
        {
            if (_active == value)
            {
                return;
            }

            _active = value;
            Invalidate();
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        Graphics graphics = e.Graphics;
        graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        // Inset by a pixel on every side so the anti-aliased border (which can be up to
        // 1.4px wide when active) always has room to render fully inside the control's
        // own clip region. Without this the bottom/right edge of the square could get
        // sliced off by exactly the amount the stroke overshot the control bounds.
        Rectangle bounds = new(1, 1, Width - 3, Height - 3);

        Color borderColor = _active
            ? Color.White
            : Color.FromArgb(_hovering ? 210 : 140, 255, 255, 255);

        using Pen border = new(borderColor, _active ? 1.4f : 1f);
        graphics.DrawRectangle(border, bounds);

        Color textColor = _active ? Color.White : Color.FromArgb(210, 214, 220);
        string label = MonitorNumber.ToString();
        using Font font = new("Segoe UI", 10f, FontStyle.Bold);
        SizeF size = graphics.MeasureString(label, font);
        using SolidBrush textBrush = new(textColor);
        graphics.DrawString(
            label,
            font,
            textBrush,
            (Width - size.Width) / 2f,
            (Height - size.Height) / 2f - 0.5f);
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        base.OnMouseEnter(e);
        _hovering = true;
        Invalidate();
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        _hovering = false;
        Invalidate();
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Left)
        {
            Selected?.Invoke(this, EventArgs.Empty);
        }
    }
}
