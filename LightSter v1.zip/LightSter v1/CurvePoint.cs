namespace LightSter;

internal sealed class CurvePoint
{
    public int Minute { get; set; }
    public int Value { get; set; }

    public CurvePoint()
    {
    }

    public CurvePoint(int minute, int value, int maxValue = 100)
    {
        Minute = Math.Clamp(minute, 0, 1439);
        Value = Math.Clamp(value, 0, maxValue);
    }
}
