Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")

scriptFolder = fileSystem.GetParentFolderName(WScript.ScriptFullName)
exePath = scriptFolder & "\app\LightSter.exe"
shortcutPath = scriptFolder & "\LightSter.lnk"

If Not fileSystem.FileExists(exePath) Then
    MsgBox "Najpierw zbuduj aplikacje (kliknij Zbuduj.bat lub Uruchom LightSter.bat)." & vbCrLf & vbCrLf & "Brak pliku:" & vbCrLf & exePath, vbExclamation, "LightSter"
    WScript.Quit 1
End If

Set shortcut = shell.CreateShortcut(shortcutPath)
shortcut.TargetPath = exePath
shortcut.WorkingDirectory = scriptFolder & "\app"
shortcut.Description = "LightSter - sterowanie jasnoscia monitora"
shortcut.Save

MsgBox "Utworzono skrot:" & vbCrLf & shortcutPath, vbInformation, "LightSter"
