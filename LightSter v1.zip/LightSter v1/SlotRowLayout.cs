namespace LightSter;

internal static class SlotRowLayout
{
    public static IReadOnlyList<int> Compute(int count)
    {
        if (count <= 0)
        {
            return [3];
        }

        if (count <= 5)
        {
            return [count];
        }

        int minRows = (int)Math.Ceiling(count / 5.0);
        int maxRows = (int)Math.Ceiling(count / 3.0);

        List<int>? best = null;
        int bestScore = int.MaxValue;

        for (int rows = minRows; rows <= maxRows; rows++)
        {
            if (!TryBuildLayout(count, rows, out List<int>? layout) || layout is null || layout.Count == 0)
            {
                continue;
            }

            int score = rows * 100 - layout[0] * 10 + (layout.Max() - layout.Min());
            if (score < bestScore)
            {
                bestScore = score;
                best = layout;
            }
        }

        return best ?? [Math.Min(5, count)];
    }

    private static bool TryBuildLayout(int count, int rows, out List<int>? layout)
    {
        layout = [];
        int remaining = count;

        for (int row = 0; row < rows; row++)
        {
            int rowsLeft = rows - row;
            int minTake = Math.Max(3, remaining - (rowsLeft - 1) * 5);
            int maxTake = Math.Min(5, remaining - (rowsLeft - 1) * 3);
            if (minTake > maxTake)
            {
                layout = null;
                return false;
            }

            int take = rowsLeft == 1
                ? remaining
                : maxTake;
            while (take >= minTake && !CanComplete(remaining - take, rowsLeft - 1))
            {
                take--;
            }

            if (take < minTake)
            {
                layout = null;
                return false;
            }

            layout.Add(take);
            remaining -= take;
        }

        return remaining == 0 && layout.All(value => value is >= 3 and <= 5);
    }

    private static bool CanComplete(int remaining, int rowsLeft)
    {
        if (rowsLeft == 0)
        {
            return remaining == 0;
        }

        return remaining >= rowsLeft * 3 && remaining <= rowsLeft * 5;
    }
}
