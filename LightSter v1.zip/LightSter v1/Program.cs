using System.Globalization;

namespace LightSter;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        CultureInfo polish = CultureInfo.GetCultureInfo("pl-PL");
        Thread.CurrentThread.CurrentCulture = polish;
        Thread.CurrentThread.CurrentUICulture = polish;

        // Aplikacja startuje jako WinExe bez konsoli - bez tego jakikolwiek
        // niezłapany wyjątek przy starcie po prostu cichutko zabijał proces
        // (stąd "kółko się kręci i nic się nie dzieje"). Teraz zamiast tego
        // pokazuje się okno z pełną treścią błędu, żeby dało się go namierzyć.
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            ShowFatalError(e.ExceptionObject as Exception);
        Application.ThreadException += (_, e) =>
            ShowFatalError(e.Exception);

        try
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new TrayApplicationContext());
        }
        catch (Exception ex)
        {
            ShowFatalError(ex);
        }
    }

    private static void ShowFatalError(Exception? ex)
    {
        MessageBox.Show(
            $"LightSter napotkał błąd przy starcie i nie może kontynuować:\n\n{ex}",
            "LightSter - błąd krytyczny",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}
