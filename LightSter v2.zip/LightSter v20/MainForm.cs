namespace LightSter;

internal sealed class MainForm : Form
{
    // Wspólna wysokość dla wszystkich kontrolek w jednym wierszu (przyciski,
    // pola, etykiety, combo), dzięki czemu ich środek wypada na tej samej
    // linii i cały interfejs wygląda równo.
    private const int RowHeight = 32;

    private readonly AppSettings _settings;
    private readonly MonitorDdcController _monitorController;
    private readonly SmoothMonitorApplier _applier;
    private readonly Action _onSettingsChanged;
    private SettingsForm? _settingsForm;
    private readonly TimelineControl _timeline = new();
    private readonly ComboBox _monitorBox = new();
    private readonly ComboBox _presetBox = new();
    private readonly TextBox _presetNameBox = new();
    private readonly NumericUpDown _presetBrightnessInput = new();
    private readonly NumericUpDown _presetContrastInput = new();
    private readonly NumericUpDown _presetSaturationInput = new();
    private readonly NumericUpDown _presetRgbInput = new();
    private readonly ComboBox _presetGammaBox = new();
    private readonly Button _settingsButton = new();
    private readonly NumericUpDown _hourInput = new();
    private readonly MinuteStepNumericUpDown _minuteInput = new();
    private readonly NumericUpDown _valueInput = new();
    private readonly CurveSnapTextBox _curveValueSnapInput = new();
    private readonly CurveSnapTextBox _curveTimeSnapInput = new();
    private readonly TextBox _slotNameBox = new();
    private readonly Button _addSlotButton = new()
    {
        Text = "+",
        Width = 36,
        Height = RowHeight,
        Margin = new Padding(8, 0, 0, 0)
    };
    private readonly Button _nightModeToggle = new()
    {
        Text = "🌙 Tryb nocny",
        AutoSize = true,
        Dock = DockStyle.Right,
        FlatStyle = FlatStyle.Flat,
        Margin = new Padding(0, 8, 16, 0)
    };
    private readonly Dictionary<ParameterKind, RadioButton> _parameterButtons = [];
    private readonly Dictionary<int, RadioButton> _curveSlotButtons = [];
    private readonly FlowLayoutPanel _curveSlotPanel = new();

    private ParameterKind _selectedParameter = ParameterKind.Brightness;
    private int _currentMaxValue = 100;
    private bool _syncingControls;
    private bool _nightMode;
    private bool _nightScheduleManualOverride;
    private Icon? _customAppIcon;
    private string? _customAppIconPath;
    private bool _customAppIconApplied;
    private readonly Icon? _defaultAppIcon;

    public MainForm(
        AppSettings settings,
        MonitorDdcController monitorController,
        SmoothMonitorApplier applier,
        Action onSettingsChanged)
    {
        _settings = settings;
        _monitorController = monitorController;
        _applier = applier;
        _onSettingsChanged = onSettingsChanged;

        Text = "LightSter - Krzywe";
        MinimumSize = new Size(1000, 700);
        Size = new Size(1200, 800);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);
        BackColor = Color.FromArgb(243, 244, 246);
        KeyPreview = true;
        _defaultAppIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        _syncingControls = true;
        _curveValueSnapInput.Minimum = 1;
        _curveValueSnapInput.Maximum = 100;
        _curveValueSnapInput.Value = _settings.CurvePointValueSnap;
        _curveTimeSnapInput.Minimum = 1;
        _curveTimeSnapInput.Maximum = 60;
        _curveTimeSnapInput.Value = _settings.CurvePointTimeSnapMinutes;

        _addSlotButton.Click += (_, _) => AddCurveSlot();
        _nightModeToggle.Click += (_, _) => ToggleNightMode();

        KeyDown += (_, e) =>
        {
            if (e.Control && e.KeyCode == Keys.Z && e.Shift)
            {
                _timeline.Redo();
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.Z)
            {
                _timeline.Undo();
                e.Handled = true;
            }
        };

        BuildLayout();
        _timeline.ValueSnapStep = _settings.CurvePointValueSnap;
        _timeline.TimeSnapMinutes = _settings.CurvePointTimeSnapMinutes;
        _syncingControls = false;
        ApplyCustomAppIcon();
        _nightMode = _settings.NightModeLastState;
        ApplyNightMode();
        RefreshFromSettings();
    }

    private MonitorConfiguration ActiveMonitor => _settings.ActiveMonitor;

    private Profile ActiveProfile => ActiveMonitor.ActiveProfile;

    private ParameterCurve ActiveCurve => ActiveProfile.Curve(_selectedParameter);

    public void RefreshFromSettings()
    {
        _settings.SyncMonitors(_monitorController.GetMonitors());
        BindMonitors();
        BindCurveSlots();
        BindPresets();
        BindCurrentCurve();
    }

    private void BuildLayout()
    {
        TableLayoutPanel root = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 6,
            Padding = new Padding(16)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        Controls.Add(root);

        root.Controls.Add(BuildTopPanel(), 0, 0);
        root.Controls.Add(BuildParameterPanel(), 0, 1);

        Panel graphHost = new()
        {
            Dock = DockStyle.Fill,
            BackColor = Color.White,
            Padding = new Padding(12),
            BorderStyle = BorderStyle.FixedSingle
        };
        _timeline.Dock = DockStyle.Fill;
        _timeline.PointsChanged += (_, _) => MarkChanged();
        _timeline.SelectedPointChanged += (_, _) => SyncPointInputs();
        graphHost.Controls.Add(_timeline);
        root.Controls.Add(graphHost, 0, 2);

        root.Controls.Add(BuildSlotNamePanel(), 0, 3);
        root.Controls.Add(BuildPresetPanel(), 0, 4);
        root.Controls.Add(BuildBottomPanel(), 0, 5);
    }

    private Control BuildSlotNamePanel()
    {
        TableLayoutPanel row = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1
        };
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        row.RowStyles.Add(new RowStyle(SizeType.Absolute, RowHeight));

        Label caption = MakeCaptionLabel("Nazwa", 90);
        // Anchor bez Top/Bottom - TableLayoutPanel wyśrodkuje kontrolkę w
        // komórce w pionie, niezależnie od naturalnej wysokości etykiety
        // i pola tekstowego (które się różnią).
        caption.Anchor = AnchorStyles.Left;
        row.Controls.Add(caption, 0, 0);

        _slotNameBox.Width = 280;
        _slotNameBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        _slotNameBox.Margin = new Padding(6, 0, 0, 0);
        _slotNameBox.TextChanged += (_, _) =>
        {
            if (_syncingControls)
            {
                return;
            }

            ActiveProfile.Name = _slotNameBox.Text;
            SaveAndApply("Zmieniono nazwę slotu.");
        };
        row.Controls.Add(_slotNameBox, 1, 0);

        return row;
    }

    private Control BuildTopPanel()
    {
        Panel container = new() { Dock = DockStyle.Fill };

        FlowLayoutPanel top = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Padding = new Padding(0, 8, 0, 0)
        };

        top.Controls.Add(MakeCaptionLabel("Monitor:", 70));
        _monitorBox.Width = 240;
        _monitorBox.Height = RowHeight;
        _monitorBox.Margin = new Padding(6, 0, 0, 0);
        _monitorBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _monitorBox.SelectedIndexChanged += (_, _) =>
        {
            if (_syncingControls || _monitorBox.SelectedIndex < 0)
            {
                return;
            }

            _settings.ActiveMonitorIndex = _monitorBox.SelectedIndex;
            BindCurveSlots();
            BindCurrentCurve();
            SaveAndApply("Monitor zmieniony.");
        };
        top.Controls.Add(_monitorBox);

        _settingsButton.Text = "⚙ Ustawienia";
        _settingsButton.AutoSize = false;
        _settingsButton.Width = 140;
        _settingsButton.Height = RowHeight;
        _settingsButton.FlatStyle = FlatStyle.Flat;
        _settingsButton.Margin = new Padding(16, 0, 0, 0);
        _settingsButton.Click += (_, _) => ShowSettingsWindow();
        top.Controls.Add(_settingsButton);

        // Dodawane w kolejności: element dokowany do prawej krawędzi jako
        // pierwszy, a "wypełniający" panel jako ostatni - tak, aby oba
        // otrzymały właściwą przestrzeń w layoucie.
        container.Controls.Add(_nightModeToggle);
        container.Controls.Add(top);

        return container;
    }

    private void ToggleNightMode()
    {
        _nightMode = !_nightMode;
        _nightScheduleManualOverride = true;
        _settings.NightModeLastState = _nightMode;
        _settings.Save();
        ApplyNightMode();
    }

    public void ApplyNightModeSchedule()
    {
        if (_settings.NightModeSetting != NightModeSetting.DailySchedule
            || _nightScheduleManualOverride)
        {
            return;
        }

        int now = DateTime.Now.Hour * 60 + DateTime.Now.Minute;
        int start = _settings.NightModeStartMinutes;
        int end = _settings.NightModeEndMinutes;
        bool shouldBeNight = start < end
            ? now >= start && now < end
            : now >= start || now < end;
        if (_nightMode != shouldBeNight)
        {
            _nightMode = shouldBeNight;
            ApplyNightMode();
        }
    }

    private void ShowSettingsWindow()
    {
        if (_settingsForm is null || _settingsForm.IsDisposed)
        {
            _settingsForm = new SettingsForm(_settings);
        }

        _settingsForm.RefreshFromSettings();
        _settingsForm.ShowDialog(this);

        // SettingsForm zapisuje ustawienia na bieżąco (przy każdej zmianie), więc
        // tu tylko odświeżamy resztę aplikacji (m.in. ikonkę w zasobniku, jeśli
        // przełącznik "HDR/SDR zamiast '0'" się zmienił).
        _onSettingsChanged();
    }

    public void ApplyCustomAppIcon()
    {
        if (_customAppIconApplied
            && string.Equals(_customAppIconPath, _settings.CustomAppIconPath, StringComparison.Ordinal))
        {
            return;
        }

        Icon? next = TrayIconRenderer.CreateCustomIcon(_settings.CustomAppIconPath);
        _customAppIcon?.Dispose();
        _customAppIcon = next;
        _customAppIconPath = _settings.CustomAppIconPath;
        _customAppIconApplied = true;
        Icon = _customAppIcon ?? _defaultAppIcon;
    }

    private void ApplyNightMode()
    {
        _timeline.DarkMode = _nightMode;

        if (_nightMode)
        {
            BackColor = Color.FromArgb(24, 24, 26);
            ApplyThemeRecursive(this, dark: true);
            _nightModeToggle.Text = "☀ Tryb dzienny";
            _nightModeToggle.BackColor = Color.FromArgb(60, 60, 66);
            _nightModeToggle.ForeColor = Color.White;
        }
        else
        {
            BackColor = Color.FromArgb(243, 244, 246);
            ApplyThemeRecursive(this, dark: false);
            _nightModeToggle.Text = "🌙 Tryb nocny";
            _nightModeToggle.BackColor = SystemColors.Control;
            _nightModeToggle.ForeColor = SystemColors.ControlText;
        }

        UpdateParameterStyles();
        UpdateCurveSlotStyles();
    }

    private static void ApplyThemeRecursive(Control root, bool dark)
    {
        Color back = dark ? Color.FromArgb(32, 33, 36) : Color.FromArgb(243, 244, 246);
        Color panelBack = dark ? Color.FromArgb(40, 41, 45) : Color.White;
        Color fore = dark ? Color.FromArgb(224, 226, 230) : Color.FromArgb(20, 24, 30);
        Color buttonBack = dark ? Color.FromArgb(58, 60, 66) : SystemColors.Control;
        Color editBack = dark ? Color.FromArgb(50, 52, 58) : Color.White;

        root.BackColor = back;

        foreach (Control control in root.Controls)
        {
            switch (control)
            {
                case TimelineControl:
                    // Ma własną logikę kolorów (DarkMode) - pomijamy.
                    break;
                case GroupBox groupBox:
                    groupBox.ForeColor = fore;
                    groupBox.BackColor = back;
                    break;
                case Button button:
                    button.ForeColor = fore;
                    button.BackColor = buttonBack;
                    break;
                case Label label:
                    label.ForeColor = fore;
                    break;
                case TextBox textBox:
                    textBox.BackColor = editBack;
                    textBox.ForeColor = fore;
                    break;
                case ComboBox comboBox:
                    comboBox.BackColor = editBack;
                    comboBox.ForeColor = fore;
                    break;
                case NumericUpDown numeric:
                    numeric.BackColor = editBack;
                    numeric.ForeColor = fore;
                    break;
                case CheckBox checkBox:
                    checkBox.ForeColor = fore;
                    break;
                case Panel panel:
                    panel.BackColor = panelBack;
                    break;
                default:
                    control.ForeColor = fore;
                    control.BackColor = back;
                    break;
            }

            if (control.HasChildren)
            {
                ApplyThemeRecursive(control, dark);
            }
        }
    }

    private Control BuildParameterPanel()
    {
        TableLayoutPanel panel = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2
        };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));

        // Wiersz 1: etykieta "Slot", kwadraciki slotów, a zaraz za ostatnim
        // z nich przycisk "+" (dodawany dynamicznie w BindCurveSlots, żeby
        // zawsze lądował po ostatnim aktualnie istniejącym slocie).
        TableLayoutPanel slotRow = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1
        };
        slotRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70));
        slotRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        slotRow.RowStyles.Add(new RowStyle(SizeType.Absolute, RowHeight));

        Label slotCaption = MakeCaptionLabel("Slot", 70);
        slotCaption.Anchor = AnchorStyles.Left;
        slotRow.Controls.Add(slotCaption, 0, 0);

        _curveSlotPanel.AutoSize = true;
        _curveSlotPanel.FlowDirection = FlowDirection.LeftToRight;
        _curveSlotPanel.WrapContents = false;
        _curveSlotPanel.Margin = new Padding(6, 0, 0, 0);
        _curveSlotPanel.Anchor = AnchorStyles.Left;
        slotRow.Controls.Add(_curveSlotPanel, 1, 0);

        // Wiersz 2: akcje slotu (usuń/kopiuj/przesuń), a po prawej parametry.
        FlowLayoutPanel actionRow = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Margin = new Padding(0)
        };

        Button removeSlotButton = MakeButton("−", 36, (_, _) => RemoveCurveSlot());
        removeSlotButton.Margin = new Padding(0, 0, 0, 0);
        actionRow.Controls.Add(removeSlotButton);

        Button copySlotButton = MakeButton("Kopiuj", 62, (_, _) => CopyCurveSlot());
        actionRow.Controls.Add(copySlotButton);

        Button leftSlotButton = MakeButton("←", 32, (_, _) => MoveCurveSlot(-1));
        actionRow.Controls.Add(leftSlotButton);

        Button rightSlotButton = MakeButton("→", 32, (_, _) => MoveCurveSlot(1));
        actionRow.Controls.Add(rightSlotButton);

        Button resetSlotButton = MakeButton("Reset slotu", 110, (_, _) => ResetCurrentParameterCurve());
        actionRow.Controls.Add(resetSlotButton);

        actionRow.Controls.Add(new Panel { Width = 18, Height = 1, Margin = new Padding(0) });

        FlowLayoutPanel paramRow = new()
        {
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Margin = new Padding(0)
        };
        AddParameterButton(paramRow, ParameterKind.Brightness, "Jasność");
        AddParameterButton(paramRow, ParameterKind.Contrast, "Kontrast");
        AddParameterButton(paramRow, ParameterKind.Saturation, "Saturacja");
        AddParameterButton(paramRow, ParameterKind.Rgb, "RGB");
        actionRow.Controls.Add(paramRow);
        FlowLayoutPanel snapPanel = new()
        {
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Margin = new Padding(12, 0, 0, 0),
            Anchor = AnchorStyles.Right
        };
        snapPanel.Controls.Add(new Label
        {
            Text = "Wartość",
            AutoSize = true,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0, 8, 4, 0)
        });
        ConfigureCurveSnapInput(_curveValueSnapInput);
        _curveValueSnapInput.Width = 58;
        _curveValueSnapInput.ValueChanged += (_, _) => UpdateCurvePointSnapSettings();
        snapPanel.Controls.Add(_curveValueSnapInput);
        snapPanel.Controls.Add(new Label
        {
            Text = "Czas (min)",
            AutoSize = true,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(8, 8, 4, 0)
        });
        ConfigureCurveSnapInput(_curveTimeSnapInput);
        _curveTimeSnapInput.Width = 58;
        _curveTimeSnapInput.ValueChanged += (_, _) => UpdateCurvePointSnapSettings();
        snapPanel.Controls.Add(_curveTimeSnapInput);
        actionRow.Controls.Add(snapPanel);

        panel.Controls.Add(slotRow, 0, 0);
        panel.Controls.Add(actionRow, 0, 1);

        return panel;
    }

    private Control BuildPresetPanel()
    {
        TableLayoutPanel panel = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 14,
            RowCount = 1
        };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, RowHeight));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 64));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 64));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 56));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 56));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 56));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 56));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 64));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 108));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 108));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));

        // Wszystkie kontrolki w tym wierszu używają Anchor (lewo+prawo) razem
        // ze stałą wysokością RowHeight, a nie Dock.Fill - dzięki temu każda
        // z nich jest wyśrodkowana w komórce w tym samym miejscu, niezależnie
        // od tego, czy to pole tekstowe, przycisk czy etykieta.
        _presetBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _presetBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        _presetBox.Margin = new Padding(3, 0, 3, 0);
        _presetBox.SelectedIndexChanged += (_, _) =>
        {
            if (_presetBox.SelectedIndex < 0 || _presetBox.SelectedIndex >= _settings.Presets.Count)
            {
                return;
            }

            Preset preset = _settings.Presets[_presetBox.SelectedIndex];
            _presetNameBox.Text = preset.Name;
            _presetBrightnessInput.Value = preset.Brightness;
            _presetContrastInput.Value = preset.Contrast;
            _presetSaturationInput.Value = preset.Saturation;
            _presetRgbInput.Value = preset.Rgb;
            _presetGammaBox.SelectedIndex = preset.Gamma.HasValue ? GammaSteps.IndexOf(preset.Gamma.Value) + 1 : 0;
        };

        _presetNameBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        _presetNameBox.Height = RowHeight;
        _presetNameBox.Margin = new Padding(3, 0, 3, 0);
        ConfigureNumeric(_presetBrightnessInput, 0, 100);
        ConfigureNumeric(_presetContrastInput, 0, 100);
        ConfigureNumeric(_presetSaturationInput, 0, 100);
        ConfigureNumeric(_presetRgbInput, 0, 100);

        _presetGammaBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _presetGammaBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        _presetGammaBox.Margin = new Padding(3, 0, 3, 0);
        _presetGammaBox.Items.Add("None");
        foreach (double step in GammaSteps.Values)
        {
            _presetGammaBox.Items.Add(step.ToString("0.0"));
        }

        _presetGammaBox.SelectedIndex = 0;

        Button savePresetButton = MakeFillButton("Zapisz preset");
        savePresetButton.Click += (_, _) => SavePresetFromInputs();

        Button applyPresetButton = MakeFillButton("Zastosuj preset");
        applyPresetButton.Click += (_, _) => ApplySelectedPreset();

        Button deletePresetButton = MakeFillButton("Usuń preset");
        deletePresetButton.Click += (_, _) => DeleteSelectedPreset();

        Button movePresetUpButton = MakeFillButton("▲");
        movePresetUpButton.Click += (_, _) => MoveSelectedPreset(-1);

        Button movePresetDownButton = MakeFillButton("▼");
        movePresetDownButton.Click += (_, _) => MoveSelectedPreset(1);

        panel.Controls.Add(Label("Preset"), 0, 0);
        panel.Controls.Add(_presetBox, 1, 0);
        panel.Controls.Add(Label("Nazwa"), 2, 0);
        panel.Controls.Add(_presetNameBox, 3, 0);
        panel.Controls.Add(_presetBrightnessInput, 4, 0);
        panel.Controls.Add(_presetContrastInput, 5, 0);
        panel.Controls.Add(_presetSaturationInput, 6, 0);
        panel.Controls.Add(_presetRgbInput, 7, 0);
        panel.Controls.Add(_presetGammaBox, 8, 0);
        panel.Controls.Add(movePresetUpButton, 9, 0);
        panel.Controls.Add(movePresetDownButton, 10, 0);
        panel.Controls.Add(savePresetButton, 11, 0);
        panel.Controls.Add(applyPresetButton, 12, 0);
        panel.Controls.Add(deletePresetButton, 13, 0);

        return BuildSectionRow("Presety ręczne", panel);
    }

    private Control BuildBottomPanel()
    {
        TableLayoutPanel bottom = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 10,
            RowCount = 1
        };
        bottom.RowStyles.Add(new RowStyle(SizeType.Absolute, RowHeight));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 56));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 72));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 48));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 72));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 1));

        ConfigureNumeric(_hourInput, 0, 23);
        ConfigureNumeric(_minuteInput, 0, 59);
        ConfigureNumeric(_valueInput, 0, 100);

        _hourInput.ValueChanged += (_, _) => UpdateSelectedPointFromInputs();
        _minuteInput.ValueChanged += (_, _) => UpdateSelectedPointFromInputs();
        _valueInput.ValueChanged += (_, _) => UpdateSelectedPointFromInputs();

        Button addButton = MakeFillButton("Dodaj punkt");
        addButton.Click += (_, _) =>
        {
            int minute = (int)_hourInput.Value * 60 + (int)_minuteInput.Value;
            _timeline.AddPoint(minute, (int)_valueInput.Value);
        };

        Button deleteButton = MakeFillButton("Usuń punkt");
        deleteButton.Click += (_, _) => _timeline.DeleteSelectedPoint();

        bottom.Controls.Add(Label("Godz."), 0, 0);
        bottom.Controls.Add(_hourInput, 1, 0);
        bottom.Controls.Add(Label("Min."), 2, 0);
        bottom.Controls.Add(_minuteInput, 3, 0);
        bottom.Controls.Add(Label("Wartość"), 4, 0);
        bottom.Controls.Add(_valueInput, 5, 0);
        bottom.Controls.Add(addButton, 6, 0);
        bottom.Controls.Add(deleteButton, 7, 0);

        return BuildSectionRow("Edycja punktu", bottom);
    }

    // Zamiast GroupBox (ramka + duży odstęp na tytuł, który psuł wyliczenia
    // wysokości i przycinał zawartość) - prosty nagłówek nad treścią, bez
    // obramowania.
    private Control BuildSectionRow(string title, Control content)
    {
        TableLayoutPanel container = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Margin = new Padding(0)
        };
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, 20));
        container.RowStyles.Add(new RowStyle(SizeType.Absolute, RowHeight));

        Label header = new()
        {
            Text = title,
            AutoSize = false,
            Dock = DockStyle.Fill,
            Font = new Font(Font, FontStyle.Bold),
            ForeColor = Color.FromArgb(70, 78, 88),
            TextAlign = ContentAlignment.BottomLeft,
            Margin = new Padding(0)
        };
        container.Controls.Add(header, 0, 0);

        content.Dock = DockStyle.Fill;
        container.Controls.Add(content, 0, 1);

        return container;
    }

    private void AddParameterButton(Control panel, ParameterKind kind, string text)
    {
        RadioButton button = new()
        {
            Appearance = Appearance.Button,
            Text = text,
            AutoSize = false,
            Size = new Size(118, RowHeight),
            TextAlign = ContentAlignment.MiddleCenter,
            Margin = new Padding(0, 0, 10, 0),
            Checked = kind == _selectedParameter
        };
        button.CheckedChanged += (_, _) =>
        {
            if (button.Checked)
            {
                PersistCurrentTimelineToCurve();
                _selectedParameter = kind;
                UpdateParameterStyles();
                BindCurrentCurve();
            }
        };
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = Color.FromArgb(170, 176, 184);

        _parameterButtons[kind] = button;
        panel.Controls.Add(button);
    }

    private void BindMonitors()
    {
        _syncingControls = true;
        int selected = _monitorBox.SelectedIndex;
        _monitorBox.Items.Clear();
        foreach (MonitorConfiguration monitor in _settings.Monitors)
        {
            _monitorBox.Items.Add(monitor.DisplayName);
        }

        if (_monitorBox.Items.Count > 0)
        {
            _monitorBox.SelectedIndex = selected >= 0
                ? Math.Clamp(selected, 0, _monitorBox.Items.Count - 1)
                : _settings.ActiveMonitorIndex;
        }

        _syncingControls = false;
    }

    private void BindCurveSlots()
    {
        _syncingControls = true;
        _curveSlotPanel.Controls.Clear();
        _curveSlotButtons.Clear();

        int activeSlot = ActiveMonitor.ActiveCurveSlot;
        int slotCount = _settings.CurveSlotCount;
        for (int slot = 1; slot <= slotCount; slot++)
        {
            int captured = slot;
            RadioButton slotButton = new()
            {
                Appearance = Appearance.Button,
                Text = slot.ToString(),
                AutoSize = false,
                Size = new Size(42, RowHeight),
                TextAlign = ContentAlignment.MiddleCenter,
                Margin = new Padding(0, 0, 8, 0),
                Checked = captured == activeSlot
            };
            slotButton.CheckedChanged += (_, _) =>
            {
                if (!slotButton.Checked || _syncingControls)
                {
                    return;
                }

                PersistCurrentTimelineToCurve();
                _settings.SwitchActiveCurveSlot(ActiveMonitor, captured);
                UpdateCurveSlotStyles();
                BindCurrentCurve();
                SaveAndApply($"Aktywny slot krzywych: {captured}.");
                _onSettingsChanged();
            };
            slotButton.FlatStyle = FlatStyle.Flat;
            slotButton.FlatAppearance.BorderSize = 1;
            slotButton.FlatAppearance.BorderColor = Color.FromArgb(170, 176, 184);
            _curveSlotButtons[slot] = slotButton;
            _curveSlotPanel.Controls.Add(slotButton);
        }

        // "+" ląduje zawsze zaraz za ostatnim aktualnie istniejącym slotem.
        _addSlotButton.Margin = new Padding(4, 0, 0, 0);
        _curveSlotPanel.Controls.Add(_addSlotButton);

        _syncingControls = false;
        UpdateCurveSlotStyles();
    }


    private void CopyCurveSlot()
    {
        PersistCurrentTimelineToCurve();
        _settings.CopyCurveSlot(ActiveMonitor.ActiveCurveSlot);
        _settings.SwitchActiveCurveSlot(ActiveMonitor, _settings.CurveSlotCount);
        BindCurveSlots(); BindCurrentCurve(); SaveAndApply("Skopiowano slot 24h."); _onSettingsChanged();
    }

    private void MoveCurveSlot(int direction)
    {
        int slot = ActiveMonitor.ActiveCurveSlot;
        if (slot + direction < 1 || slot + direction > _settings.CurveSlotCount) return;
        PersistCurrentTimelineToCurve(); _settings.MoveCurveSlot(slot, direction);
        ActiveMonitor.ActiveCurveSlot += direction;
        BindCurveSlots(); BindCurrentCurve(); SaveAndApply("Przeniesiono ustawienia slotu 24h."); _onSettingsChanged();
    }

    private void AddCurveSlot()
    {
        PersistCurrentTimelineToCurve();
        _settings.AddCurveSlot();
        BindCurveSlots();
        BindCurrentCurve();
        SaveAndApply($"Dodano slot 24h ({_settings.CurveSlotCount}).");
        _onSettingsChanged();
    }

    private void RemoveCurveSlot()
    {
        if (_settings.CurveSlotCount <= 3)
        {
            MessageBox.Show(
                this,
                "Musi pozostać co najmniej 3 sloty 24h.",
                "LightSter",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        int slotToRemove = ActiveMonitor.ActiveCurveSlot;
        PersistCurrentTimelineToCurve();
        _settings.RemoveCurveSlot(slotToRemove);
        _settings.RestoreActiveCurveHState(ActiveMonitor);
        BindCurveSlots();
        BindCurrentCurve();
        SaveAndApply($"Usunięto slot 24h ({slotToRemove}).");
        _onSettingsChanged();
    }

    private void UpdateCurveSlotStyles()
    {
        int activeSlot = ActiveMonitor.ActiveCurveSlot;
        foreach (KeyValuePair<int, RadioButton> entry in _curveSlotButtons)
        {
            StyleToggleButton(entry.Value, entry.Key == activeSlot);
        }
    }

    private void UpdateParameterStyles()
    {
        foreach (KeyValuePair<ParameterKind, RadioButton> entry in _parameterButtons)
        {
            StyleToggleButton(entry.Value, entry.Key == _selectedParameter);
        }
    }

    private static void StyleToggleButton(RadioButton button, bool selected)
    {
        button.BackColor = selected ? Color.FromArgb(176, 186, 198) : Color.FromArgb(230, 233, 238);
        button.ForeColor = selected ? Color.FromArgb(20, 24, 30) : Color.FromArgb(60, 66, 74);
    }

    private void BindPresets()
    {
        int selected = _presetBox.SelectedIndex;
        _presetBox.Items.Clear();
        foreach (Preset preset in _settings.Presets)
        {
            _presetBox.Items.Add(preset.Name);
        }

        if (_presetBox.Items.Count > 0)
        {
            _presetBox.SelectedIndex = Math.Clamp(selected, 0, _presetBox.Items.Count - 1);
            Preset preset = _settings.Presets[_presetBox.SelectedIndex];
            _presetNameBox.Text = preset.Name;
            _presetBrightnessInput.Value = preset.Brightness;
            _presetContrastInput.Value = preset.Contrast;
            _presetSaturationInput.Value = preset.Saturation;
            _presetRgbInput.Value = preset.Rgb;
            _presetGammaBox.SelectedIndex = preset.Gamma.HasValue ? GammaSteps.IndexOf(preset.Gamma.Value) + 1 : 0;
        }
        else
        {
            _presetNameBox.Text = "Nowy preset";
        }
    }

    private void BindCurrentCurve()
    {
        _syncingControls = true;
        try
        {
            _currentMaxValue = 100;
            ActiveCurve.MaxValue = _currentMaxValue;
            ActiveCurve.Normalize();
            _timeline.MaxValue = _currentMaxValue;
            _timeline.ActiveCurveColor = ParameterColor(_selectedParameter);
            _timeline.Points = ActiveCurve.Points
                .Select(point => new CurvePoint(point.Minute, point.Value, _currentMaxValue))
                .ToList();

            // Pozostałe 3 krzywe (te, których teraz NIE edytujemy) - pokazane w tle,
            // przyciemnione, wyłącznie do podglądu (patrz TimelineControl.OnPaint).
            _timeline.SetBackgroundCurves(
                Enum.GetValues<ParameterKind>()
                    .Where(kind => kind != _selectedParameter)
                    .Select(kind => (
                        ParameterColor(kind),
                        (IReadOnlyList<CurvePoint>)ActiveProfile.Curve(kind).Points))
                    .ToList());

            _slotNameBox.Text = ActiveProfile.Name;
            UpdateParameterStyles();

            CurvePoint? point = _timeline.SelectedPoint;
            if (point is not null)
            {
                _hourInput.Value = point.Minute / 60;
                _minuteInput.Value = point.Minute % 60;
                SetNumericValue(_valueInput, 0, _currentMaxValue, point.Value);
            }
            else
            {
                SetNumericValue(_valueInput, 0, _currentMaxValue, _currentMaxValue / 2);
            }
        }
        finally
        {
            _syncingControls = false;
        }

        UpdateCurveSlotStyles();
    }

    private void PersistCurrentTimelineToCurve()
    {
        ParameterCurve curve = ActiveProfile.Curve(_selectedParameter);
        curve.Points = _timeline.Points
            .Select(point => new CurvePoint(point.Minute, point.Value, curve.MaxValue))
            .ToList();
        curve.Normalize();
    }

    private void MarkChanged()
    {
        PersistCurrentTimelineToCurve();
        SaveAndApply($"Zmieniono krzywą: {ParameterLabel(_selectedParameter)}.");
    }

    private void SyncPointInputs()
    {
        if (_syncingControls)
        {
            return;
        }

        _syncingControls = true;
        CurvePoint? point = _timeline.SelectedPoint;
        if (point is not null)
        {
            _hourInput.Value = point.Minute / 60;
            _minuteInput.Value = point.Minute % 60;
            SetNumericValue(_valueInput, 0, _currentMaxValue, point.Value);
        }

        _syncingControls = false;
    }

    private void UpdateSelectedPointFromInputs()
    {
        if (_syncingControls)
        {
            return;
        }

        int minute = (int)_hourInput.Value * 60 + (int)_minuteInput.Value;
        _timeline.UpdateSelectedPoint(minute, (int)_valueInput.Value);
    }

    private void UpdateCurvePointSnapSettings()
    {
        if (_syncingControls)
        {
            return;
        }

        _settings.CurvePointValueSnap = _curveValueSnapInput.Value;
        _settings.CurvePointTimeSnapMinutes = _curveTimeSnapInput.Value;
        _timeline.ValueSnapStep = _settings.CurvePointValueSnap;
        _timeline.TimeSnapMinutes = _settings.CurvePointTimeSnapMinutes;
        SaveSettings("Zmieniono przyciąganie punktów krzywej.");
    }

    private static void ConfigureCurveSnapInput(CurveSnapTextBox input)
    {
        input.Anchor = AnchorStyles.Left;
        input.Height = RowHeight;
        input.Margin = new Padding(3, 0, 3, 0);
    }

    private void ResetCurrentParameterCurve()
    {
        // Usuwa wszystkie punkty tylko dla aktualnie edytowanego parametru
        // (jasność/kontrast/saturacja/RGB) w aktualnie aktywnym slocie i
        // zostawia jeden punkt o godz. 12:00 ze standardową wartością
        // domyślną dla tego parametru.
        ParameterCurve defaults = ParameterCurve.CreateNewSlotDefaultForParameter(_selectedParameter);
        ParameterCurve target = ActiveProfile.Curve(_selectedParameter);
        target.MaxValue = defaults.MaxValue;
        target.Points = defaults.Points
            .Select(point => new CurvePoint(point.Minute, point.Value, defaults.MaxValue))
            .ToList();
        BindCurrentCurve();
        SaveAndApply($"Zresetowano {ParameterLabel(_selectedParameter)} w slocie {ActiveMonitor.ActiveCurveSlot}.");
    }


    private void SavePresetFromInputs()
    {
        string name = string.IsNullOrWhiteSpace(_presetNameBox.Text)
            ? $"Preset {_settings.Presets.Count + 1}"
            : _presetNameBox.Text.Trim();

        Preset preset = new()
        {
            Name = name,
            Brightness = (int)_presetBrightnessInput.Value,
            Contrast = (int)_presetContrastInput.Value,
            Saturation = (int)_presetSaturationInput.Value,
            Rgb = (int)_presetRgbInput.Value,
            Gamma = _presetGammaBox.SelectedIndex > 0 ? GammaSteps.Values[_presetGammaBox.SelectedIndex - 1] : null
        };
        preset.Clamp();

        Preset? existing = _settings.Presets.FirstOrDefault(item => item.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            existing.Brightness = preset.Brightness;
            existing.Contrast = preset.Contrast;
            existing.Saturation = preset.Saturation;
            existing.Rgb = preset.Rgb;
            existing.Gamma = preset.Gamma;
        }
        else
        {
            _settings.Presets.Add(preset);
        }

        BindPresets();
        SaveSettings($"Zapisano preset: {name}.");
    }

    private void ApplySelectedPreset()
    {
        if (_presetBox.SelectedIndex < 0 || _presetBox.SelectedIndex >= _settings.Presets.Count)
        {
            MessageBox.Show(
                this,
                "Wybierz preset do zastosowania.",
                "LightSter",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        Preset preset = _settings.Presets[_presetBox.SelectedIndex];
        if (_settings.PresetAutomationMode == PresetAutomationMode.KeepAutomation
            && _settings.AutomationEnabled)
        {
            _settings.ActiveMonitor.ManualValues.Brightness = preset.Brightness;
            _settings.ActiveMonitor.ManualValues.Contrast = preset.Contrast;
            _settings.ActiveMonitor.ManualValues.Saturation = preset.Saturation;
            _settings.ActiveMonitor.ManualValues.SetUnifiedRgb(preset.Rgb);
            if (preset.Gamma is { } gamma) _settings.ActiveMonitor.ManualValues.Gamma = gamma;
            _settings.ManualValues.CopyFrom(_settings.ActiveMonitor.ManualValues);
            SaveSettings($"Zastosowano preset: {preset.Name}.");
            _applier.ForceAutomationSync(_settings, _onSettingsChanged);
            return;
        }

        _settings.AutomationEnabled = false;
        _applier.ApplyPresetNow(preset, _settings, () =>
        {
            _settings.ActiveMonitor.ManualValues.Brightness = preset.Brightness;
            _settings.ActiveMonitor.ManualValues.Contrast = preset.Contrast;
            _settings.ActiveMonitor.ManualValues.Saturation = preset.Saturation;
            _settings.ActiveMonitor.ManualValues.SetUnifiedRgb(preset.Rgb);
            if (preset.Gamma is { } gamma) _settings.ActiveMonitor.ManualValues.Gamma = gamma;
            _settings.ManualValues.CopyFrom(_settings.ActiveMonitor.ManualValues);
            SaveSettings($"Zastosowano preset: {preset.Name}.");
            _onSettingsChanged();
        });
    }

    private void DeleteSelectedPreset()
    {
        if (_presetBox.SelectedIndex < 0 || _presetBox.SelectedIndex >= _settings.Presets.Count)
        {
            MessageBox.Show(
                this,
                "Wybierz preset do usunięcia.",
                "LightSter",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        string name = _settings.Presets[_presetBox.SelectedIndex].Name;
        _settings.Presets.RemoveAt(_presetBox.SelectedIndex);
        BindPresets();
        SaveSettings($"Usunięto preset: {name}.");
        _onSettingsChanged();
    }

    private void MoveSelectedPreset(int direction)
    {
        int index = _presetBox.SelectedIndex;
        if (index < 0 || index >= _settings.Presets.Count)
        {
            return;
        }

        int newIndex = index + direction;
        if (newIndex < 0 || newIndex >= _settings.Presets.Count)
        {
            return;
        }

        (_settings.Presets[index], _settings.Presets[newIndex]) = (_settings.Presets[newIndex], _settings.Presets[index]);
        BindPresets();
        _presetBox.SelectedIndex = newIndex;
        SaveSettings("Zmieniono kolejność presetów.");
        _onSettingsChanged();
    }

    private void ApplyAutomation(bool force = false)
    {
        if (!_settings.AutomationEnabled && !force)
        {
            return;
        }

        _applier.ForceAutomationSync(_settings, () =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated)
            {
                return;
            }

            try
            {
                BeginInvoke(() =>
                {
                    if (!IsDisposed && !Disposing)
                    {
                        _onSettingsChanged();
                    }
                });
            }
            catch (InvalidOperationException)
            {
                // The form handle may be destroyed while the asynchronous apply
                // operation is completing during application shutdown.
            }
        });
    }

    private void SaveSettings(string status)
    {
        // Okno nie pokazuje już na bieżąco informacji o wykonywanych
        // czynnościach - zapisujemy ustawienia w tle, a błąd (rzadki
        // przypadek) sygnalizujemy dopiero wtedy, gdy faktycznie wystąpi.
        _ = status;
        try
        {
            _settings.Save();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                $"Nie zapisano ustawień: {ex.Message}",
                "LightSter",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    // Zapisuje ustawienia i od razu wymusza zastosowanie aktualnych krzywych
    // na monitorze - zastępuje dawne osobne przyciski "Zapisz" i "Zastosuj",
    // które zniknęły z okna Krzywych.
    private void SaveAndApply(string status)
    {
        SaveSettings(status);
        ApplyAutomation(force: true);
    }

    private static void ConfigureNumeric(NumericUpDown input, int min, int max)
    {
        input.Minimum = min;
        input.Maximum = max;
        input.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        input.Height = RowHeight;
        input.Margin = new Padding(3, 0, 3, 0);
        input.TextAlign = HorizontalAlignment.Center;
    }

    // Przycisk wypełniający szerokość komórki, ale ze stałą wysokością
    // (RowHeight) i wyśrodkowany w komórce dzięki Anchor - tak samo jak pola
    // tekstowe i combo w tym samym wierszu, żeby wszystko leżało na jednej
    // linii środkowej.
    private static Button MakeFillButton(string text)
    {
        return new Button
        {
            Text = text,
            Anchor = AnchorStyles.Left | AnchorStyles.Right,
            Height = RowHeight,
            TextAlign = ContentAlignment.MiddleCenter,
            Margin = new Padding(3, 0, 3, 0)
        };
    }

    private static void SetNumericValue(NumericUpDown input, int min, int max, int value)
    {
        int safe = Math.Clamp(value, min, max);
        if (input.Minimum != min)
        {
            input.Minimum = min;
        }

        if (input.Maximum != max)
        {
            input.Maximum = max;
        }

        if ((int)input.Value != safe)
        {
            input.Value = safe;
        }
    }

    // AutoSize=false jest tu kluczowe: domyślnie Label ma AutoSize=true, co
    // w połączeniu z Dock=Fill w wąskiej kolumnie TableLayoutPanel powodowało
    // łamanie tekstu w dowolnym miejscu (np. "Preset" -> "Prese" / "t").
    private static Label Label(string text)
    {
        return new Label
        {
            Text = text,
            AutoSize = false,
            AutoEllipsis = false,
            TextAlign = ContentAlignment.MiddleLeft,
            Anchor = AnchorStyles.Left | AnchorStyles.Right,
            Height = RowHeight,
            Margin = new Padding(0)
        };
    }

    private static Label MakeCaptionLabel(string text, int width)
    {
        return new Label
        {
            Text = text,
            AutoSize = false,
            AutoEllipsis = false,
            Width = width,
            Height = RowHeight,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0)
        };
    }

    private static Button MakeButton(string text, int width, EventHandler onClick)
    {
        Button button = new()
        {
            Text = text,
            Width = width,
            Height = RowHeight,
            TextAlign = ContentAlignment.MiddleCenter,
            Margin = new Padding(8, 0, 0, 0)
        };
        button.Click += onClick;
        return button;
    }

    private static string ParameterLabel(ParameterKind kind)
    {
        return kind switch
        {
            ParameterKind.Brightness => "jasność",
            ParameterKind.Contrast => "kontrast",
            ParameterKind.Saturation => "saturacja",
            ParameterKind.Rgb => "RGB",
            _ => "parametr"
        };
    }

    /// <summary>
    /// Kolor krzywej na wykresie, osobny dla każdego parametru - jasność żółty,
    /// kontrast zielony, saturacja niebieski, RGB (razem) ciemniejszy szary (żeby był
    /// widoczny zarówno na jasnym tle, jak i po przyciemnieniu w tle, gdy nie jest
    /// aktywnie edytowany).
    /// </summary>
    private static Color ParameterColor(ParameterKind kind)
    {
        return kind switch
        {
            ParameterKind.Brightness => Color.FromArgb(196, 138, 4),
            ParameterKind.Contrast => Color.FromArgb(43, 138, 68),
            ParameterKind.Saturation => Color.FromArgb(37, 100, 194),
            ParameterKind.Rgb => Color.FromArgb(90, 92, 98),
            _ => Color.FromArgb(21, 87, 129)
        };
    }
}
