namespace LightSter;

/// <summary>
/// Okno "Ustawienia" otwierane z panelu Krzywych (przycisk, który zastąpił
/// dawny checkbox "Automatyczne krzywe"). Wszystkie zmiany tu stosują się i
/// zapisują natychmiast (nie ma Cofnij/Anuluj), tak samo jak reszta interfejsu
/// LightStera.
/// </summary>
internal sealed class SettingsForm : Form
{
    private const int RowHeight = 28;

    private readonly AppSettings _settings;
    private readonly CheckBox _autostartCheckBox = new();
    private readonly CheckBox _hdrTrayIconCheckBox = new();

    private readonly RadioButton _offsetKeepOnManualToggle = new();
    private readonly RadioButton _offsetResetOnManualToggle = new();

    private readonly RadioButton _hReenableAfterAutomation = new();
    private readonly RadioButton _hStayOffAfterAutomation = new();

    private readonly Panel _guzik3Panel = new();
    private readonly RadioButton _offsetKeepWhenReenabled = new();
    private readonly RadioButton _offsetResetWhenReenabled = new();
    private readonly RadioButton _resetHOnRestart = new();
    private readonly RadioButton _keepHOnRestart = new();
    private readonly RadioButton _wheelLegacy = new();
    private readonly RadioButton _wheelHeaderFive = new();
    private readonly RadioButton _wheelMixed = new();
    private readonly CheckBox _farJumpCheckBox = new();
    private readonly RadioButton _automationRestartAuto = new();
    private readonly RadioButton _automationRestartOff = new();
    private readonly RadioButton _automationRestartOn = new();
    private readonly RadioButton _lastCurve = new();
    private readonly RadioButton _selectedCurve = new();
    private readonly ComboBox _startupCurveBox = new();
    private readonly RadioButton _disableAutomationAfterPlus = new();
    private readonly RadioButton _keepAutomationAfterPlus = new();
    private readonly Panel _plusHSettingsPanel = new();
    private readonly RadioButton _rememberHAfterPlus = new();
    private readonly RadioButton _disableHAfterPlus = new();
    private readonly RadioButton _nightRemember = new();
    private readonly RadioButton _nightDaily = new();
    private readonly RadioButton _presetDisableAutomation = new();
    private readonly RadioButton _presetKeepAutomation = new();
    private readonly RadioButton _gammaResetDisableAutomation = new();
    private readonly RadioButton _gammaResetKeepCurrentAutomation = new();
    private readonly RadioButton _gammaResetMouseMiddle = new();
    private readonly RadioButton _gammaResetMouseLeft = new();
    private readonly RadioButton _gammaResetMouseRight = new();
    private readonly RadioButton _hRememberPerCurve = new();
    private readonly RadioButton _hDisableAndReset = new();
    private readonly CheckBox _gammaResetEnabled = new();
    private readonly Panel _gammaResetPanel = new();
    private readonly CheckBox _gammaResetBrightnessEnabled = new();
    private readonly CheckBox _gammaResetContrastEnabled = new();
    private readonly CheckBox _gammaResetSaturationEnabled = new();
    private readonly CheckBox _gammaResetRgbEnabled = new();
    private readonly CheckBox _gammaResetGammaEnabled = new();
    private readonly NumericUpDown _gammaResetBrightness = new();
    private readonly NumericUpDown _gammaResetContrast = new();
    private readonly NumericUpDown _gammaResetSaturation = new();
    private readonly NumericUpDown _gammaResetRgb = new();
    private readonly ComboBox _gammaResetGamma = new();
    private readonly Label _gammaResetBrightnessNone = new() { Text = "none" };
    private readonly Label _gammaResetContrastNone = new() { Text = "none" };
    private readonly Label _gammaResetSaturationNone = new() { Text = "none" };
    private readonly Label _gammaResetRgbNone = new() { Text = "none" };
    private readonly Label _gammaResetGammaNone = new() { Text = "none" };
    private readonly Panel _nightSchedulePanel = new();
    private readonly ComboBox _nightStart = new();
    private readonly ComboBox _nightEnd = new();
    private readonly Button _selectAppIconButton = new();
    private readonly Button _resetAppIconButton = new();
    private readonly Button _selectTrayIconButton = new();
    private readonly Button _resetTrayIconButton = new();
    private readonly RadioButton _manualValuesUnchanged = new();
    private readonly RadioButton _manualValuesFromTable = new();
    private readonly Panel _manualValuesPanel = new();
    private readonly CheckBox _startupBrightnessEnabled = new();
    private readonly CheckBox _startupContrastEnabled = new();
    private readonly CheckBox _startupSaturationEnabled = new();
    private readonly CheckBox _startupRgbEnabled = new();
    private readonly CheckBox _startupGammaEnabled = new();
    private readonly NumericUpDown _startupBrightness = new();
    private readonly NumericUpDown _startupContrast = new();
    private readonly NumericUpDown _startupSaturation = new();
    private readonly NumericUpDown _startupRgb = new();
    private readonly ComboBox _startupGamma = new();
    private readonly Panel _startupGammaHolder = new();
    private readonly Label _startupGammaNone = new() { Text = "none", AutoSize = true };
    private readonly Dictionary<Control, Panel> _startupValueHolders = [];
    private readonly Label _startupBrightnessNone = new() { Text = "none", AutoSize = true, Visible = false };
    private readonly Label _startupContrastNone = new() { Text = "none", AutoSize = true, Visible = false };
    private readonly Label _startupSaturationNone = new() { Text = "none", AutoSize = true, Visible = false };
    private readonly Label _startupRgbNone = new() { Text = "none", AutoSize = true, Visible = false };

    private bool _syncing;

    public SettingsForm(AppSettings settings)
    {
        _settings = settings;

        Text = "LightSter - Ustawienia";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        Font = new Font("Segoe UI", 9.5f);
        ClientSize = new Size(940, 650);
        MinimumSize = new Size(760, 500);
        BackColor = Color.FromArgb(243, 244, 246);

        BuildLayout();
        LoadValues();
        WireEvents();
    }

    private Panel CreateStartupValueHolder(Control value, Label noneLabel)
    {
        Panel holder = new() { Width = 80, Height = 24, Margin = new Padding(0) };
        value.Dock = DockStyle.Fill;
        noneLabel.Dock = DockStyle.Fill;
        noneLabel.TextAlign = ContentAlignment.MiddleLeft;
        holder.Controls.Add(noneLabel);
        holder.Controls.Add(value);
        _startupValueHolders[value] = holder;
        return holder;
    }

    private static void ConfigureTimeCombo(ComboBox combo)
    {
        combo.DropDownStyle = ComboBoxStyle.DropDownList;
        combo.Width = 70;
        for (int minutes = 0; minutes < 1440; minutes += 30)
        {
            combo.Items.Add($"{minutes / 60:00}:{minutes % 60:00}");
        }
    }

    private void BuildLayout()
    {
        FlowLayoutPanel root = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false
        };
        Controls.Add(root);

        FlowLayoutPanel left = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0, 0, 16, 0)
        };
        FlowLayoutPanel right = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0)
        };
        root.Controls.Add(left);
        root.Controls.Add(right);

        _autostartCheckBox.Text = "Autostart";
        _autostartCheckBox.AutoSize = true;
        _autostartCheckBox.Height = RowHeight;
        _autostartCheckBox.Margin = new Padding(0, 0, 0, 12);
        left.Controls.Add(_autostartCheckBox);

        _hdrTrayIconCheckBox.Text = "HDR/SDR ICO";
        _hdrTrayIconCheckBox.AutoSize = true;
        _hdrTrayIconCheckBox.Height = RowHeight;
        _hdrTrayIconCheckBox.Margin = new Padding(0, 0, 0, 16);
        left.Controls.Add(_hdrTrayIconCheckBox);

        left.Controls.Add(MakeSubLabel("Po wyłączeniu krzywych"));
        left.Controls.Add(MakeRadioGroup(
            _hReenableAfterAutomation, "Włącz H spowrotem",
            _hStayOffAfterAutomation, "Wyłącz"));

        _guzik3Panel.AutoSize = true;
        _guzik3Panel.Margin = new Padding(0);
        FlowLayoutPanel guzik3Flow = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0)
        };
        _guzik3Panel.Controls.Add(guzik3Flow);
        guzik3Flow.Controls.Add(MakeSubLabel("Oraz"));
        guzik3Flow.Controls.Add(MakeRadioGroup(
            _offsetResetWhenReenabled, "Resetuj",
            _offsetKeepWhenReenabled, "Zapamiętaj"));
        left.Controls.Add(_guzik3Panel);

        left.Controls.Add(MakeSubLabel("Po wyłączeniu H"));
        left.Controls.Add(MakeRadioGroup(
            _offsetResetOnManualToggle, "Resetuj",
            _offsetKeepOnManualToggle, "Zapamiętaj"));
        left.Controls.Add(MakeSubLabel("H po zmianie krzywej"));
        left.Controls.Add(MakeRadioGroup(
            (_hRememberPerCurve, "Zapamiętaj stan osobno dla każdej krzywej"),
            (_hDisableAndReset, "Wyłącz H i wyzeruj wartość")));

        left.Controls.Add(MakeSubLabel("Skok Kontrastu i Saturacji"));
        left.Controls.Add(MakeRadioGroup(
            (_wheelLegacy, "Nad napisem co 1, nad suwakiem co 2"),
            (_wheelHeaderFive, "Nad napisem co 5, nad suwakiem co 2"),
            (_wheelMixed, "Nad napisem co 1, nad suwakiem co 2 i co 5")));
        _farJumpCheckBox.Text = "Daleki skok";
        _farJumpCheckBox.AutoSize = true;
        _farJumpCheckBox.Margin = new Padding(16, 0, 0, 8);
        left.Controls.Add(_farJumpCheckBox);

        left.Controls.Add(MakeSubLabel("Po kliknięciu +"));
        left.Controls.Add(MakeRadioGroup(
            (_disableAutomationAfterPlus, "Wyłącz Automatyczne Krzywe"),
            (_keepAutomationAfterPlus, "Zostaw Włączone Automatyczne Krzywe")));
        _plusHSettingsPanel.AutoSize = true;
        _plusHSettingsPanel.Margin = new Padding(0);
        FlowLayoutPanel plusHFlow = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0)
        };
        plusHFlow.Controls.Add(MakeSubLabel("Po Kliknięciu +"));
        plusHFlow.Controls.Add(MakeRadioGroup(
            (_rememberHAfterPlus, "Zapamiętaj H"),
            (_disableHAfterPlus, "Wyłącz H")));
        _plusHSettingsPanel.Controls.Add(plusHFlow);
        left.Controls.Add(_plusHSettingsPanel);

        left.Controls.Add(MakeSubLabel("Po restarcie komputera"));
        left.Controls.Add(MakeRadioGroup(
            (_automationRestartOff, "Krzywa \"OFF\""),
            (_automationRestartOn, "Krzywa ON"),
            (_automationRestartAuto, "Krzywa Ostatnia")));

        left.Controls.Add(MakeSubLabel("Po restarcie komputera"));
        left.Controls.Add(MakeRadioGroup(
            _resetHOnRestart, "Wyłącz i wyzeruj wartość suwaka H",
            _keepHOnRestart, "Zapamiętaj ostatni stan H"));

        left.Controls.Add(MakeSubLabel("Po restarcie komputera"));
        left.Controls.Add(MakeRadioGroup(
            _lastCurve, "Ostatnia Automatyczna Krzywa",
            _selectedCurve, "Wybrana Automatyczna Krzywa"));
        _startupCurveBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _startupCurveBox.Width = 220;
        _startupCurveBox.Margin = new Padding(16, 0, 0, 8);
        left.Controls.Add(_startupCurveBox);

        right.Controls.Add(MakeSubLabel("Presety Ręczne"));
        right.Controls.Add(MakeRadioGroup(
            (_presetKeepAutomation, "Nie wyłączaj Automatycznych Krzywych"),
            (_presetDisableAutomation, "Wyłącz Automatyczne Krzywe")));

        right.Controls.Add(MakeSubLabel("Wartości ręczne przy uruchomieniu"));
        right.Controls.Add(MakeRadioGroup(
            (_manualValuesUnchanged, "Bez Zmian"),
            (_manualValuesFromTable, "Wartości z Tabeli")));
        _manualValuesPanel.AutoSize = true;
        _manualValuesPanel.Margin = new Padding(0);
        FlowLayoutPanel manualFlow = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0)
        };
        manualFlow.Controls.Add(MakeManualValueRow("Jasność", _startupBrightnessEnabled, _startupBrightness, _startupBrightnessNone));
        manualFlow.Controls.Add(MakeManualValueRow("Kontrast", _startupContrastEnabled, _startupContrast, _startupContrastNone));
        manualFlow.Controls.Add(MakeManualValueRow("Saturacja", _startupSaturationEnabled, _startupSaturation, _startupSaturationNone));
        manualFlow.Controls.Add(MakeManualValueRow("RGB", _startupRgbEnabled, _startupRgb, _startupRgbNone));
        manualFlow.Controls.Add(MakeManualGammaRow());
        _manualValuesPanel.Controls.Add(manualFlow);
        right.Controls.Add(_manualValuesPanel);

        FlowLayoutPanel gammaResetHeader = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = true,
            WrapContents = false,
            Margin = new Padding(0)
        };
        _gammaResetEnabled.Text = "Reset ręczny na gammie";
        _gammaResetEnabled.AutoSize = true;
        _gammaResetEnabled.Margin = new Padding(0, 0, 0, 4);
        gammaResetHeader.Controls.Add(_gammaResetEnabled);
        right.Controls.Add(gammaResetHeader);
        BuildGammaResetPanel();
        right.Controls.Add(_gammaResetPanel);

        right.Controls.Add(MakeSubLabel("Tryb Nocny"));
        right.Controls.Add(MakeRadioGroup(
            (_nightRemember, "Zapamiętaj Ostatni Stan"),
            (_nightDaily, "Tryb Dobowy")));
        _nightSchedulePanel.AutoSize = true;
        FlowLayoutPanel nightFlow = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = true,
            WrapContents = false,
            Margin = new Padding(16, 0, 0, 8)
        };
        nightFlow.Controls.Add(new Label { Text = "Ciemny od", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft });
        ConfigureTimeCombo(_nightStart);
        nightFlow.Controls.Add(_nightStart);
        nightFlow.Controls.Add(new Label { Text = " do ", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft });
        ConfigureTimeCombo(_nightEnd);
        nightFlow.Controls.Add(_nightEnd);
        _nightSchedulePanel.Controls.Add(nightFlow);
        right.Controls.Add(_nightSchedulePanel);

        right.Controls.Add(MakeSubLabel("Zmiana Ikonek"));
        right.Controls.Add(MakeIconRow(
            "Ikona aplikacji", string.Empty,
            _selectAppIconButton, _resetAppIconButton,
            () => ChooseIcon(true), () => ResetIcon(true)));
        right.Controls.Add(MakeIconRow(
            "Ikona tray", string.Empty,
            _selectTrayIconButton, _resetTrayIconButton,
            () => ChooseIcon(false), () => ResetIcon(false)));

        BuildCategoryLayout(root, left, right);
    }

    private void BuildCategoryLayout(Control root, FlowLayoutPanel left, FlowLayoutPanel right)
    {
        Control[] leftControls = left.Controls.Cast<Control>().ToArray();
        Control[] rightControls = right.Controls.Cast<Control>().ToArray();
        Controls.Remove(root);

        TableLayoutPanel shell = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            Padding = new Padding(12),
            BackColor = BackColor
        };
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 165));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        Controls.Add(shell);

        Panel navigation = new()
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(232, 234, 238),
            Padding = new Padding(8)
        };
        FlowLayoutPanel navigationItems = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Margin = new Padding(0)
        };
        navigation.Controls.Add(navigationItems);
        shell.Controls.Add(navigation, 0, 0);

        Panel pageHost = new()
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(16, 8, 8, 8),
            BackColor = Color.White
        };
        shell.Controls.Add(pageHost, 1, 0);

        List<(string Name, Control[] Controls)> categories =
        [
            ("Ogólne", [leftControls[0], leftControls[1], rightControls[10], rightControls[11], rightControls[12]]),
            ("Suwaki", [leftControls[9], leftControls[10], leftControls[11]]),
            ("Krzywe", [.. leftControls[2..9], .. leftControls[12..15]]),
            ("Presety", [rightControls[0], rightControls[1], rightControls[5], rightControls[6]]),
            ("Start", [.. leftControls[15..], .. rightControls[2..5]]),
            ("Wygląd", [.. rightControls[7..10]])
        ];
        List<Panel> pages = [];
        List<Button> buttons = [];

        foreach ((string name, Control[] controls) in categories)
        {
            Panel page = new()
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                BackColor = Color.White,
                Visible = pages.Count == 0
            };
            Label heading = new()
            {
                Text = name,
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                ForeColor = Color.FromArgb(40, 45, 52),
                Location = new Point(12, 8)
            };
            FlowLayoutPanel content = new()
            {
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Location = new Point(12, 38),
                Margin = new Padding(0)
            };
            page.Controls.Add(content);
            page.Controls.Add(heading);
            pageHost.Controls.Add(page);
            pages.Add(page);

            foreach (Control control in controls)
            {
                control.Parent?.Controls.Remove(control);
                content.Controls.Add(control);
            }

            Button button = new()
            {
                Text = name,
                Width = 135,
                Height = 36,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0),
                Margin = new Padding(0, 0, 0, 4),
                ForeColor = Color.FromArgb(40, 45, 52),
                Tag = pages.Count - 1
            };
            button.FlatAppearance.BorderSize = 0;
            button.Click += (_, _) => SelectCategory((int)button.Tag, pages, buttons);
            navigationItems.Controls.Add(button);
            buttons.Add(button);
        }

        Button closeButton = new()
        {
            Text = "Zamknij",
            Width = 100,
            Height = 30,
            Anchor = AnchorStyles.Right | AnchorStyles.Bottom,
            Margin = new Padding(0, 0, 0, 2)
        };
        closeButton.Click += (_, _) => Close();
        FlowLayoutPanel footer = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            Padding = new Padding(0, 6, 0, 0)
        };
        footer.Controls.Add(closeButton);
        shell.Controls.Add(footer, 0, 1);
        shell.SetColumnSpan(footer, 2);
        SelectCategory(0, pages, buttons);
    }

    private static void SelectCategory(int selectedIndex, IReadOnlyList<Panel> pages, IReadOnlyList<Button> buttons)
    {
        for (int index = 0; index < pages.Count; index++)
        {
            pages[index].Visible = index == selectedIndex;
            buttons[index].BackColor = index == selectedIndex
                ? Color.FromArgb(205, 218, 238)
                : Color.FromArgb(232, 234, 238);
        }
    }

    private static Control MakeIconRow(
        string label,
        string sizeHint,
        Button choose,
        Button reset,
        Action chooseAction,
        Action resetAction)
    {
        FlowLayoutPanel row = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = true,
            WrapContents = false,
            Margin = new Padding(0, 0, 0, 4)
        };
        Label text = new()
        {
            Text = string.IsNullOrEmpty(sizeHint) ? label : $"{label} ({sizeHint})",
            AutoSize = true,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0, 5, 8, 0)
        };
        choose.Text = "...";
        choose.Width = 32;
        choose.Height = 24;
        choose.Margin = new Padding(0);
        choose.Click += (_, _) => chooseAction();
        reset.Text = "X";
        reset.Width = 28;
        reset.Height = 24;
        reset.Margin = new Padding(4, 0, 0, 0);
        reset.Click += (_, _) => resetAction();
        row.Controls.Add(text);
        row.Controls.Add(choose);
        row.Controls.Add(reset);
        return row;
    }

    private static Label MakeSubLabel(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
        Margin = new Padding(0, 4, 0, 4)
    };

    private static FlowLayoutPanel MakeRadioGroup(
        RadioButton first, string firstText,
        RadioButton second, string secondText)
    {
        first.Text = firstText;
        first.AutoSize = true;
        first.Margin = new Padding(16, 0, 0, 0);

        second.Text = secondText;
        second.AutoSize = true;
        second.Margin = new Padding(16, 4, 0, 0);

        FlowLayoutPanel panel = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0, 0, 0, 4)
        };
        panel.Controls.Add(first);
        panel.Controls.Add(second);
        return panel;
    }

    private static FlowLayoutPanel MakeRadioGroup(
        params (RadioButton Radio, string Text)[] options)
    {
        FlowLayoutPanel panel = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            Margin = new Padding(0)
        };

        foreach ((RadioButton radio, string text) in options)
        {
            radio.Text = text;
            radio.AutoSize = true;
            radio.Margin = new Padding(16, 0, 0, 4);
            panel.Controls.Add(radio);
        }

        return panel;
    }

    private void LoadValues()
    {
        _syncing = true;

        _autostartCheckBox.Checked = _settings.AutostartEnabled;
        _hdrTrayIconCheckBox.Checked = _settings.ShowHdrStatusIconInTray;

        _offsetResetOnManualToggle.Checked = _settings.ResetOffsetOnManualHToggle;
        _offsetKeepOnManualToggle.Checked = !_settings.ResetOffsetOnManualHToggle;
        _hRememberPerCurve.Checked = _settings.HSlotChangeMode == HSlotChangeMode.RememberPerCurve;
        _hDisableAndReset.Checked = _settings.HSlotChangeMode == HSlotChangeMode.DisableAndReset;

        _hReenableAfterAutomation.Checked = _settings.ReenableHAfterAutomationResume;
        _hStayOffAfterAutomation.Checked = !_settings.ReenableHAfterAutomationResume;

        _offsetResetWhenReenabled.Checked = _settings.ResetOffsetWhenHReenabledByAutomation;
        _offsetKeepWhenReenabled.Checked = !_settings.ResetOffsetWhenHReenabledByAutomation;

        _guzik3Panel.Visible = _settings.ReenableHAfterAutomationResume;

        _resetHOnRestart.Checked = _settings.ResetHOnRestart;
        _keepHOnRestart.Checked = !_settings.ResetHOnRestart;

        _wheelLegacy.Checked = _settings.ContrastSaturationWheelMode == QuickAdjustWheelMode.Legacy;
        _wheelHeaderFive.Checked = _settings.ContrastSaturationWheelMode == QuickAdjustWheelMode.HeaderFive;
        _wheelMixed.Checked = _settings.ContrastSaturationWheelMode == QuickAdjustWheelMode.MixedSlider;
        _farJumpCheckBox.Checked = _settings.ContrastSaturationFarJump;
        UpdateWheelOptionsVisibility();

        _disableAutomationAfterPlus.Checked = !_settings.KeepAutomationAfterPlus;
        _keepAutomationAfterPlus.Checked = _settings.KeepAutomationAfterPlus;
        _rememberHAfterPlus.Checked = _settings.PlusHMode == PlusHMode.Remember;
        _disableHAfterPlus.Checked = _settings.PlusHMode == PlusHMode.Disable;
        _plusHSettingsPanel.Visible = !_settings.KeepAutomationAfterPlus;

        _automationRestartAuto.Checked = _settings.AutomationRestartMode == AutomationRestartMode.Auto;
        _automationRestartOff.Checked = _settings.AutomationRestartMode == AutomationRestartMode.Off;
        _automationRestartOn.Checked = _settings.AutomationRestartMode == AutomationRestartMode.On;

        _startupCurveBox.Items.Clear();
        for (int slot = 1; slot <= _settings.CurveSlotCount; slot++)
        {
            string name = _settings.Monitors[0].CurveSlots[slot - 1].Name;
            _startupCurveBox.Items.Add($"{slot}: {name}");
        }
        _startupCurveBox.SelectedIndex = _startupCurveBox.Items.Count == 0
            ? -1
            : Math.Clamp(_settings.StartupCurveSlot - 1, 0, _startupCurveBox.Items.Count - 1);
        _lastCurve.Checked = !_settings.UseStartupCurveSelection;
        _selectedCurve.Checked = _settings.UseStartupCurveSelection;
        _startupCurveBox.Enabled = _settings.UseStartupCurveSelection;

        _manualValuesUnchanged.Checked = !_settings.UseStartupManualValues;
        _manualValuesFromTable.Checked = _settings.UseStartupManualValues;
        ConfigureStartupNumeric(_startupBrightness, _settings.StartupBrightness);
        ConfigureStartupNumeric(_startupContrast, _settings.StartupContrast);
        ConfigureStartupNumeric(_startupSaturation, _settings.StartupSaturation);
        ConfigureStartupNumeric(_startupRgb, _settings.StartupRgb);
        _startupGamma.Items.Clear();
        foreach (double gamma in GammaSteps.Values.Reverse())
        {
            _startupGamma.Items.Add(gamma.ToString("0.0"));
        }
        _startupGamma.SelectedIndex = GammaSteps.Values.Length - 1 - GammaSteps.IndexOf(_settings.StartupGamma);
        _startupBrightnessEnabled.Checked = _settings.StartupBrightnessEnabled;
        _startupContrastEnabled.Checked = _settings.StartupContrastEnabled;
        _startupSaturationEnabled.Checked = _settings.StartupSaturationEnabled;
        _startupRgbEnabled.Checked = _settings.StartupRgbEnabled;
        _startupGammaEnabled.Checked = _settings.StartupGammaEnabled;
        _manualValuesPanel.Visible = _settings.UseStartupManualValues;
        UpdateManualValueControls();
        _presetKeepAutomation.Checked = _settings.PresetAutomationMode == PresetAutomationMode.KeepAutomation;
        _presetDisableAutomation.Checked = !_presetKeepAutomation.Checked;
        ConfigureStartupNumeric(_gammaResetBrightness, _settings.GammaResetBrightness);
        ConfigureStartupNumeric(_gammaResetContrast, _settings.GammaResetContrast);
        ConfigureStartupNumeric(_gammaResetSaturation, _settings.GammaResetSaturation);
        ConfigureStartupNumeric(_gammaResetRgb, _settings.GammaResetRgb);
        _gammaResetGamma.SelectedIndex = Math.Clamp(
            GammaSteps.Values.Length - 1 - GammaSteps.IndexOf(_settings.GammaResetGamma),
            0,
            Math.Max(0, _gammaResetGamma.Items.Count - 1));
        _gammaResetBrightnessEnabled.Checked = _settings.GammaResetBrightnessEnabled;
        _gammaResetContrastEnabled.Checked = _settings.GammaResetContrastEnabled;
        _gammaResetSaturationEnabled.Checked = _settings.GammaResetSaturationEnabled;
        _gammaResetRgbEnabled.Checked = _settings.GammaResetRgbEnabled;
        _gammaResetGammaEnabled.Checked = _settings.GammaResetGammaEnabled;
        _gammaResetEnabled.Checked = _settings.GammaManualResetEnabled;
        _gammaResetPanel.Visible = _settings.GammaManualResetEnabled;
        _gammaResetKeepCurrentAutomation.Checked =
            _settings.GammaResetAutomationMode == GammaResetAutomationMode.KeepCurrent;
        _gammaResetDisableAutomation.Checked =
            _settings.GammaResetAutomationMode == GammaResetAutomationMode.DisableAutomation;
        _gammaResetMouseMiddle.Checked = _settings.GammaResetMouseButton == GammaResetMouseButton.Middle;
        _gammaResetMouseLeft.Checked = _settings.GammaResetMouseButton == GammaResetMouseButton.Left;
        _gammaResetMouseRight.Checked = _settings.GammaResetMouseButton == GammaResetMouseButton.Right;
        UpdateGammaResetControls();
        _nightRemember.Checked = _settings.NightModeSetting == NightModeSetting.RememberLast;
        _nightDaily.Checked = _settings.NightModeSetting == NightModeSetting.DailySchedule;
        _nightStart.SelectedIndex = _settings.NightModeStartMinutes / 30;
        _nightEnd.SelectedIndex = _settings.NightModeEndMinutes / 30;
        _nightSchedulePanel.Visible = _settings.NightModeSetting == NightModeSetting.DailySchedule;

        _syncing = false;
    }

    public void RefreshFromSettings()
    {
        LoadValues();
    }

    private void WireEvents()
    {
        _autostartCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            _settings.AutostartEnabled = _autostartCheckBox.Checked;
            AutostartManager.SetEnabled(_settings.AutostartEnabled);
            Save();
        };

        _hdrTrayIconCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            _settings.ShowHdrStatusIconInTray = _hdrTrayIconCheckBox.Checked;
            Save();
        };

        _offsetResetOnManualToggle.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetResetOnManualToggle.Checked)
            {
                return;
            }

            _settings.ResetOffsetOnManualHToggle = true;
            Save();
        };

        _offsetKeepOnManualToggle.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetKeepOnManualToggle.Checked)
            {
                return;
            }

            _settings.ResetOffsetOnManualHToggle = false;
            Save();
        };
        _hRememberPerCurve.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_hRememberPerCurve.Checked) return;
            _settings.HSlotChangeMode = HSlotChangeMode.RememberPerCurve;
            _settings.ActiveMonitor.ActiveProfile.ShowTimeOffsetPanel = _settings.ShowSlotTimeOffsetPanel;
            Save();
        };
        _hDisableAndReset.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_hDisableAndReset.Checked) return;
            _settings.HSlotChangeMode = HSlotChangeMode.DisableAndReset;
            Save();
        };

        _hReenableAfterAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_hReenableAfterAutomation.Checked)
            {
                return;
            }

            _settings.ReenableHAfterAutomationResume = true;
            _guzik3Panel.Visible = true;
            Save();
        };

        _hStayOffAfterAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_hStayOffAfterAutomation.Checked)
            {
                return;
            }

            _settings.ReenableHAfterAutomationResume = false;
            _guzik3Panel.Visible = false;
            Save();
        };

        _offsetResetWhenReenabled.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetResetWhenReenabled.Checked)
            {
                return;
            }

            _settings.ResetOffsetWhenHReenabledByAutomation = true;
            Save();
        };

        _offsetKeepWhenReenabled.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_offsetKeepWhenReenabled.Checked)
            {
                return;
            }

            _settings.ResetOffsetWhenHReenabledByAutomation = false;
            Save();
        };

        _resetHOnRestart.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_resetHOnRestart.Checked)
            {
                return;
            }

            _settings.ResetHOnRestart = true;
            Save();
        };

        _keepHOnRestart.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_keepHOnRestart.Checked)
            {
                return;
            }

            _settings.ResetHOnRestart = false;
            Save();
        };

        _wheelLegacy.CheckedChanged += (_, _) => SetWheelMode(QuickAdjustWheelMode.Legacy);
        _wheelHeaderFive.CheckedChanged += (_, _) => SetWheelMode(QuickAdjustWheelMode.HeaderFive);
        _wheelMixed.CheckedChanged += (_, _) => SetWheelMode(QuickAdjustWheelMode.MixedSlider);
        _farJumpCheckBox.CheckedChanged += (_, _) =>
        {
            if (_syncing)
            {
                return;
            }

            _settings.ContrastSaturationFarJump = _farJumpCheckBox.Checked;
            Save();
        };

        _disableAutomationAfterPlus.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_disableAutomationAfterPlus.Checked)
            {
                return;
            }

            _settings.KeepAutomationAfterPlus = false;
            _plusHSettingsPanel.Visible = true;
            Save();
        };
        _keepAutomationAfterPlus.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_keepAutomationAfterPlus.Checked)
            {
                return;
            }

            _settings.KeepAutomationAfterPlus = true;
            _plusHSettingsPanel.Visible = false;
            Save();
        };
        _rememberHAfterPlus.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_rememberHAfterPlus.Checked)
            {
                return;
            }

            _settings.PlusHMode = PlusHMode.Remember;
            Save();
        };
        _disableHAfterPlus.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_disableHAfterPlus.Checked)
            {
                return;
            }

            _settings.PlusHMode = PlusHMode.Disable;
            Save();
        };

        _automationRestartAuto.CheckedChanged += (_, _) => SetAutomationRestartMode(AutomationRestartMode.Auto);
        _automationRestartOff.CheckedChanged += (_, _) => SetAutomationRestartMode(AutomationRestartMode.Off);
        _automationRestartOn.CheckedChanged += (_, _) => SetAutomationRestartMode(AutomationRestartMode.On);
        _lastCurve.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_lastCurve.Checked)
            {
                return;
            }

            _settings.UseStartupCurveSelection = false;
            _startupCurveBox.Enabled = false;
            Save();
        };
        _selectedCurve.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_selectedCurve.Checked)
            {
                return;
            }

            _settings.UseStartupCurveSelection = true;
            _startupCurveBox.Enabled = true;
            Save();
        };
        _startupCurveBox.SelectedIndexChanged += (_, _) =>
        {
            if (_syncing || _startupCurveBox.SelectedIndex < 0)
            {
                return;
            }

            _settings.StartupCurveSlot = _startupCurveBox.SelectedIndex + 1;
            Save();
        };

        _manualValuesUnchanged.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_manualValuesUnchanged.Checked) return;
            _settings.UseStartupManualValues = false;
            _manualValuesPanel.Visible = false;
            Save();
        };
        _manualValuesFromTable.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_manualValuesFromTable.Checked) return;
            _settings.UseStartupManualValues = true;
            _manualValuesPanel.Visible = true;
            Save();
        };
        WireStartupValue(_startupBrightnessEnabled, _startupBrightness, value => _settings.StartupBrightnessEnabled = value);
        WireStartupValue(_startupContrastEnabled, _startupContrast, value => _settings.StartupContrastEnabled = value);
        WireStartupValue(_startupSaturationEnabled, _startupSaturation, value => _settings.StartupSaturationEnabled = value);
        WireStartupValue(_startupRgbEnabled, _startupRgb, value => _settings.StartupRgbEnabled = value);
        WireStartupValue(_startupGammaEnabled, _startupGamma, value => _settings.StartupGammaEnabled = value);
        _startupBrightness.ValueChanged += (_, _) => SaveStartupValues();
        _startupContrast.ValueChanged += (_, _) => SaveStartupValues();
        _startupSaturation.ValueChanged += (_, _) => SaveStartupValues();
        _startupRgb.ValueChanged += (_, _) => SaveStartupValues();
        _startupGamma.SelectedIndexChanged += (_, _) => SaveStartupValues();
        WireStartupWheel(_startupBrightness);
        WireStartupWheel(_startupContrast);
        WireStartupWheel(_startupSaturation);
        WireStartupWheel(_startupRgb);
        _presetKeepAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_presetKeepAutomation.Checked) return;
            _settings.PresetAutomationMode = PresetAutomationMode.KeepAutomation;
            Save();
        };
        _presetDisableAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_presetDisableAutomation.Checked) return;
            _settings.PresetAutomationMode = PresetAutomationMode.DisableAutomation;
            Save();
        };
        _gammaResetEnabled.CheckedChanged += (_, _) =>
        {
            if (_syncing) return;
            _settings.GammaManualResetEnabled = _gammaResetEnabled.Checked;
            _gammaResetPanel.Visible = _gammaResetEnabled.Checked;
            Save();
        };
        WireGammaResetValue(_gammaResetBrightnessEnabled, value => _settings.GammaResetBrightnessEnabled = value);
        WireGammaResetValue(_gammaResetContrastEnabled, value => _settings.GammaResetContrastEnabled = value);
        WireGammaResetValue(_gammaResetSaturationEnabled, value => _settings.GammaResetSaturationEnabled = value);
        WireGammaResetValue(_gammaResetRgbEnabled, value => _settings.GammaResetRgbEnabled = value);
        WireGammaResetValue(_gammaResetGammaEnabled, value => _settings.GammaResetGammaEnabled = value);
        _gammaResetBrightness.ValueChanged += (_, _) => SaveGammaResetValues();
        _gammaResetContrast.ValueChanged += (_, _) => SaveGammaResetValues();
        _gammaResetSaturation.ValueChanged += (_, _) => SaveGammaResetValues();
        _gammaResetRgb.ValueChanged += (_, _) => SaveGammaResetValues();
        _gammaResetGamma.SelectedIndexChanged += (_, _) => SaveGammaResetValues();
        _gammaResetKeepCurrentAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_gammaResetKeepCurrentAutomation.Checked) return;
            _settings.GammaResetAutomationMode = GammaResetAutomationMode.KeepCurrent;
            Save();
        };
        _gammaResetDisableAutomation.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_gammaResetDisableAutomation.Checked) return;
            _settings.GammaResetAutomationMode = GammaResetAutomationMode.DisableAutomation;
            Save();
        };
        _gammaResetMouseMiddle.CheckedChanged += (_, _) => SaveGammaResetMouseButton(GammaResetMouseButton.Middle);
        _gammaResetMouseLeft.CheckedChanged += (_, _) => SaveGammaResetMouseButton(GammaResetMouseButton.Left);
        _gammaResetMouseRight.CheckedChanged += (_, _) => SaveGammaResetMouseButton(GammaResetMouseButton.Right);
        WireStartupWheel(_gammaResetBrightness);
        WireStartupWheel(_gammaResetContrast);
        WireStartupWheel(_gammaResetSaturation);
        WireStartupWheel(_gammaResetRgb);
        _nightRemember.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_nightRemember.Checked) return;
            _settings.NightModeSetting = NightModeSetting.RememberLast;
            _nightSchedulePanel.Visible = false;
            Save();
        };
        _nightDaily.CheckedChanged += (_, _) =>
        {
            if (_syncing || !_nightDaily.Checked) return;
            _settings.NightModeSetting = NightModeSetting.DailySchedule;
            _nightSchedulePanel.Visible = true;
            Save();
        };
        _nightStart.SelectedIndexChanged += (_, _) => SaveNightSchedule();
        _nightEnd.SelectedIndexChanged += (_, _) => SaveNightSchedule();
    }

    private Control MakeManualValueRow(string label, CheckBox enabled, NumericUpDown value, Label noneLabel)
    {
        enabled.Text = string.Empty;
        enabled.AutoSize = false;
        enabled.Size = new Size(24, 24);
        enabled.Margin = new Padding(16, 0, 0, 0);
        Label caption = new()
        {
            Text = label,
            AutoSize = false,
            Width = 105,
            Height = 24,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0)
        };
        ConfigureStartupNumeric(value, 50);
        FlowLayoutPanel row = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = false,
            Width = 225,
            Height = 24,
            WrapContents = false,
            Margin = new Padding(0)
        };
        row.Controls.Add(enabled);
        row.Controls.Add(caption);
        Panel holder = CreateStartupValueHolder(value, noneLabel);
        row.Controls.Add(holder);
        return row;
    }

    private Control MakeManualGammaRow()
    {
        _startupGammaEnabled.Text = string.Empty;
        _startupGammaEnabled.AutoSize = false;
        _startupGammaEnabled.Size = new Size(24, 24);
        _startupGammaEnabled.Margin = new Padding(16, 0, 0, 0);
        Label caption = new()
        {
            Text = "Gamma",
            AutoSize = false,
            Width = 105,
            Height = 24,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0)
        };
        _startupGamma.DropDownStyle = ComboBoxStyle.DropDownList;
        _startupGamma.Width = 80;
        _startupGamma.Height = _startupBrightness.Height;
        _startupGamma.IntegralHeight = false;
        _startupGammaHolder.Width = 80;
        _startupGammaHolder.Height = _startupBrightness.Height;
        _startupGammaHolder.Margin = new Padding(0);
        _startupGamma.Margin = new Padding(0);
        FlowLayoutPanel row = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = false,
            Width = 225,
            Height = 24,
            WrapContents = false,
            Margin = new Padding(0)
        };
        row.Controls.Add(_startupGammaEnabled);
        row.Controls.Add(caption);
        _startupGammaNone.Dock = DockStyle.Fill;
        _startupGammaNone.TextAlign = ContentAlignment.MiddleLeft;
        _startupGammaHolder.Controls.Add(_startupGammaNone);
        _startupGammaHolder.Controls.Add(_startupGamma);
        row.Controls.Add(_startupGammaHolder);
        return row;
    }

    private void ChooseIcon(bool appIcon)
    {
        using OpenFileDialog dialog = new()
        {
            Title = appIcon ? "Wybierz ikonę aplikacji" : "Wybierz ikonę tray",
            Filter = "Pliki obrazów (*.png;*.jpg;*.jpeg;*.bmp;*.ico)|*.png;*.jpg;*.jpeg;*.bmp;*.ico|Wszystkie pliki (*.*)|*.*",
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        if (!IconFileLoader.TryLoad(dialog.FileName, out Icon? icon, out string error))
        {
            MessageBox.Show(this, error, "LightSter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        icon?.Dispose();
        string fileName = appIcon ? "app-icon" : "tray-icon";
        string extension = Path.GetExtension(dialog.FileName);
        string? previousPath = appIcon ? _settings.CustomAppIconPath : _settings.CustomTrayIconPath;
        if (!IconFileLoader.TryCopyToStorage(
                dialog.FileName,
                fileName + extension,
                out string storedPath,
                out error))
        {
            MessageBox.Show(this, error, "LightSter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (appIcon)
        {
            if (!string.Equals(previousPath, storedPath, StringComparison.OrdinalIgnoreCase))
            {
                IconFileLoader.DeleteStored(previousPath);
            }
            _settings.CustomAppIconPath = storedPath;
        }
        else
        {
            if (!string.Equals(previousPath, storedPath, StringComparison.OrdinalIgnoreCase))
            {
                IconFileLoader.DeleteStored(previousPath);
            }
            _settings.CustomTrayIconPath = storedPath;
        }
        Save();
    }

    private void ResetIcon(bool appIcon)
    {
        if (appIcon)
        {
            IconFileLoader.DeleteStored(_settings.CustomAppIconPath);
            _settings.CustomAppIconPath = null;
        }
        else
        {
            IconFileLoader.DeleteStored(_settings.CustomTrayIconPath);
            _settings.CustomTrayIconPath = null;
        }
        Save();
    }

    private void BuildGammaResetPanel()
    {
        _gammaResetPanel.AutoSize = true;
        _gammaResetPanel.Margin = new Padding(0);
        FlowLayoutPanel flow = new()
        {
            FlowDirection = FlowDirection.TopDown,
            AutoSize = true,
            WrapContents = false,
            Margin = new Padding(0)
        };
        flow.Controls.Add(MakeCompactResetRow("Jasność", _gammaResetBrightnessEnabled, _gammaResetBrightness, _gammaResetBrightnessNone));
        flow.Controls.Add(MakeCompactResetRow("Kontrast", _gammaResetContrastEnabled, _gammaResetContrast, _gammaResetContrastNone));
        flow.Controls.Add(MakeCompactResetRow("Saturacja", _gammaResetSaturationEnabled, _gammaResetSaturation, _gammaResetSaturationNone));
        flow.Controls.Add(MakeCompactResetRow("RGB", _gammaResetRgbEnabled, _gammaResetRgb, _gammaResetRgbNone));

        _gammaResetGamma.DropDownStyle = ComboBoxStyle.DropDownList;
        _gammaResetGamma.Width = 64;
        foreach (double gamma in GammaSteps.Values.Reverse())
        {
            _gammaResetGamma.Items.Add(gamma.ToString("0.0"));
        }
        Panel gammaHolder = CreateStartupValueHolder(_gammaResetGamma, _gammaResetGammaNone);
        _gammaResetGamma.Height = 24;
        flow.Controls.Add(MakeCompactResetRow("Gamma", _gammaResetGammaEnabled, gammaHolder));
        flow.Controls.Add(MakeSubLabel("Krzywe po resecie"));
        flow.Controls.Add(MakeRadioGroup(
            (_gammaResetKeepCurrentAutomation, "Pozostaw obecny stan krzywych"),
            (_gammaResetDisableAutomation, "Wyłącz automatyczne krzywe")));
        flow.Controls.Add(MakeSubLabel("Przycisk myszy"));
        flow.Controls.Add(MakeRadioGroup(
            (_gammaResetMouseMiddle, "Środkowy"),
            (_gammaResetMouseLeft, "Lewy"),
            (_gammaResetMouseRight, "Prawy")));
        _gammaResetPanel.Controls.Add(flow);
    }

    private Control MakeCompactResetRow(
        string label,
        CheckBox enabled,
        NumericUpDown value,
        Label noneLabel)
    {
        ConfigureStartupNumeric(value, 50);
        Panel holder = CreateStartupValueHolder(value, noneLabel);
        return MakeCompactResetRow(label, enabled, holder);
    }

    private static Control MakeCompactResetRow(string label, CheckBox enabled, Control value)
    {
        enabled.Text = string.Empty;
        enabled.AutoSize = false;
        enabled.Size = new Size(20, 22);
        enabled.Margin = new Padding(0, 0, 4, 0);
        Label caption = new()
        {
            Text = label,
            AutoSize = false,
            Width = 68,
            Height = 22,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0)
        };
        value.Margin = new Padding(0);
        FlowLayoutPanel row = new()
        {
            FlowDirection = FlowDirection.LeftToRight,
            AutoSize = true,
            WrapContents = false,
            Height = 24,
            Margin = new Padding(0)
        };
        row.Controls.Add(enabled);
        row.Controls.Add(caption);
        row.Controls.Add(value);
        return row;
    }

    private static void ConfigureStartupNumeric(NumericUpDown control, int value)
    {
        control.Minimum = 0;
        control.Maximum = 100;
        control.Width = 80;
        control.Value = value;
    }

    private void WireStartupValue(CheckBox enabled, Control valueControl, Action<bool> saveEnabled)
    {
        enabled.CheckedChanged += (_, _) =>
        {
            if (_syncing) return;
            saveEnabled(enabled.Checked);
            UpdateManualValueControls();
            Save();
        };
    }

    private void UpdateManualValueControls()
    {
        _startupBrightness.Enabled = _startupBrightnessEnabled.Checked;
        _startupContrast.Enabled = _startupContrastEnabled.Checked;
        _startupSaturation.Enabled = _startupSaturationEnabled.Checked;
        _startupRgb.Enabled = _startupRgbEnabled.Checked;
        _startupGamma.Enabled = _startupGammaEnabled.Checked;
        _startupGamma.Visible = _startupGammaEnabled.Checked;
        _startupGammaNone.Visible = !_startupGammaEnabled.Checked;
        foreach (KeyValuePair<Control, Panel> entry in _startupValueHolders)
        {
            entry.Key.Visible = true;
        }

        _startupBrightness.Visible = _startupBrightnessEnabled.Checked;
        _startupContrast.Visible = _startupContrastEnabled.Checked;
        _startupSaturation.Visible = _startupSaturationEnabled.Checked;
        _startupRgb.Visible = _startupRgbEnabled.Checked;
        _startupBrightnessNone.Visible = !_startupBrightnessEnabled.Checked;
        _startupContrastNone.Visible = !_startupContrastEnabled.Checked;
        _startupSaturationNone.Visible = !_startupSaturationEnabled.Checked;
        _startupRgbNone.Visible = !_startupRgbEnabled.Checked;
        if (_startupGammaEnabled.Checked)
        {
            _startupGamma.SelectedIndex = GammaSteps.Values.Length - 1 - GammaSteps.IndexOf(_settings.StartupGamma);
        }
        else
        {
            _startupGamma.SelectedIndex = 0;
        }
    }

    private void UpdateGammaResetControls()
    {
        _gammaResetBrightness.Enabled = _gammaResetBrightnessEnabled.Checked;
        _gammaResetContrast.Enabled = _gammaResetContrastEnabled.Checked;
        _gammaResetSaturation.Enabled = _gammaResetSaturationEnabled.Checked;
        _gammaResetRgb.Enabled = _gammaResetRgbEnabled.Checked;
        _gammaResetGamma.Enabled = _gammaResetGammaEnabled.Checked;
        _gammaResetBrightness.Visible = _gammaResetBrightnessEnabled.Checked;
        _gammaResetContrast.Visible = _gammaResetContrastEnabled.Checked;
        _gammaResetSaturation.Visible = _gammaResetSaturationEnabled.Checked;
        _gammaResetRgb.Visible = _gammaResetRgbEnabled.Checked;
        _gammaResetGamma.Visible = _gammaResetGammaEnabled.Checked;
        _gammaResetBrightnessNone.Visible = !_gammaResetBrightnessEnabled.Checked;
        _gammaResetContrastNone.Visible = !_gammaResetContrastEnabled.Checked;
        _gammaResetSaturationNone.Visible = !_gammaResetSaturationEnabled.Checked;
        _gammaResetRgbNone.Visible = !_gammaResetRgbEnabled.Checked;
        _gammaResetGammaNone.Visible = !_gammaResetGammaEnabled.Checked;
    }

    private void WireGammaResetValue(CheckBox enabled, Action<bool> saveEnabled)
    {
        enabled.CheckedChanged += (_, _) =>
        {
            if (_syncing) return;
            saveEnabled(enabled.Checked);
            UpdateGammaResetControls();
            Save();
        };
    }

    private void SaveGammaResetValues()
    {
        if (_syncing) return;
        _settings.GammaResetBrightness = (int)_gammaResetBrightness.Value;
        _settings.GammaResetContrast = (int)_gammaResetContrast.Value;
        _settings.GammaResetSaturation = (int)_gammaResetSaturation.Value;
        _settings.GammaResetRgb = (int)_gammaResetRgb.Value;
        if (_gammaResetGammaEnabled.Checked && _gammaResetGamma.SelectedIndex >= 0)
        {
            _settings.GammaResetGamma =
                GammaSteps.Values[GammaSteps.Values.Length - 1 - _gammaResetGamma.SelectedIndex];
        }
        Save();
    }

    private void SaveGammaResetMouseButton(GammaResetMouseButton button)
    {
        if (_syncing)
        {
            return;
        }

        bool selected = button switch
        {
            GammaResetMouseButton.Left => _gammaResetMouseLeft.Checked,
            GammaResetMouseButton.Right => _gammaResetMouseRight.Checked,
            _ => _gammaResetMouseMiddle.Checked
        };
        if (!selected)
        {
            return;
        }

        _settings.GammaResetMouseButton = button;
        Save();
    }

    private void SaveStartupValues()
    {
        if (_syncing) return;
        _settings.StartupBrightness = (int)_startupBrightness.Value;
        _settings.StartupContrast = (int)_startupContrast.Value;
        _settings.StartupSaturation = (int)_startupSaturation.Value;
        _settings.StartupRgb = (int)_startupRgb.Value;
        if (_startupGammaEnabled.Checked && _startupGamma.SelectedIndex >= 0)
        {
            _settings.StartupGamma = GammaSteps.Values[GammaSteps.Values.Length - 1 - _startupGamma.SelectedIndex];
        }
        Save();
    }

    private void SaveNightSchedule()
    {
        if (_syncing || _nightStart.SelectedIndex < 0 || _nightEnd.SelectedIndex < 0) return;
        _settings.NightModeStartMinutes = _nightStart.SelectedIndex * 30;
        _settings.NightModeEndMinutes = _nightEnd.SelectedIndex * 30;
        Save();
    }

    private static void WireStartupWheel(NumericUpDown control)
    {
        control.MouseWheel += (_, e) =>
        {
            int direction = Math.Sign(e.Delta);
            decimal next = Math.Clamp(control.Value + direction * 5, control.Minimum, control.Maximum);
            control.Value = next;
            if (e is HandledMouseEventArgs handled)
            {
                handled.Handled = true;
            }
        };
    }

    private void SetWheelMode(QuickAdjustWheelMode mode)
    {
        if (_syncing)
        {
            return;
        }

        if (!((mode == QuickAdjustWheelMode.Legacy && _wheelLegacy.Checked)
            || (mode == QuickAdjustWheelMode.HeaderFive && _wheelHeaderFive.Checked)
            || (mode == QuickAdjustWheelMode.MixedSlider && _wheelMixed.Checked)))
        {
            return;
        }

        _settings.ContrastSaturationWheelMode = mode;
        UpdateWheelOptionsVisibility();
        Save();
    }

    private void UpdateWheelOptionsVisibility()
    {
        _farJumpCheckBox.Visible = _settings.ContrastSaturationWheelMode != QuickAdjustWheelMode.Legacy;
    }

    private void SetAutomationRestartMode(AutomationRestartMode mode)
    {
        if (_syncing)
        {
            return;
        }

        _settings.AutomationRestartMode = mode;
        Save();
    }

    private void Save()
    {
        try
        {
            _settings.Save();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                $"Nie zapisano ustawień: {ex.Message}",
                "LightSter",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}
