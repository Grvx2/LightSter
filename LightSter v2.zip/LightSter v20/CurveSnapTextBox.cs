namespace LightSter;

internal sealed class CurveSnapTextBox : TextBox
{
    private int _minimum = 1;
    private int _maximum = 100;
    private int _value = 1;
    private bool _updatingText;
    private bool _selectAllAfterMouseDown;

    public event EventHandler? ValueChanged;

    public int Minimum
    {
        get => _minimum;
        set
        {
            _minimum = value;
            Maximum = Math.Max(_maximum, _minimum);
            Value = Math.Clamp(_value, _minimum, _maximum);
        }
    }

    public int Maximum
    {
        get => _maximum;
        set
        {
            _maximum = Math.Max(value, _minimum);
            Value = Math.Clamp(_value, _minimum, _maximum);
        }
    }

    public int Value
    {
        get => _value;
        set
        {
            int next = Math.Clamp(value, _minimum, _maximum);
            bool changed = next != _value;
            _value = next;
            if (Text != next.ToString())
            {
                _updatingText = true;
                Text = next.ToString();
                _updatingText = false;
            }

            if (changed)
            {
                ValueChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public CurveSnapTextBox()
    {
        TextAlign = HorizontalAlignment.Center;
        Height = 28;
        Text = _value.ToString();
        TextChanged += (_, _) =>
        {
            if (_updatingText)
            {
                return;
            }

            if (int.TryParse(Text, out int typed) && typed >= _minimum && typed <= _maximum)
            {
                bool changed = typed != _value;
                _value = typed;
                if (changed)
                {
                    ValueChanged?.Invoke(this, EventArgs.Empty);
                }
            }
        };
        Leave += (_, _) => CommitText();
        Enter += (_, _) => SelectAll();
        KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                CommitText();
                e.SuppressKeyPress = true;
            }
        };
        KeyPress += (_, e) =>
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        };
    }

    protected override void WndProc(ref Message m)
    {
        const int WmMouseWheel = 0x020A;
        const int WmLeftButtonDown = 0x0201;
        if (m.Msg == WmMouseWheel)
        {
            int delta = (short)((m.WParam.ToInt64() >> 16) & 0xFFFF);
            int direction = Math.Sign(delta);
            if (direction != 0)
            {
                Value += direction;
            }

            m.Result = IntPtr.Zero;
            return;
        }

        if (m.Msg == WmLeftButtonDown && !Focused)
        {
            _selectAllAfterMouseDown = true;
        }

        base.WndProc(ref m);

        const int WmLeftButtonUp = 0x0202;
        if (m.Msg == WmLeftButtonUp && _selectAllAfterMouseDown)
        {
            _selectAllAfterMouseDown = false;
            BeginInvoke((Action)SelectAll);
        }
    }

    private void CommitText()
    {
        if (int.TryParse(Text, out int typed))
        {
            Value = typed;
        }
        else
        {
            Value = _value;
        }
    }
}
