namespace LightSter;

internal sealed class VerticalValueSlider : Control
{
    private int _minimum;
    private int _maximum = 100;
    private int _value;
    private bool _dragging;
    private Color _trackColor = Color.FromArgb(255, 196, 64);

    // Grid of "stop" values used when scrolling the mouse wheel. Always sorted ascending
    // and always contains at least Minimum and Maximum. Defaults to a uniform step of 2,
    // but can be overridden with an explicit (possibly irregular) list via SetWheelGrid.
    private List<int> _wheelGrid = [0, 2, 4, 6, 8, 10];
    private int _wheelAccumulator;
    private bool _farJump;

    public event EventHandler? ValueChanged;
    public event EventHandler? ValuePreview;

    public VerticalValueSlider()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        Width = 42;
        Height = 180;
        Cursor = Cursors.Hand;
    }

    public int Minimum
    {
        get => _minimum;
        set
        {
            _minimum = value;
            SetValueInternal(_value, raiseChanged: true);
        }
    }

    public int Maximum
    {
        get => _maximum;
        set
        {
            _maximum = value;
            SetValueInternal(_value, raiseChanged: true);
        }
    }

    /// <summary>
    /// Convenience setter that builds a uniform wheel grid from Minimum to Maximum using the given step.
    /// </summary>
    public int WheelStep
    {
        get => _wheelGrid.Count >= 2 ? _wheelGrid[1] - _wheelGrid[0] : 1;
        set
        {
            int step = Math.Max(1, value);
            List<int> grid = [];
            for (int candidate = _minimum; candidate < _maximum; candidate += step)
            {
                grid.Add(candidate);
            }

            grid.Add(_maximum);
            _wheelGrid = grid;
        }
    }

    /// <summary>
    /// Overrides the wheel grid with an explicit, possibly irregular, ascending list of stop values.
    /// Used for sliders where the step size is not uniform (e.g. RGB: ...,220,240,255).
    /// </summary>
    public void SetWheelGrid(IEnumerable<int> stops)
    {
        List<int> grid = stops.Distinct().OrderBy(v => v).ToList();
        if (grid.Count == 0)
        {
            grid.Add(_minimum);
        }

        if (grid[0] != _minimum)
        {
            grid.Insert(0, _minimum);
        }

        if (grid[^1] != _maximum)
        {
            grid.Add(_maximum);
        }

        _wheelGrid = grid;
    }

    public bool FarJump
    {
        get => _farJump;
        set => _farJump = value;
    }

    public int Value
    {
        get => _value;
        set => SetValueInternal(value, raiseChanged: true);
    }

    public void SetPreviewValue(int value)
    {
        SetValueInternal(value, raiseChanged: false);
    }

    public Color TrackColor
    {
        get => _trackColor;
        set
        {
            _trackColor = value;
            Invalidate();
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        Graphics graphics = e.Graphics;
        graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        Rectangle track = new(16, 8, 10, Height - 16);
        using SolidBrush trackBackground = new(Color.FromArgb(58, 62, 70));
        graphics.FillRectangle(trackBackground, track);

        float fillHeight = track.Height * ((_value - _minimum) / (float)(_maximum - _minimum));
        Rectangle fill = new(track.Left, (int)(track.Bottom - fillHeight), track.Width, (int)fillHeight);
        using SolidBrush fillBrush = new(_trackColor);
        graphics.FillRectangle(fillBrush, fill);

        int thumbY = (int)(track.Bottom - fillHeight) - 4;
        using SolidBrush thumbBrush = new(Color.White);
        graphics.FillEllipse(thumbBrush, track.Left - 3, thumbY, track.Width + 6, 8);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Left)
        {
            _dragging = true;
            Capture = true;
            UpdateValueFromPoint(e.Y);
        }
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_dragging)
        {
            UpdateValueFromPoint(e.Y);
        }
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (_dragging)
        {
            UpdateValueFromPoint(e.Y);
        }

        _dragging = false;
        Capture = false;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        AdjustByWheel(e.Delta);

        // Mark the message as handled so WinForms doesn't bubble the raw WM_MOUSEWHEEL
        // up to the parent form. QuickAdjustForm also intercepts WM_MOUSEWHEEL at the
        // form level (to support scrolling over a slider that doesn't have focus), and
        // without this the same wheel notch was being applied twice: once here, and
        // once again when the unhandled message reached the form's WndProc override.
        if (e is HandledMouseEventArgs handledArgs)
        {
            handledArgs.Handled = true;
        }
    }

    public void AdjustByWheel(int wheelDelta)
    {
        int notch = Math.Max(1, SystemInformation.MouseWheelScrollDelta);
        _wheelAccumulator += wheelDelta;

        while (_wheelAccumulator >= notch)
        {
            _wheelAccumulator -= notch;
            StepAlongGrid(+1);
        }

        while (_wheelAccumulator <= -notch)
        {
            _wheelAccumulator += notch;
            StepAlongGrid(-1);
        }
    }

    private void StepAlongGrid(int direction)
    {
        if (_farJump && _value % 10 == 5)
        {
            SetValueInternal(
                Math.Clamp(_value + direction * 3, _minimum, _maximum),
                raiseChanged: true);
            return;
        }

        int next = direction > 0 ? NextGridValueAbove(_value) : NextGridValueBelow(_value);
        SetValueInternal(next, raiseChanged: true);
    }

    /// <summary>
    /// Adjusts the value by exactly +/-<paramref name="step"/> per wheel notch, ignoring
    /// the grid entirely. Used when the cursor is over the caption/value label above the
    /// slider, so users can nudge a value by precise +/-1 increments regardless of the
    /// slider's own (usually coarser) wheel grid.
    /// </summary>
    public void AdjustByWheelStep(int wheelDelta, int step)
    {
        int notch = Math.Max(1, SystemInformation.MouseWheelScrollDelta);
        _wheelAccumulator += wheelDelta;

        while (_wheelAccumulator >= notch)
        {
            _wheelAccumulator -= notch;
            SetValueInternal(Math.Clamp(_value + step, _minimum, _maximum), raiseChanged: true);
        }

        while (_wheelAccumulator <= -notch)
        {
            _wheelAccumulator += notch;
            SetValueInternal(Math.Clamp(_value - step, _minimum, _maximum), raiseChanged: true);
        }
    }

    /// <summary>
    /// Moves to the next multiple of <paramref name="step"/> in the wheel direction.
    /// Values already between multiples are snapped to the next multiple rather than
    /// incremented by the full step.
    /// </summary>
    public void AdjustByWheelSnappedStep(int wheelDelta, int step)
    {
        int notch = Math.Max(1, SystemInformation.MouseWheelScrollDelta);
        _wheelAccumulator += wheelDelta;

        while (_wheelAccumulator >= notch)
        {
            _wheelAccumulator -= notch;
            int next = ((_value / step) + 1) * step;
            SetValueInternal(Math.Clamp(next, _minimum, _maximum), raiseChanged: true);
        }

        while (_wheelAccumulator <= -notch)
        {
            _wheelAccumulator += notch;
            int next = ((_value - 1) / step) * step;
            SetValueInternal(Math.Clamp(next, _minimum, _maximum), raiseChanged: true);
        }
    }

    private int NextGridValueAbove(int value)
    {
        foreach (int candidate in _wheelGrid)
        {
            if (candidate > value)
            {
                return candidate;
            }
        }

        return _maximum;
    }

    private int NextGridValueBelow(int value)
    {
        int result = _minimum;
        foreach (int candidate in _wheelGrid)
        {
            if (candidate < value)
            {
                result = candidate;
            }
            else
            {
                break;
            }
        }

        return result;
    }

    private void UpdateValueFromPoint(int y)
    {
        Rectangle track = new(16, 8, 10, Height - 16);
        float ratio = 1f - Math.Clamp((y - track.Top) / (float)track.Height, 0f, 1f);
        int value = _minimum + (int)Math.Round(ratio * (_maximum - _minimum));
        SetValueInternal(value, raiseChanged: true);
    }

    private void SetValueInternal(int value, bool raiseChanged)
    {
        int clamped = Math.Clamp(value, _minimum, _maximum);
        if (_value == clamped)
        {
            return;
        }

        _value = clamped;
        Invalidate();

        if (raiseChanged)
        {
            ValueChanged?.Invoke(this, EventArgs.Empty);
        }
        else
        {
            ValuePreview?.Invoke(this, EventArgs.Empty);
        }
    }
}
