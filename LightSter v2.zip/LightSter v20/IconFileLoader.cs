using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace LightSter;

internal static class IconFileLoader
{
    public static string IconStorageDirectory =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "LightSter",
            "icons");

    public static bool TryCopyToStorage(string sourcePath, string fileName, out string storedPath, out string error)
    {
        storedPath = string.Empty;
        error = string.Empty;
        try
        {
            Directory.CreateDirectory(IconStorageDirectory);
            storedPath = Path.Combine(IconStorageDirectory, fileName);
            File.Copy(sourcePath, storedPath, true);
            return true;
        }
        catch (IOException)
        {
            error = "Nie udało się zapisać kopii ikony w danych aplikacji.";
        }
        catch (UnauthorizedAccessException)
        {
            error = "Brak uprawnień do zapisania ikony w danych aplikacji.";
        }

        return false;
    }

    public static void DeleteStored(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)
            || !path.StartsWith(IconStorageDirectory + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        try
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
        catch (IOException)
        {
        }
        catch (UnauthorizedAccessException)
        {
        }
    }

    public static bool TryLoad(string path, out Icon? icon, out string error)
    {
        icon = null;
        error = string.Empty;
        try
        {
            using Bitmap bitmap = new(path);
            IntPtr handle = bitmap.GetHicon();
            using Icon temporary = Icon.FromHandle(handle);
            icon = (Icon)temporary.Clone();
            DestroyIcon(handle);
            return true;
        }
        catch (ArgumentException)
        {
            error = "Wybrany plik nie jest prawidłowym obrazem.";
        }
        catch (ExternalException)
        {
            error = "Nie udało się odczytać wybranego obrazu.";
        }
        catch (IOException)
        {
            error = "Nie udało się odczytać pliku obrazu.";
        }
        catch (UnauthorizedAccessException)
        {
            error = "Brak dostępu do wybranego pliku.";
        }

        return false;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool DestroyIcon(IntPtr hIcon);
}
