namespace LightSter;

internal enum QuickAdjustWheelMode
{
    Legacy = 0,
    HeaderFive = 1,
    MixedSlider = 2
}

internal enum AutomationRestartMode
{
    Auto = 0,
    Off = 1,
    On = 2
}

internal enum PlusHMode
{
    Remember = 0,
    Disable = 1
}

internal enum NightModeSetting
{
    RememberLast = 0,
    DailySchedule = 1
}

internal enum PresetAutomationMode
{
    DisableAutomation = 0,
    KeepAutomation = 1
}

internal enum GammaResetAutomationMode
{
    DisableAutomation = 0,
    KeepCurrent = 1
}

internal enum GammaResetMouseButton
{
    Middle = 0,
    Left = 1,
    Right = 2
}

internal enum HSlotChangeMode
{
    RememberPerCurve = 0,
    DisableAndReset = 1
}
